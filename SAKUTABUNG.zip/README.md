# SAKUTABUNG v0.0.1

**Sedikit demi sedikit, sampai jadi.**

Aplikasi celengan/tabungan pribadi **offline-first** untuk membuat target, menghitung kebutuhan menabung, mencatat transaksi, melihat progress, dan menerima pengingat lokal.

## Teknologi
- Android native + Kotlin
- Material 3 UI
- SQLiteOpenHelper untuk database lokal
- AlarmManager + BroadcastReceiver untuk pengingat lokal
- Tidak ada backend, login, cloud database, atau API key
- Android Gradle Plugin 9.4.0 + Gradle 9.6 + JDK 17

## Android compatibility
- Minimum: Android 5.0 (API 21)
- Target: Android 16 (API 36)
- Runtime API checks digunakan untuk fitur platform baru seperti permission notifikasi Android 13+.

## Upload paling simpel ke GitHub
1. Download `SAKUTABUNG.zip`.
2. Extract ZIP di HP/PC.
3. Di GitHub buat repository baru.
4. Upload **isi folder SAKUTABUNG** ke repository, termasuk folder `.github`.
5. Commit ke branch `main`.
6. GitHub Actions akan otomatis menjalankan workflow `Build APK`.

> **Penting:** GitHub Actions hanya mengenali workflow YAML yang berada di `.github/workflows/`. Karena itu, upload ZIP saja sebagai satu file tidak cukup untuk memicu workflow. Cara paling simpel adalah extract ZIP lalu upload semua isinya.

## Kalau project terlanjur berada di ZIP di repository
Workflow `build-apk.yml` juga dapat menemukan dan mengekstrak ZIP project secara otomatis **asalkan workflow YAML-nya sendiri sudah berada di `.github/workflows/`**. Setelah ZIP di-upload, push/commit akan menjalankan build.

## Build manual
Di GitHub:
**Actions → Build APK → Run workflow**.

Workflow akan:
1. Checkout repository
2. Mencari Gradle project di root, folder, atau ZIP
3. Menyiapkan JDK 17 dan Android SDK
4. Menjalankan unit test
5. Build Debug APK
6. Build Release APK
7. Mengupload APK sebagai Artifact

## Lokasi APK
Buka:
**GitHub → Actions → Build APK → workflow run → Artifacts → `SAKUTABUNG-v0.0.1-APKs`**

## Keamanan
v0.0.1 tidak membutuhkan server atau akun. Permission dibuat seminimal mungkin. Tidak ada API key, password, credential, atau secret pribadi di source code.

Release APK pada v0.0.1 adalah **unsigned release APK** untuk build/test. Untuk publikasi Google Play, gunakan **Android App Bundle (AAB)** dan signing key/keystore yang dikelola secara aman di luar source code.

## Fitur v0.0.1
- Beranda
- Celengan/target
- Deadline dan frekuensi
- Kalkulasi saldo, sisa, hari, progress, harian, mingguan
- Tambah tabungan dan catatan
- Riwayat transaksi
- Pengingat lokal
- Permission notifikasi Android 13+
- Penyimpanan SQLite lokal
- Pengaturan dasar
- Offline-first

## Known issue v0.0.1
Bug kecil pada loading/splash screen **sengaja belum diperbaiki** karena versi ini dipertahankan sebagai versi awal.
