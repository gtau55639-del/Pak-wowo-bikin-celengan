package com.sakutabung.app.util

import com.sakutabung.app.model.Goal
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class CalculatorTest {
 @Test fun calculatesRemainingAndDailyNeed(){
  val g=Goal(1,"HP Baru",3_000_000,"2026-09-01","2026-12-01","Setiap hari",20,0,true)
  val s=Calculator.stats(g,450_000,LocalDate.parse("2026-09-17"))
  assertEquals(2_550_000,s.remaining); assertEquals(15,s.progress); assertEquals(30_000,s.daily)
 }
 @Test fun neverGoesBelowZero(){
  val g=Goal(1,"Test",100,"2026-09-01","2026-09-17","Setiap hari",20,0,true)
  val s=Calculator.stats(g,150,LocalDate.parse("2026-09-17")); assertEquals(0,s.remaining); assertEquals(100,s.progress)
 }
}
