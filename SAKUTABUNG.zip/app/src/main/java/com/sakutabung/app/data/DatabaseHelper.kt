package com.sakutabung.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.sakutabung.app.model.Goal
import com.sakutabung.app.model.Transaction

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "sakutabung.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE goals(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,target INTEGER NOT NULL,start_date TEXT NOT NULL,deadline TEXT NOT NULL,frequency TEXT NOT NULL,reminder_hour INTEGER NOT NULL,reminder_minute INTEGER NOT NULL,active INTEGER NOT NULL DEFAULT 1)")
        db.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,goal_id INTEGER NOT NULL,amount INTEGER NOT NULL,date TEXT NOT NULL,note TEXT NOT NULL,FOREIGN KEY(goal_id) REFERENCES goals(id) ON DELETE CASCADE)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun insertGoal(g: Goal): Long { val v=ContentValues().apply{put("name",g.name);put("target",g.target);put("start_date",g.startDate);put("deadline",g.deadline);put("frequency",g.frequency);put("reminder_hour",g.reminderHour);put("reminder_minute",g.reminderMinute);put("active",if(g.active)1 else 0)}; return writableDatabase.insert("goals",null,v) }
    fun goals(): List<Goal> = readableDatabase.rawQuery("SELECT * FROM goals ORDER BY active DESC, deadline ASC",null).use { c -> buildList { while(c.moveToNext()) add(Goal(c.getLong(0),c.getString(1),c.getLong(2),c.getString(3),c.getString(4),c.getString(5),c.getInt(6),c.getInt(7),c.getInt(8)==1)) } }
    fun goal(id:Long): Goal? = readableDatabase.rawQuery("SELECT * FROM goals WHERE id=?",arrayOf(id.toString())).use{c->if(c.moveToFirst()) Goal(c.getLong(0),c.getString(1),c.getLong(2),c.getString(3),c.getString(4),c.getString(5),c.getInt(6),c.getInt(7),c.getInt(8)==1) else null}
    fun addTransaction(t:Transaction):Long { val v=ContentValues().apply{put("goal_id",t.goalId);put("amount",t.amount);put("date",t.date);put("note",t.note)}; val id=writableDatabase.insert("transactions",null,v); updateCompleted(t.goalId); return id }
    fun transactions(goalId:Long?=null):List<Transaction>{ val sql=if(goalId==null)"SELECT * FROM transactions ORDER BY date DESC,id DESC" else "SELECT * FROM transactions WHERE goal_id=? ORDER BY date DESC,id DESC"; val args=goalId?.let{arrayOf(it.toString())}; return readableDatabase.rawQuery(sql,args).use{c->buildList{while(c.moveToNext())add(Transaction(c.getLong(0),c.getLong(1),c.getLong(2),c.getString(3),c.getString(4)))}} }
    fun saved(goalId:Long):Long = readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE goal_id=?",arrayOf(goalId.toString())).use{c->c.moveToFirst();c.getLong(0)}
    private fun updateCompleted(goalId:Long){ val g=goal(goalId)?:return; if(saved(goalId)>=g.target) writableDatabase.execSQL("UPDATE goals SET active=0 WHERE id=?",arrayOf(goalId)) }
}
