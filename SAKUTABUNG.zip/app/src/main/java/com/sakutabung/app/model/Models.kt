package com.sakutabung.app.model

data class Goal(val id: Long, val name: String, val target: Long, val startDate: String, val deadline: String, val frequency: String, val reminderHour: Int, val reminderMinute: Int, val active: Boolean)
data class Transaction(val id: Long, val goalId: Long, val amount: Long, val date: String, val note: String)
data class GoalStats(val saved: Long, val remaining: Long, val daysLeft: Long, val progress: Int, val daily: Long, val weekly: Long)
