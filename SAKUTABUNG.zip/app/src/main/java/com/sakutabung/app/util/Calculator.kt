package com.sakutabung.app.util

import com.sakutabung.app.model.Goal
import com.sakutabung.app.model.GoalStats
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.ceil

object Calculator {
 fun stats(goal:Goal,saved:Long,today:LocalDate=LocalDate.now()):GoalStats{
   val remaining=(goal.target-saved).coerceAtLeast(0)
   val end=LocalDate.parse(goal.deadline)
   val days=ChronoUnit.DAYS.between(today,end).coerceAtLeast(0)
   val progress=((saved.toDouble()/goal.target.toDouble())*100).toInt().coerceIn(0,100)
   val divisor=days.coerceAtLeast(1)
   return GoalStats(saved,remaining,days,progress,ceil(remaining.toDouble()/divisor).toLong(),ceil(remaining.toDouble()/divisor*7).toLong())
 }
}
