package com.sakutabung.app.util
import java.text.NumberFormat
import java.util.Locale
object Format { fun rupiah(n:Long)=NumberFormat.getCurrencyInstance(Locale("id","ID")).apply{maximumFractionDigits=0;minimumFractionDigits=0}.format(n).replace("Rp","Rp ") }
