package com.sakutabung.app.ui

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.model.Goal
import com.sakutabung.app.model.Transaction
import com.sakutabung.app.notification.ReminderScheduler
import com.sakutabung.app.util.Calculator
import com.sakutabung.app.util.Format
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Calendar

class MainActivity: AppCompatActivity(){
 private lateinit var db:DatabaseHelper; private lateinit var root:LinearLayout; private val dateFmt=DateTimeFormatter.ISO_LOCAL_DATE
 private val notifPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()){ }
 override fun onCreate(b:Bundle?){super.onCreate(b);db=DatabaseHelper(this); buildShell(); if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS);showHome()}
 private fun buildShell(){ root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(0xFFF7F8F4.toInt())};setContentView(root); }
 private fun shell(title:String,body:View){root.removeAllViews(); val top=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,20,20,0)}; val t=TextView(this).apply{text=title;textSize=28f;setTextColor(0xFF20251F.toInt());setTypeface(null,Typeface.BOLD)};top.addView(t);root.addView(top,LinearLayout.LayoutParams(-1,0,1f));top.addView(body); val nav=BottomNavigationView(this).apply{menu.add("Beranda").setIcon(android.R.drawable.ic_menu_view).setItemId(1);menu.add("Celengan").setIcon(android.R.drawable.ic_menu_agenda).setItemId(2);menu.add("Riwayat").setIcon(android.R.drawable.ic_menu_recent_history).setItemId(3);menu.add("Pengaturan").setIcon(android.R.drawable.ic_menu_preferences).setItemId(4);setOnItemSelectedListener{when(it.itemId){1->{showHome();true};2->{showGoals();true};3->{showHistory();true};4->{showSettings();true};else->false}}};root.addView(nav,LinearLayout.LayoutParams(-1,64)); }
 private fun card(v:View):LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,16,16,16);setBackgroundResource(com.sakutabung.app.R.drawable.bg_card);addView(v)}
 private fun showHome(){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; val goals=db.goals();val total=goals.sumOf{db.saved(it.id)}; val header=TextView(this).apply{text="${Format.rupiah(total)}\nTotal Tabungan";textSize=22f;setTypeface(null,Typeface.BOLD);setPadding(0,12,0,20)};box.addView(header);box.addView(TextView(this).apply{text="Celengan Aktif  ${goals.count{it.active}}";textSize=16f;setPadding(0,0,0,16)}); goals.take(5).forEach{box.addView(goalCard(it))};val add=button("+ Buat Celengan"){showCreateGoal()};box.addView(add);shell("Beranda",ScrollView(this).apply{addView(box)})}
 private fun goalCard(g:Goal):View{val s=Calculator.stats(g,db.saved(g.id)); val tv=TextView(this).apply{text="🐷 ${g.name}\n${Format.rupiah(s.saved)} / ${Format.rupiah(g.target)}  •  ${s.progress}%\nSisa ${s.daysLeft} hari • ${Format.rupiah(s.daily)}/hari";textSize=16f;setTextColor(0xFF20251F.toInt())};val c=card(tv);c.setOnClickListener{showGoalDetail(g.id)};return c.apply{layoutParams=LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT).also{it.setMargins(0,0,0,12)}}}
 private fun showGoals(){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};db.goals().forEach{box.addView(goalCard(it))};box.addView(button("+ Buat Celengan"){showCreateGoal()});shell("Celengan",ScrollView(this).apply{addView(box)})}
 private fun showGoalDetail(id:Long){val g=db.goal(id)?:return;val s=Calculator.stats(g,db.saved(id));val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};box.addView(TextView(this).apply{text="🐷 ${g.name}";textSize=24f;setTypeface(null,Typeface.BOLD)});box.addView(TextView(this).apply{text="${Format.rupiah(s.saved)} / ${Format.rupiah(g.target)}\nProgress ${s.progress}%\nDeadline ${g.deadline}\nSisa ${s.daysLeft} hari\nRekomendasi berikutnya: ${Format.rupiah(s.daily)}/hari atau ${Format.rupiah(s.weekly)}/minggu";textSize=16f;setPadding(0,12,0,20)});if(s.remaining<=0)box.addView(TextView(this).apply{text="🎉 Target tercapai!";textSize=20f;setTypeface(null,Typeface.BOLD);setPadding(0,0,0,12)});box.addView(button("+ Tambah Tabungan"){showAddSaving(g)});box.addView(button("Riwayat"){showHistory(g.id)});shell(g.name,ScrollView(this).apply{addView(box)})}
 private fun showCreateGoal(){val form=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val name=edit("Nama celengan");val target=edit("Target nominal");val start=edit("Tanggal mulai");val deadline=edit("Deadline");val freq=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Setiap hari","Setiap minggu","Tanggal tertentu"))};val time=edit("Jam pengingat");form.addView(name);form.addView(target);form.addView(start);form.addView(deadline);form.addView(freq);form.addView(time);val now=LocalDate.now();start.setText(now.format(dateFmt));deadline.setText(now.plusDays(30).format(dateFmt));start.setOnClickListener{datePicker(start)};deadline.setOnClickListener{datePicker(deadline)};time.setOnClickListener{timePicker(time)};AlertDialog.Builder(this).setTitle("Buat Celengan").setView(form).setNegativeButton("Batal",null).setPositiveButton("Simpan",null).create().also{d->d.setOnShowListener{d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{try{val n=name.text.toString().trim();val t=target.text.toString().replace("[^0-9]".toRegex(),"").toLong();val sd=LocalDate.parse(start.text.toString());val ed=LocalDate.parse(deadline.text.toString());if(n.isBlank()||t<=0||ed.isBefore(sd))throw IllegalArgumentException();val hm=time.text.toString().split(":");val h=hm.getOrNull(0)?.toIntOrNull()?:20;val m=hm.getOrNull(1)?.toIntOrNull()?:0;val id=db.insertGoal(Goal(0,n,t,sd.toString(),ed.toString(),freq.selectedItem.toString(),h,m,true));ReminderScheduler.schedule(this,id,h,m);d.dismiss();showGoals()}catch(e:Exception){Toast.makeText(this,"Periksa nama, target, dan tanggal.",Toast.LENGTH_SHORT).show()}}}}.show()}
 private fun showAddSaving(g:Goal){val form=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val amount=edit("Nominal");val date=edit("Tanggal");val note=edit("Catatan");date.setText(LocalDate.now().toString());date.setOnClickListener{datePicker(date)};form.addView(amount);form.addView(date);form.addView(note);AlertDialog.Builder(this).setTitle("Tambah Tabungan").setView(form).setNegativeButton("Batal",null).setPositiveButton("Simpan"){_,_->try{val a=amount.text.toString().replace("[^0-9]".toRegex(),"").toLong();if(a<0)throw Exception();db.addTransaction(Transaction(0,g.id,a,date.text.toString(),note.text.toString()));if(db.saved(g.id)>=g.target)ReminderScheduler.cancel(this,g.id);showGoalDetail(g.id)}catch(_:Exception){Toast.makeText(this,"Nominal tidak valid.",Toast.LENGTH_SHORT).show()}}.show()}
 private fun showHistory(goalId:Long?=null){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};db.transactions(goalId).forEach{t->val g=db.goal(t.goalId);box.addView(card(TextView(this).apply{text="${t.date}\n- ${Format.rupiah(t.amount)}  ${t.note}\n${g?.name?:("")}";textSize=16f}))};shell("Riwayat",ScrollView(this).apply{addView(box)})}
 private fun showSettings(){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};box.addView(TextView(this).apply{text="SakuTabung\nSedikit demi sedikit, sampai jadi.\n\nData tersimpan lokal di perangkat. Tidak membutuhkan internet atau akun.";textSize=17f;setPadding(0,20,0,20)});box.addView(button("Izinkan notifikasi"){if(android.os.Build.VERSION.SDK_INT>=33)notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)});shell("Pengaturan",box)}
 private fun edit(h:String)=TextInputEditText(this).apply{hint=h;setTextSize(16f);setPadding(12,14,12,14);layoutParams=LinearLayout.LayoutParams(-1,60).also{it.setMargins(0,6,0,6)}}
 private fun button(text:String,action:()->Unit)=Button(this).apply{this.text=text;setTextSize(15f);setOnClickListener{action()};setAllCaps(false);setBackgroundResource(com.sakutabung.app.R.drawable.bg_primary_button);setTextColor(0xFFFFFFFF.toInt());layoutParams=LinearLayout.LayoutParams(-1,58).also{it.setMargins(0,8,0,8)}}
 private fun datePicker(target:TextView){val c=Calendar.getInstance();DatePickerDialog(this,{_,y,m,d->target.text="%04d-%02d-%02d".format(y,m+1,d)},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()}
 private fun timePicker(target:TextView){val c=Calendar.getInstance();TimePickerDialog(this,{_,h,m->target.text="%02d:%02d".format(h,m)},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show()}
}
