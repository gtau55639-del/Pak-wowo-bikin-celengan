package com.sakutabung.app.notification
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar
object ReminderScheduler{
 fun schedule(context:Context,goalId:Long,hour:Int,minute:Int){
  val am=context.getSystemService(AlarmManager::class.java); val i=Intent(context,SavingReminderReceiver::class.java).putExtra("goalId",goalId); val pi=PendingIntent.getBroadcast(context,goalId.toInt(),i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); val c=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,hour);set(Calendar.MINUTE,minute);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);if(timeInMillis<=System.currentTimeMillis())add(Calendar.DAY_OF_YEAR,1)}; am.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.timeInMillis,AlarmManager.INTERVAL_DAY,pi)
 }
 fun cancel(context:Context,goalId:Long){val am=context.getSystemService(AlarmManager::class.java);val i=Intent(context,SavingReminderReceiver::class.java);val pi=PendingIntent.getBroadcast(context,goalId.toInt(),i,PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE);if(pi!=null)am.cancel(pi)}
}
