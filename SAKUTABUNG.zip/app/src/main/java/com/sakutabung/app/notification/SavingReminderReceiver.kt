package com.sakutabung.app.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.sakutabung.app.R
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.util.Calculator
import com.sakutabung.app.util.Format

class SavingReminderReceiver: BroadcastReceiver(){
 override fun onReceive(context:Context,intent:Intent){
  val db=DatabaseHelper(context); val id=intent.getLongExtra("goalId", -1); val g=db.goal(id) ?: return; if(!g.active)return
  val s=Calculator.stats(g,db.saved(id)); if(s.remaining<=0)return
  val nm=context.getSystemService(NotificationManager::class.java); nm.createNotificationChannel(NotificationChannel("saving","Pengingat menabung",NotificationManager.IMPORTANCE_DEFAULT))
  val n=NotificationCompat.Builder(context,"saving").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("🐷 Waktunya menabung!").setContentText("Target hari ini: ${Format.rupiah(s.daily)} • ${g.name}").setAutoCancel(true).build(); nm.notify(id.toInt(),n)
 }
}
