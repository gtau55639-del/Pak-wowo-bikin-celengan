# SakuTabung v1: no custom shrinker rules required.
