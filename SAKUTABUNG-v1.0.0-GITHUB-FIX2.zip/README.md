# SakuTabung v1.0.0

**Sedikit demi sedikit, sampai jadi.**

Aplikasi Android celengan/tabungan pribadi yang offline-first. Data disimpan di SQLite lokal tanpa login, backend, cloud database, atau server.

## Fitur v1
- Dashboard total tabungan, target terdekat, dan celengan aktif
- Buat/edit/hapus celengan
- Target, tanggal mulai, deadline, dan frekuensi pengingat
- Kalkulasi saldo, sisa target, progress, kebutuhan harian/mingguan
- Tambah tabungan dengan nominal cepat, tanggal, dan catatan
- Riwayat + pencarian transaksi
- Notifikasi lokal dan penjadwalan ulang setelah reboot/update aplikasi
- Target tercapai otomatis menghentikan pengingat
- Light/dark mode
- Adaptive app icon + splash screen
- Android API 21+ (Android 5.0+) dengan target SDK 36
- Release R8 shrinking
- GitHub Actions build Debug + Release APK

## Menjalankan lokal
Buka project dengan Android Studio, tunggu Gradle sync, lalu jalankan konfigurasi `app` pada perangkat/emulator.

## Upload ke GitHub
Cara termudah: upload isi project ke repository. Workflow juga dapat menerima `SAKUTABUNG.zip` di root repository dan akan mengekstraknya otomatis.

## Build APK di GitHub
Buka **Actions → Build SAKUTABUNG APK → Run workflow**. Push ke branch `main` atau `master` juga memicu build otomatis.

APK tersedia di **workflow run → Artifacts**.

## Signing
Artifact release pada workflow adalah APK release yang belum ditandatangani dengan keystore pribadi. Untuk publikasi Play Store, buat keystore sendiri dan simpan credential hanya di GitHub Actions Secrets; jangan commit keystore/password ke repository.


## GitHub ZIP workflow

The repository workflow can build either an extracted Android project or a ZIP containing the complete Gradle project. If a ZIP is uploaded to the repository, the workflow extracts it automatically. The workflow uses the Android SDK already installed on the GitHub runner and does not request the obsolete `tools` SDK package.
