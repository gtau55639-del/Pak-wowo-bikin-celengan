# SakuTabung v3.5.1 — Startup/ANR Hardening

## Fokus

Versi ini memprioritaskan masalah startup yang dapat membuat aplikasi terlihat macet di splash atau memicu ANR, terutama pada perangkat Android lama/lebih lambat.

### Perbaikan
- Database dibuka dan di-warm di background thread sebelum layar utama dibuat.
- Tidak ada lagi query SQLite awal yang sengaja dijalankan di UI thread.
- Konfigurasi bahasa/tema hanya diterapkan jika memang berubah, untuk mencegah recreation yang tidak perlu.
- Splash tidak ditahan tanpa batas; jika persiapan database gagal, pengguna mendapat layar error yang bisa dicoba ulang.
- Riwayat menghindari pola N+1 query untuk nama target.
- Perubahan bahasa tidak lagi memanggil `recreate()` secara manual setelah AppCompat locale update.
- Google Login tetap opsional.
- Uang tetap fisik; aplikasi hanya mencatat progres.

## Catatan pengujian
Build Android penuh perlu dijalankan di GitHub Actions/Android Studio karena environment pengembangan ini tidak dapat mengunduh Gradle/dependency dari internet.

## Regression test wajib
1. Fresh install → buka aplikasi.
2. Tutup → buka lagi minimal 10 kali.
3. Home → Riwayat → Home berulang.
4. Riwayat dengan 0, 100, dan 1.000 catatan.
5. Android 10 dan Android versi baru.
6. Airplane mode.
7. Restore backup → buka Home/Riwayat.
8. Ubah tema dan bahasa → pastikan hanya satu recreation dan tidak masuk splash loop.
