package com.sakutabung.app.util

import org.junit.Assert.assertEquals
import org.junit.Test

class RewardManagerRulesTest {
    @Test fun premiumMilestonesAreFixed() {
        assertEquals("premium_3_days", RewardManager.levelReward(20))
        assertEquals("premium_7_days", RewardManager.levelReward(50))
        assertEquals("premium_permanent", RewardManager.levelReward(100))
    }

}
