package com.sakutabung.app.ui

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.R
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.game.GameLimitManager
import com.sakutabung.app.util.CoinManager
import com.sakutabung.app.util.RewardManager

/**
 * v3.0.0: one reliable feature hub. It exposes the real screens already shipped
 * in the project instead of scattering them across the home screen.
 */
class FeatureHubActivity : AppCompatActivity() {
    private val db by lazy { DatabaseHelper(this) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = androidx.core.content.ContextCompat.getColor(this, id)

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        build()
    }

    override fun onResume() {
        super.onResume()
        if (rootReady) build()
    }

    private var rootReady = false

    private fun build() {
        rootReady = false
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(30))
            setBackgroundResource(R.color.background)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(10))
        }
        val brand = ImageView(this).apply {
            setImageResource(R.drawable.ic_brand)
            setPadding(dp(5), dp(5), dp(5), dp(5))
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52)).also { it.setMargins(0, 0, dp(12), 0) }
        }
        header.addView(brand)
        header.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            addView(TextView(this@FeatureHubActivity).apply {
                text = "Semua Fitur"
                textSize = 25f
                setTypeface(null, Typeface.BOLD)
                setTextColor(color(R.color.text))
            })
            addView(TextView(this@FeatureHubActivity).apply {
                text = "Pusat semua alat SakuTabung"
                textSize = 13f
                setTextColor(color(R.color.muted))
            })
        })
        header.addView(ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            background = transparentRound()
            contentDescription = "Kembali"
            setOnClickListener { finish() }
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(46))
        })
        root.addView(header)

        val stats = card()
        stats.addView(TextView(this).apply {
            text = "Ringkasan cepat"
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(color(R.color.text))
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, 0) }
        stat(row, "Tercatat", db.totalSaved().let { "Rp${String.format("%,d", it).replace(',', '.')}" })
        stat(row, "Koin", "${CoinManager.balance(this)}")
        stat(row, "Game limit", "${GameLimitManager.getLimit(this)}")
        root.addView(stats.apply { addView(row) })

        root.addView(section("Keuangan dan Target"))
        feature(root, "Celengan Fisik", "Catat tempat kamu menyimpan uang secara fisik", R.drawable.ic_tab_target) { open(PhysicalSavingActivity::class.java) }
        feature(root, "Tabungan", "Tambah, lihat, dan kelola target tabungan", R.drawable.ic_tab_home) { openMainTab(2) }
        feature(root, "Target Tabungan", "Buat atau edit target dan pengingat", R.drawable.ic_tab_target) { openMainTab(2) }
        feature(root, "Riwayat", "Cari semua transaksi tabungan", R.drawable.ic_tab_history) { openMainTab(3) }
        feature(root, "Smart Goal", "Hitung kebutuhan harian/mingguan menuju target", R.drawable.ic_tab_smart) { open(SmartGoalActivity::class.java) }
        feature(root, "Rencana Menabung", "Lihat kebutuhan menabung hari ini untuk target aktif", R.drawable.ic_tab_smart) { open(SavingPlanActivity::class.java) }
        feature(root, "Tantangan Menabung", "Challenge offline untuk membangun kebiasaan menabung", R.drawable.ic_tab_target) { open(SavingChallengeActivity::class.java) }
        feature(root, "Insight Menabung", "Lihat pola, rata-rata, dan perkiraan progres target", R.drawable.ic_tab_smart) { open(SavingInsightActivity::class.java) }
        feature(root, "Template Target", "Mulai dari contoh target yang siap disesuaikan", R.drawable.ic_tab_target) { openTemplates() }

        root.addView(section("Game, Koin dan Reward"))
        feature(root, "Game Center", "Semua mini game dan skor", R.drawable.ic_tab_game) { open(GameHubActivity::class.java) }
        feature(root, "Brain Games", "Latihan memori, logika, angka, dan kata", R.drawable.ic_tab_game) { open(BrainGamesActivity::class.java) }
        feature(root, "Toko Koin", "Tukar koin menjadi limit ekstra", R.drawable.ic_tab_game) { open(CoinShopActivity::class.java) }
        feature(root, "Reward Center", "Daily reward, misi, XP, dan streak", R.drawable.ic_tab_game) { open(RewardCenterActivity::class.java) }

        root.addView(section("Profil dan Progres"))
        feature(root, "Profil", "Level, XP, reward milestone, dan status OPIMOUS", R.drawable.ic_account) { open(ProfileActivity::class.java) }

        root.addView(section("Progres dan Personalisasi"))
        feature(root, "SakuVerse", "Level, statistik, badge, koin, dan progres", R.drawable.ic_brand) { open(SakuVerseActivity::class.java) }
        feature(root, "Pengaturan", "Tema, bahasa, keamanan, backup, dan opsi aplikasi", R.drawable.ic_settings) { openSettings() }
        feature(root, "Widget", "Tambahkan ringkasan SakuTabung ke layar utama", R.drawable.ic_brand) { showWidgetInfo() }

        root.addView(section("Status akses"))
        root.addView(card().apply {
            addView(TextView(this@FeatureHubActivity).apply {
                text = "Tidak ada menu palsu"
                textSize = 16f
                setTypeface(null, Typeface.BOLD)
                setTextColor(color(R.color.text))
            })
            addView(TextView(this@FeatureHubActivity).apply {
                text = "Menu di halaman ini hanya mengarah ke fitur yang memang tersedia di aplikasi. Akun Free dan OPIMOUS tetap melihat pusat fitur yang sama; batas kuota game/tabungan diterapkan oleh sistem yang sesuai."
                textSize = 13f
                setTextColor(color(R.color.muted))
                setPadding(0, dp(5), 0, 0)
            })
        })

        scroll.addView(root)
        setContentView(scroll)
        rootReady = true
    }

    private fun open(clazz: Class<*>) = startActivity(Intent(this, clazz))

    private fun openMainTab(which: Int) {
        // MainActivity owns the real tab content. Re-opening it is safer than
        // duplicating its data/UI inside the hub.
        val intent = Intent(this, MainActivity::class.java).putExtra("open_tab", which)
        startActivity(intent)
    }

    private fun openSettings() {
        val intent = Intent(this, MainActivity::class.java).putExtra("open_settings", true)
        startActivity(intent)
    }

    private fun openTemplates() {
        val intent = Intent(this, MainActivity::class.java).putExtra("open_templates", true)
        startActivity(intent)
    }

    private fun showWidgetInfo() {
        AlertDialogBuilder(this)
            .setTitle("Widget SakuTabung")
            .setMessage("Widget tersedia di Android. Tekan lama area kosong di layar utama → Widget → SakuTabung.")
            .setPositiveButton("Mengerti", null)
            .show()
    }

    private fun feature(parent: LinearLayout, title: String, desc: String, icon: Int, action: () -> Unit) {
        val row = card().apply {
            orientation = LinearLayout.HORIZONTAL
            isClickable = true
            setOnClickListener { animate().scaleX(.985f).scaleY(.985f).setDuration(60).withEndAction { animate().scaleX(1f).scaleY(1f).setDuration(100).start(); action() }.start() }
        }
        row.addView(ImageView(this).apply {
            setImageResource(icon)
            imageTintList = android.content.res.ColorStateList.valueOf(color(R.color.primary))
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).also { it.setMargins(0, 0, dp(13), 0) }
        })
        row.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            addView(TextView(this@FeatureHubActivity).apply { text = title; textSize = 16f; setTypeface(null, Typeface.BOLD); setTextColor(color(R.color.text)) })
            addView(TextView(this@FeatureHubActivity).apply { text = desc; textSize = 12.5f; setTextColor(color(R.color.muted)); setPadding(0, dp(3), 0, 0) })
        })
        row.addView(TextView(this).apply { text = "›"; textSize = 28f; setTextColor(color(R.color.muted)); gravity = Gravity.CENTER })
        parent.addView(row)
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text
        textSize = 18f
        setTypeface(null, Typeface.BOLD)
        setTextColor(color(R.color.text))
        setPadding(dp(2), dp(15), dp(2), dp(7))
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(14), dp(15), dp(14))
        setBackgroundResource(R.drawable.bg_card)
        layoutParams = LinearLayout.LayoutParams(-1, -2).also { it.setMargins(0, 0, 0, dp(9)) }
    }

    private fun stat(row: LinearLayout, label: String, value: String) {
        row.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            addView(TextView(this@FeatureHubActivity).apply { text = label; textSize = 11f; setTextColor(color(R.color.muted)) })
            addView(TextView(this@FeatureHubActivity).apply { text = value; textSize = 14f; setTypeface(null, Typeface.BOLD); setTextColor(color(R.color.text)); setPadding(0, dp(2), 0, 0) })
        })
    }

    private fun transparentRound() = android.graphics.drawable.GradientDrawable().apply {
        setColor(android.graphics.Color.TRANSPARENT)
        cornerRadius = dp(14).toFloat()
    }

    // Avoid a dependency on a particular Material dialog version.
    private fun AlertDialogBuilder(context: android.content.Context) = androidx.appcompat.app.AlertDialog.Builder(context)
}
