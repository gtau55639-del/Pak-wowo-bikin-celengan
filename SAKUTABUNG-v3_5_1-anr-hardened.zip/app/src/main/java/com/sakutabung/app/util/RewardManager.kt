package com.sakutabung.app.util

import android.content.Context
import java.time.LocalDate

object RewardManager {
    private const val PREFS = "sakutabung_rewards"
    private const val DAILY = "daily_claim"
    private const val XP = "xp"
    private const val STREAK = "streak"
    private const val LAST = "last_day"
    private const val SAVING_XP_DAY = "saving_xp_day"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun today() = LocalDate.now().toString()

    fun xp(c: Context) = p(c).getInt(XP, 0).coerceAtLeast(0)
    fun level(c: Context) = (xp(c) / 100) + 1
    fun progress(c: Context) = xp(c) % 100
    fun streak(c: Context) = p(c).getInt(STREAK, 0).coerceAtLeast(0)
    fun dailyClaimed(c: Context) = p(c).getString(DAILY, null) == today()

    fun claimDaily(c: Context): Boolean {
        val sp = p(c)
        if (dailyClaimed(c)) return false
        val last = sp.getString(LAST, null)
        val yesterday = LocalDate.now().minusDays(1).toString()
        val s = if (last == yesterday) streak(c) + 1 else 1
        sp.edit().putString(DAILY, today()).putString(LAST, today()).putInt(STREAK, s).apply()
        CoinManager.add(c, 5)
        addXp(c, 15)
        return true
    }


    /** Counts consecutive calendar days with at least one physical-saving note. */
    fun savingStreak(c: Context): Int {
        val dates = com.sakutabung.app.data.DatabaseHelper(c).transactions().map { it.date }.toSet()
        var day = LocalDate.now()
        var count = 0
        while (dates.contains(day.toString())) { count++; day = day.minusDays(1) }
        return count
    }

    fun addXp(c: Context, amount: Int) {
        if (amount > 0) p(c).edit().putInt(XP, (xp(c) + amount).coerceAtMost(2_000_000)).apply()
    }

    /** Gives the daily saving XP only once per calendar day to prevent tiny-note farming. */
    fun addSavingXp(c: Context, amount: Int = 20): Boolean {
        val sp = p(c)
        if (sp.getString(SAVING_XP_DAY, null) == today()) return false
        sp.edit().putString(SAVING_XP_DAY, today()).apply()
        addXp(c, amount.coerceAtMost(20))
        return true
    }

    fun missionClaimed(c: Context, id: String) = p(c).getBoolean("mission_${id}_${today()}", false)
    fun claimMission(c: Context, id: String, coins: Int, xp: Int): Boolean {
        if (missionClaimed(c, id)) return false
        p(c).edit().putBoolean("mission_${id}_${today()}", true).apply()
        if (coins > 0) CoinManager.add(c, coins)
        addXp(c, xp)
        return true
    }

    fun levelReward(level: Int): String = when (level) {
        20 -> "premium_3_days"
        50 -> "premium_7_days"
        100 -> "premium_permanent"
        else -> "none"
    }

    fun rewardClaimed(c: Context, level: Int) = p(c).getBoolean("level_reward_$level", false)

    /** Claims only the three Premium milestone rewards. Each milestone is one-time. */
    fun claimLevelReward(c: Context, level: Int): Boolean {
        if (level !in setOf(20, 50, 100) || this.level(c) < level || rewardClaimed(c, level)) return false
        val ok = when (level) {
            20 -> PremiumManager.activateTrial(c, 3)
            50 -> PremiumManager.activateTrial(c, 7)
            100 -> PremiumManager.activatePermanent(c)
            else -> false
        }
        if (!ok) return false
        p(c).edit().putBoolean("level_reward_$level", true).apply()
        return true
    }

    fun nextPremiumLevel(c: Context): Int? = listOf(20, 50, 100).firstOrNull { level(c) < it }

    fun export(c: Context) = org.json.JSONObject().apply {
        put("xp", xp(c)); put("streak", streak(c)); put("lastDay", p(c).getString(LAST, "")); put("dailyClaim", p(c).getString(DAILY, "")); put("savingXpDay", p(c).getString(SAVING_XP_DAY, ""))
        put("reward20", rewardClaimed(c, 20)); put("reward50", rewardClaimed(c, 50)); put("reward100", rewardClaimed(c, 100))
    }

    fun import(c: Context, o: org.json.JSONObject?) {
        if (o == null) return
        p(c).edit()
            .putInt(XP, o.optInt("xp", 0).coerceAtLeast(0))
            .putInt(STREAK, o.optInt("streak", 0).coerceAtLeast(0))
            .putString(LAST, o.optString("lastDay", ""))
            .putString(DAILY, o.optString("dailyClaim", ""))
            .putString(SAVING_XP_DAY, o.optString("savingXpDay", ""))
            .putBoolean("level_reward_20", o.optBoolean("reward20", false))
            .putBoolean("level_reward_50", o.optBoolean("reward50", false))
            .putBoolean("level_reward_100", o.optBoolean("reward100", false))
            .apply()
    }
}
