package com.sakutabung.app.ui

import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.R
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.game.GameType
import com.sakutabung.app.util.CoinManager
import com.sakutabung.app.util.SavingLimitManager

/** v2.4: free-friendly coin shop. Coins never use real money. */
class CoinShopActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper
    private lateinit var balance: TextView
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    override fun onCreate(b: Bundle?) { super.onCreate(b); db=DatabaseHelper(this); title="Toko Koin"; build() }
    override fun onResume(){super.onResume(); if(::balance.isInitialized) build()}

    private fun build(){
        val scroll=ScrollView(this); val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(28))}
        root.addView(TextView(this).apply{text="Toko Koin";textSize=28f;setTypeface(null,Typeface.BOLD)})
        root.addView(TextView(this).apply{text="Kumpulkan koin dari game dan target tabungan yang selesai.";textSize=13f;setPadding(0,dp(4),0,dp(12))})
        val wallet=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(18));setBackgroundResource(R.drawable.bg_card);layoutParams=LinearLayout.LayoutParams(-1,-2).also{it.setMargins(0,0,0,dp(12))}}
        balance=TextView(this).apply{textSize=25f;setTypeface(null,Typeface.BOLD);text="${CoinManager.balance(this@CoinShopActivity)} koin"}; wallet.addView(balance)
        wallet.addView(TextView(this).apply{text="Limit ekstra tersedia: ${SavingLimitManager.extra(this@CoinShopActivity)}";textSize=13f;setPadding(0,dp(5),0,0)})
        root.addView(wallet)
        root.addView(section("Klaim dari skor game"))
        GameType.values().forEach { type -> gameRewardCard(root,type) }
        root.addView(section("Klaim target selesai"))
        val completed=db.goals().filter{!it.active && db.saved(it.id)>=it.target}
        if(completed.isEmpty()) root.addView(info("Belum ada target yang bisa diklaim."))
        completed.forEach { g ->
            val key="goal_${g.id}"
            val c=card(); c.addView(TextView(this).apply{text="${g.name}";textSize=16f;setTypeface(null,Typeface.BOLD)})
            c.addView(TextView(this).apply{text="Bonus penyelesaian: +${CoinManager.goalReward()} koin";textSize=13f;setPadding(0,dp(3),0,dp(7))})
            if(CoinManager.claimed(this,key)) c.addView(TextView(this).apply{text="Sudah diklaim";textSize=13f}) else c.addView(Button(this).apply{text="Klaim +${CoinManager.goalReward()}";setAllCaps(false);setOnClickListener{CoinManager.claim(this@CoinShopActivity,key,CoinManager.goalReward());build()}})
            root.addView(c)
        }
        root.addView(section("Tukarkan koin menjadi limit"))
        exchange(root,"+1 limit","25 koin",25,1)
        exchange(root,"+5 limit","100 koin",100,5)
        exchange(root,"+15 limit","250 koin",250,15)
        exchange(root,"+40 limit","600 koin",600,40)
        root.addView(info("Limit yang ditukar dari koin menjadi limit ekstra. Limit ini dapat dipakai setelah kuota mingguan Free habis."))
        scroll.addView(root);setContentView(scroll)
    }
    private fun gameRewardCard(root:LinearLayout,type:GameType){
        val best=db.bestScore(type.id)?:return; val tiers=listOf(50 to 6,80 to 12,100 to 20)
        val c=card(); c.addView(TextView(this).apply{text="${type.label} • skor terbaik $best";textSize=16f;setTypeface(null,Typeface.BOLD)})
        tiers.forEach{(score,coins)-> if(best>=score){val key="game_${type.id}_$score";val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=android.view.Gravity.CENTER_VERTICAL};row.addView(TextView(this).apply{text="Skor $score → +$coins";textSize=13f;layoutParams=LinearLayout.LayoutParams(0,-2,1f)}); if(CoinManager.claimed(this,key)) row.addView(TextView(this).apply{text="Diklaim"}) else row.addView(Button(this).apply{text="Klaim";setAllCaps(false);setOnClickListener{CoinManager.claim(this@CoinShopActivity,key,coins);build()}});c.addView(row)}}
        root.addView(c)
    }
    private fun exchange(root:LinearLayout,name:String,cost:String,coins:Int,limits:Int){
        val c=card(); c.addView(TextView(this).apply{text="$name • $cost";textSize=16f;setTypeface(null,Typeface.BOLD)});c.addView(Button(this).apply{text="Tukar";setAllCaps(false);setOnClickListener{
            when {
                !SavingLimitManager.canAddExtra(this@CoinShopActivity, limits) -> AlertDialog.Builder(this@CoinShopActivity).setTitle("Limit ekstra penuh").setMessage("Kurangi pemakaian limit ekstra sebelum menukar lagi.").setPositiveButton("OK",null).show()
                CoinManager.balance(this@CoinShopActivity) < coins -> AlertDialog.Builder(this@CoinShopActivity).setTitle("Koin belum cukup").setMessage("Kamu butuh $coins koin.").setPositiveButton("OK",null).show()
                else -> {
                    // Add the limit first; only spend coins after the capacity check succeeds.
                    if (SavingLimitManager.addExtra(this@CoinShopActivity, limits)) {
                        if (CoinManager.spend(this@CoinShopActivity, coins)) {
                            Toast.makeText(this@CoinShopActivity,"Berhasil: +$limits limit",Toast.LENGTH_SHORT).show()
                            build()
                        } else {
                            // Roll back the limit if the coin spend cannot be completed.
                            SavingLimitManager.setExtra(this@CoinShopActivity, (SavingLimitManager.extra(this@CoinShopActivity) - limits).coerceAtLeast(0))
                            AlertDialog.Builder(this@CoinShopActivity).setTitle("Penukaran gagal").setMessage("Koin tidak jadi dikurangi dan limit dikembalikan.").setPositiveButton("OK", null).show()
                        }
                    }
                }
            }
        }});root.addView(c)
    }
    private fun section(s:String)=TextView(this).apply{text=s;textSize=18f;setTypeface(null,Typeface.BOLD);setPadding(0,dp(12),0,dp(7))}
    private fun info(s:String)=TextView(this).apply{text=s;textSize=13f;setPadding(dp(5),dp(5),dp(5),dp(10))}
    private fun card()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(14),dp(15),dp(14));setBackgroundResource(R.drawable.bg_card);layoutParams=LinearLayout.LayoutParams(-1,-2).also{it.setMargins(0,0,0,dp(9))}}
}
