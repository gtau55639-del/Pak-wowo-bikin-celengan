package com.sakutabung.app.ui

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.R
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.game.GameLimitManager
import com.sakutabung.app.game.GameType
import com.sakutabung.app.game.Grades
import com.sakutabung.app.util.Format
import com.sakutabung.app.util.I18n

/**
 * Ditambahkan di v1.1.0 - pusat mini game.
 */
class GameHubActivity : AppCompatActivity() {
    private fun t(key: String, vararg args: Any) = I18n.t(this, key, *args)
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DatabaseHelper(this)
        title = t("game_title")
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    private fun build() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(20)) }

        root.addView(TextView(this).apply { text = t("game_title"); textSize = 26f; setTypeface(null, Typeface.BOLD) })
        root.addView(TextView(this).apply { text = t("game_desc"); textSize = 13f; setPadding(0, dp(4), 0, dp(14)) })

        val limitCard = card()
        val premium = com.sakutabung.app.util.PremiumManager.isPremium(this)
        val currentLimit = GameLimitManager.getLimit(this)
        limitCard.addView(TextView(this).apply { text = if (premium) "${t("opimous_status")}" else t("play_left", currentLimit); textSize = 18f; setTypeface(null, Typeface.BOLD) })
        limitCard.addView(TextView(this).apply { text = if (premium) t("unlimited_games") else t("play_rule"); textSize = 12f; setPadding(0, dp(4), 0, 0) })
        root.addView(limitCard)

        val gradeCard = card()
        gradeCard.addView(TextView(this).apply { text = t("grade"); textSize = 14f; setPadding(0, 0, 0, dp(6)) })
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@GameHubActivity, android.R.layout.simple_spinner_dropdown_item, Grades.all.map { it.label })
            val current = GameLimitManager.getGrade(this@GameHubActivity)
            setSelection(Grades.all.indexOfFirst { it.code == current }.coerceAtLeast(0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { GameLimitManager.setGrade(this@GameHubActivity, Grades.all[pos].code) }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        gradeCard.addView(spinner)
        root.addView(gradeCard)

        root.addView(Button(this).apply { text = "Brain Lab"; setAllCaps(false); setOnClickListener { startActivity(Intent(this@GameHubActivity, BrainGamesActivity::class.java)) } })
        root.addView(TextView(this).apply { text = t("pick_game"); textSize = 18f; setTypeface(null, Typeface.BOLD); setPadding(0, dp(10), 0, dp(6)) })
        GameType.values().forEach { type -> root.addView(gameCard(type)) }

        val recent = db.recentGameScores(5)
        if (recent.isNotEmpty()) {
            root.addView(TextView(this).apply { text = t("score_history"); textSize = 18f; setTypeface(null, Typeface.BOLD); setPadding(0, dp(10), 0, dp(6)) })
            val historyCard = card()
            recent.forEachIndexed { i, s ->
                val label = GameType.values().firstOrNull { it.id == s.gameType }?.label ?: s.gameType
                historyCard.addView(TextView(this).apply { text = "${Format.date(s.date)} • $label — ${t("score_n", s.score)}"; textSize = 13f; setPadding(0, if (i == 0) 0 else dp(4), 0, 0) })
            }
            root.addView(historyCard)
        }

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun gameCard(type: GameType): View {
        val c = card()
        val best = db.bestScore(type.id)
        c.addView(TextView(this).apply { text = type.label; textSize = 17f; setTypeface(null, Typeface.BOLD) })
        c.addView(TextView(this).apply { text = if (best != null) t("best_score", best) else t("never_played"); textSize = 13f; setPadding(0, dp(2), 0, dp(8)) })
        c.addView(Button(this).apply {
            text = t("play"); setAllCaps(false)
            setOnClickListener { startGame(type) }
        })
        return c
    }

    private fun startGame(type: GameType) {
        // Individual game activities own the actual consume operation.
        // This screen only performs a non-mutating availability check so a game
        // chance cannot be charged twice.
        if (GameLimitManager.getLimit(this) <= 0) {
            Toast.makeText(this, t("no_chance"), Toast.LENGTH_LONG).show()
            return
        }
        val intent = when (type) {
            GameType.SNAKE -> Intent(this, SnakeActivity::class.java)
            GameType.BLOCK_BLAST -> Intent(this, BlockBlastActivity::class.java)
            GameType.PUZZLE -> Intent(this, PuzzleActivity::class.java)
            GameType.MATH_QUIZ -> Intent(this, QuizActivity::class.java).putExtra("quiz_type", "math")
            GameType.ENGLISH_QUIZ -> Intent(this, QuizActivity::class.java).putExtra("quiz_type", "english")
            GameType.MEMORY, GameType.SEQUENCE, GameType.LOGIC, GameType.WORD_SCRAMBLE, GameType.NUMBER_GRID -> Intent(this, BrainGamesActivity::class.java)
        }
        startActivity(intent)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundResource(R.drawable.bg_card)
        layoutParams = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.setMargins(0, 0, 0, dp(12)) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
