package com.sakutabung.app.game

/**
 * Ditambahkan di v1.1.0 - fitur mini game.
 * File ini tidak mengubah fitur menabung yang sudah ada di v1.0.0.
 */

enum class GameType(val id: String, val label: String) {
    SNAKE("snake", "Ular Angka"),
    BLOCK_BLAST("block_blast", "Block Blast Lite"),
    PUZZLE("puzzle", "Puzzle Geser"),
    MATH_QUIZ("math_quiz", "Kuis Matematika"),
    ENGLISH_QUIZ("english_quiz", "Kuis Bahasa Inggris"),
    MEMORY("memory", "Memory Match"),
    SEQUENCE("sequence", "Sequence Otak"),
    LOGIC("logic", "Logika Cepat"),
    WORD_SCRAMBLE("word_scramble", "Acak Kata"),
    NUMBER_GRID("number_grid", "Number Grid")
}

/**
 * tier dipakai untuk menentukan tingkat kesulitan soal kuis:
 * 0 = SD kelas 1-3, 1 = SD kelas 4-6, 2 = SMP kelas 7-9, 3 = SMA kelas 10-12
 * number = nomor kelas 1..12, dipakai untuk menghaluskan tingkat kesulitan matematika.
 */
data class Grade(val code: String, val label: String, val tier: Int, val number: Int)

object Grades {
    val all = listOf(
        Grade("SD1", "SD Kelas 1", 0, 1),
        Grade("SD2", "SD Kelas 2", 0, 2),
        Grade("SD3", "SD Kelas 3", 0, 3),
        Grade("SD4", "SD Kelas 4", 1, 4),
        Grade("SD5", "SD Kelas 5", 1, 5),
        Grade("SD6", "SD Kelas 6", 1, 6),
        Grade("SMP7", "SMP Kelas 7", 2, 7),
        Grade("SMP8", "SMP Kelas 8", 2, 8),
        Grade("SMP9", "SMP Kelas 9", 2, 9),
        Grade("SMA10", "SMA Kelas 10", 3, 10),
        Grade("SMA11", "SMA Kelas 11", 3, 11),
        Grade("SMA12", "SMA Kelas 12", 3, 12)
    )

    fun byCode(code: String): Grade = all.firstOrNull { it.code == code } ?: all[6]
}

data class Question(val text: String, val options: List<String>, val correctIndex: Int)
