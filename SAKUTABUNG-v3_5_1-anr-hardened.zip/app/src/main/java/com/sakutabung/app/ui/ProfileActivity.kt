package com.sakutabung.app.ui

import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.R
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.util.CoinManager
import com.sakutabung.app.util.PremiumManager
import com.sakutabung.app.util.ProfileManager
import com.sakutabung.app.util.RewardManager

class ProfileActivity : AppCompatActivity() {
    private val db by lazy { DatabaseHelper(this) }
    private var built = false
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun color(id:Int)=androidx.core.content.ContextCompat.getColor(this,id)
    override fun onCreate(state: Bundle?) { super.onCreate(state); build() }
    override fun onResume() { super.onResume(); if (built) build() }

    private fun build() {
        built = true
        val scroll=ScrollView(this)
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(30)); setBackgroundResource(R.color.background) }
        root.addView(TextView(this).apply { text="Profil"; textSize=28f; setTypeface(null,Typeface.BOLD); setTextColor(color(R.color.text)) })
        root.addView(TextView(this).apply { text="Progress kamu tersimpan di perangkat. Google Login bersifat opsional."; textSize=13f; setTextColor(color(R.color.muted)); setPadding(0,dp(4),0,dp(14)) })

        val level=RewardManager.level(this); val progress=RewardManager.progress(this); val xp=RewardManager.xp(this)
        root.addView(card().apply {
            addView(TextView(this@ProfileActivity).apply { text=ProfileManager.name(this@ProfileActivity); textSize=23f; setTypeface(null,Typeface.BOLD); setTextColor(color(R.color.text)) })
            addView(TextView(this@ProfileActivity).apply { text="Level $level"; textSize=17f; setTextColor(color(R.color.primary)); setPadding(0,dp(5),0,dp(2)) })
            addView(ProgressBar(this@ProfileActivity,null,android.R.attr.progressBarStyleHorizontal).apply { max=100; this.progress=progress })
            addView(TextView(this@ProfileActivity).apply { text="$xp XP  •  ${100-progress} XP menuju level berikutnya"; textSize=12.5f; setTextColor(color(R.color.muted)); setPadding(0,dp(5),0,0) })
        })

        root.addView(card().apply {
            addView(TextView(this@ProfileActivity).apply { text="Progres"; textSize=17f; setTypeface(null,Typeface.BOLD); setTextColor(color(R.color.text)) })
            addView(TextView(this@ProfileActivity).apply { text="Streak menabung dan login dipisahkan. Game tetap dapat dimainkan offline."; textSize=13f; setTextColor(color(R.color.muted)); setPadding(0,dp(5),0,dp(7)) })
            addView(TextView(this@ProfileActivity).apply { text="Login streak: ${RewardManager.streak(this@ProfileActivity)} hari"; textSize=14f; setTextColor(color(R.color.text)) })
            addView(TextView(this@ProfileActivity).apply { text="Koin: ${CoinManager.balance(this@ProfileActivity)}"; textSize=14f; setTextColor(color(R.color.text)); setPadding(0,dp(4),0,0) })
        })

        root.addView(card().apply {
            addView(TextView(this@ProfileActivity).apply { text="Reward level"; textSize=17f; setTypeface(null,Typeface.BOLD); setTextColor(color(R.color.text)) })
            listOf(20 to "Premium 3 hari", 50 to "Premium 7 hari", 100 to "Premium permanen").forEach { (lv,label) ->
                val state=when { RewardManager.rewardClaimed(this@ProfileActivity,lv) -> "Sudah diklaim"; level>=lv -> "Tersedia"; else -> "Terbuka di Level $lv" }
                addView(TextView(this@ProfileActivity).apply { text="Level $lv  •  $label  •  $state"; textSize=13.5f; setTextColor(color(if(state=="Tersedia") R.color.primary else R.color.muted)); setPadding(0,dp(8),0,dp(3)) })
                if (level>=lv && !RewardManager.rewardClaimed(this@ProfileActivity,lv)) addView(Button(this@ProfileActivity).apply { text="Klaim"; setAllCaps(false); setOnClickListener { if(RewardManager.claimLevelReward(this@ProfileActivity,lv)){Toast.makeText(this@ProfileActivity,"Reward Level $lv berhasil diklaim",Toast.LENGTH_SHORT).show();build()} } })
            }
        })

        root.addView(card().apply {
            val active=PremiumManager.isPremium(this@ProfileActivity)
            addView(TextView(this@ProfileActivity).apply { text="OPIMOUS"; textSize=17f; setTypeface(null,Typeface.BOLD); setTextColor(color(R.color.text)) })
            addView(TextView(this@ProfileActivity).apply { text=when { PremiumManager.isPermanent(this@ProfileActivity) -> "Premium permanen"; active -> "Trial aktif • ${PremiumManager.daysRemaining(this@ProfileActivity)} hari tersisa"; else -> "Belum aktif • diperoleh melalui milestone level" }; textSize=13.5f; setTextColor(color(R.color.muted)); setPadding(0,dp(5),0,dp(8)) })
        })

        root.addView(Button(this).apply { text="Ganti nama"; setAllCaps(false); setOnClickListener { rename() } })
        root.addView(Button(this).apply { text="Kembali"; setAllCaps(false); setOnClickListener { finish() } })
        scroll.addView(root); setContentView(scroll)
    }

    private fun rename() {
        if (!ProfileManager.canChangeName(this)) { Toast.makeText(this,"Nama hanya dapat diganti sekali dalam satu bulan.",Toast.LENGTH_LONG).show(); return }
        val input=EditText(this).apply { setText(ProfileManager.name(this@ProfileActivity)); hint="Nama profil"; selectAll() }
        AlertDialog.Builder(this).setTitle("Ganti nama").setMessage("Nama dapat diganti satu kali dalam satu bulan.").setView(input).setNegativeButton("Batal",null).setPositiveButton("Simpan") { _,_ -> if(ProfileManager.changeName(this,input.text.toString())) build() else Toast.makeText(this,"Nama harus 3–24 karakter.",Toast.LENGTH_SHORT).show() }.show()
    }
    private fun card()=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(15),dp(16),dp(15)); setBackgroundResource(R.drawable.bg_card); layoutParams=LinearLayout.LayoutParams(-1,-2).also{it.setMargins(0,0,0,dp(10))} }
}
