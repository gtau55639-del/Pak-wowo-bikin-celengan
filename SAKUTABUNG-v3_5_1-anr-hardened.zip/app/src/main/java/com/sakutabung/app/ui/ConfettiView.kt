package com.sakutabung.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import kotlin.random.Random

class ConfettiView(context: Context) : View(context) {
    private data class Piece(var x: Float, var y: Float, var vx: Float, var vy: Float, var rot: Float, var size: Float, var color: Int)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pieces = mutableListOf<Piece>()
    private var started = false
    private val colors = intArrayOf(0xFF2E7D32.toInt(), 0xFFFFB300.toInt(), 0xFF42A5F5.toInt(), 0xFFEF5350.toInt(), 0xFFAB47BC.toInt())

    fun start() {
        pieces.clear()
        repeat(70) { pieces += Piece(width / 2f + Random.nextFloat() * width * .25f - width * .125f, height * .42f, Random.nextFloat() * 14f - 7f, -(Random.nextFloat() * 12f + 5f), Random.nextFloat() * 360f, Random.nextFloat() * 10f + 5f, colors.random()) }
        started = true
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!started) return
        var alive = false
        pieces.forEach { p ->
            p.x += p.vx; p.y += p.vy; p.vy += .28f; p.rot += 8f
            if (p.y < height + 30) alive = true
            paint.color = p.color; canvas.save(); canvas.rotate(p.rot, p.x, p.y); canvas.drawRect(p.x, p.y, p.x + p.size, p.y + p.size * .55f, paint); canvas.restore()
        }
        if (alive) postInvalidateDelayed(16) else started = false
    }
}
