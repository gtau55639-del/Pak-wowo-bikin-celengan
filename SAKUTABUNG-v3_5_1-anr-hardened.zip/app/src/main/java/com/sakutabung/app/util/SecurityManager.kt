package com.sakutabung.app.util

import android.content.Context
import java.security.MessageDigest

object SecurityManager {
    private const val PREFS = "security"
    private const val KEY_PIN = "pin_hash"
    private const val KEY_ENABLED = "lock_enabled"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun enabled(c: Context) = p(c).getBoolean(KEY_ENABLED, false) && p(c).contains(KEY_PIN)
    fun setPin(c: Context, pin: String) { p(c).edit().putString(KEY_PIN, hash(pin)).putBoolean(KEY_ENABLED, true).apply() }
    fun disable(c: Context) { p(c).edit().clear().apply() }
    fun verify(c: Context, pin: String) = p(c).getString(KEY_PIN, null) == hash(pin)
    private fun hash(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}
