package com.sakutabung.app.ui

import android.graphics.Typeface
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.R
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.util.Format
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class SavingPlanActivity: AppCompatActivity(){
 private val db by lazy{DatabaseHelper(this)}; private var built=false; private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt(); private fun color(id:Int)=androidx.core.content.ContextCompat.getColor(this,id)
 override fun onCreate(b:Bundle?){super.onCreate(b);build()}; override fun onResume(){super.onResume();if(built)build()}
 private fun build(){built=true;val s=ScrollView(this);val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(30));setBackgroundResource(R.color.background)}
  r.addView(TextView(this).apply{text="Rencana Menabung";textSize=28f;setTypeface(null,Typeface.BOLD);setTextColor(color(R.color.text))});r.addView(TextView(this).apply{text="Perhitungan dilakukan dari catatan tabungan fisik di perangkat. Tidak ada uang yang disimpan aplikasi.";textSize=13f;setTextColor(color(R.color.muted));setPadding(0,dp(4),0,dp(14))})
  val active=db.goals().filter{it.active};if(active.isEmpty()){r.addView(card().apply{addView(TextView(this@SavingPlanActivity).apply{text="Belum ada target aktif";textSize=17f;setTypeface(null,Typeface.BOLD);setTextColor(color(R.color.text))});addView(TextView(this@SavingPlanActivity).apply{text="Buat target terlebih dahulu agar SakuTabung dapat menghitung kebutuhan menabung.";textSize=13f;setTextColor(color(R.color.muted));setPadding(0,dp(5),0,0)})})} else active.forEach{g->val saved=db.saved(g.id);val remain=(g.target-saved).coerceAtLeast(0);val days=ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(g.deadline)).coerceAtLeast(0)+1;val daily=if(remain==0L)0L else (remain+days-1)/days;val status=when{remain==0L->"Target selesai";LocalDate.now().isAfter(LocalDate.parse(g.deadline))->"Terlambat";else->"Sesuai rencana"};r.addView(card().apply{addView(TextView(this@SavingPlanActivity).apply{text=g.name;textSize=18f;setTypeface(null,Typeface.BOLD);setTextColor(color(R.color.text))});addView(TextView(this@SavingPlanActivity).apply{text="Tercatat ${Format.rupiah(saved)} dari ${Format.rupiah(g.target)}";textSize=14f;setTextColor(color(R.color.text));setPadding(0,dp(5),0,dp(2))});addView(TextView(this@SavingPlanActivity).apply{text="Sisa ${Format.rupiah(remain)}";textSize=13f;setTextColor(color(R.color.muted))});addView(TextView(this@SavingPlanActivity).apply{text="Saran hari ini: ${Format.rupiah(daily)}";textSize=17f;setTypeface(null,Typeface.BOLD);setTextColor(color(R.color.primary));setPadding(0,dp(9),0,dp(2))});addView(TextView(this@SavingPlanActivity).apply{text="Deadline ${g.deadline} • $status";textSize=12.5f;setTextColor(color(R.color.muted))})})}
  r.addView(Button(this).apply{text="Kembali";setAllCaps(false);setOnClickListener{finish()}});s.addView(r);setContentView(s)}
 private fun card()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(15),dp(16),dp(15));setBackgroundResource(R.drawable.bg_card);layoutParams=LinearLayout.LayoutParams(-1,-2).also{it.setMargins(0,0,0,dp(10))}}
}
