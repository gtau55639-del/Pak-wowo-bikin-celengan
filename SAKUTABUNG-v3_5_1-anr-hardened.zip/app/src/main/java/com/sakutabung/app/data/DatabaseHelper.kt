package com.sakutabung.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.sakutabung.app.model.Goal
import com.sakutabung.app.model.GameScore
import com.sakutabung.app.model.Transaction
import java.time.LocalDate

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "sakutabung.db", null, 4) {
    override fun onConfigure(db: SQLiteDatabase) { db.setForeignKeyConstraintsEnabled(true) }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE goals(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,target INTEGER NOT NULL CHECK(target > 0),start_date TEXT NOT NULL,deadline TEXT NOT NULL,frequency TEXT NOT NULL,reminder_hour INTEGER NOT NULL,reminder_minute INTEGER NOT NULL,active INTEGER NOT NULL DEFAULT 1,coin_reward_claimed INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,goal_id INTEGER NOT NULL,amount INTEGER NOT NULL CHECK(amount > 0),date TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',FOREIGN KEY(goal_id) REFERENCES goals(id) ON DELETE CASCADE)")
        db.execSQL("CREATE INDEX idx_transactions_goal_date ON transactions(goal_id,date)")
        db.execSQL("CREATE TABLE game_scores(id INTEGER PRIMARY KEY AUTOINCREMENT,game_type TEXT NOT NULL,score INTEGER NOT NULL,grade TEXT NOT NULL,date TEXT NOT NULL)")
        db.execSQL("CREATE INDEX idx_game_scores_type ON game_scores(game_type)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("CREATE INDEX IF NOT EXISTS idx_transactions_goal_date ON transactions(goal_id,date)")
        if (oldVersion < 3) {
            db.execSQL("CREATE TABLE IF NOT EXISTS game_scores(id INTEGER PRIMARY KEY AUTOINCREMENT,game_type TEXT NOT NULL,score INTEGER NOT NULL,grade TEXT NOT NULL,date TEXT NOT NULL)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_game_scores_type ON game_scores(game_type)")
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE goals ADD COLUMN coin_reward_claimed INTEGER NOT NULL DEFAULT 0")
        }
    }

    fun insertGoal(g: Goal): Long = writableDatabase.insertOrThrow("goals", null, goalValues(g))
    fun updateGoal(g: Goal): Int = writableDatabase.update("goals", goalValues(g), "id=?", arrayOf(g.id.toString()))
    fun deleteGoal(id: Long): Int = writableDatabase.delete("goals", "id=?", arrayOf(id.toString()))

    private fun goalValues(g: Goal) = ContentValues().apply {
        put("name", g.name); put("target", g.target); put("start_date", g.startDate); put("deadline", g.deadline)
        put("frequency", g.frequency); put("reminder_hour", g.reminderHour); put("reminder_minute", g.reminderMinute); put("active", if (g.active) 1 else 0)
    }

    fun goals(): List<Goal> = readableDatabase.rawQuery("SELECT * FROM goals ORDER BY active DESC, deadline ASC", null).use { c ->
        buildList { while (c.moveToNext()) add(readGoal(c)) }
    }
    fun goal(id: Long): Goal? = readableDatabase.rawQuery("SELECT * FROM goals WHERE id=?", arrayOf(id.toString())).use { c -> if (c.moveToFirst()) readGoal(c) else null }
    private fun readGoal(c: android.database.Cursor) = Goal(c.getLong(0), c.getString(1), c.getLong(2), c.getString(3), c.getString(4), c.getString(5), c.getInt(6), c.getInt(7), c.getInt(8) == 1)

    fun addTransaction(t: Transaction): Long {
        require(t.amount > 0) { "amount" }
        require(t.date.isNotBlank()) { "date" }
        require(t.note.length <= 200) { "note_too_long" }
        require(runCatching { !LocalDate.parse(t.date).isAfter(LocalDate.now()) }.getOrDefault(false)) { "future_date" }
        require(goal(t.goalId) != null) { "goal" }
        val id = writableDatabase.insertOrThrow("transactions", null, ContentValues().apply { put("goal_id", t.goalId); put("amount", t.amount); put("date", t.date); put("note", t.note.trim()) })
        updateCompleted(t.goalId)
        return id
    }

    fun transactions(goalId: Long? = null): List<Transaction> {
        val sql = if (goalId == null) "SELECT * FROM transactions ORDER BY date DESC,id DESC" else "SELECT * FROM transactions WHERE goal_id=? ORDER BY date DESC,id DESC"
        val args = goalId?.let { arrayOf(it.toString()) }
        return readableDatabase.rawQuery(sql, args).use { c -> buildList { while (c.moveToNext()) add(Transaction(c.getLong(0), c.getLong(1), c.getLong(2), c.getString(3), c.getString(4))) } }
    }

    fun updateTransaction(t: Transaction): Boolean {
        require(t.amount > 0) { "amount" }
        require(runCatching { !LocalDate.parse(t.date).isAfter(LocalDate.now()) }.getOrDefault(false)) { "future_date" }
        require(t.note.length <= 200) { "note_too_long" }
        require(goal(t.goalId) != null) { "goal" }
        val oldGoalId = writableDatabase.rawQuery(
            "SELECT goal_id FROM transactions WHERE id=?", arrayOf(t.id.toString())
        ).use { c -> if (c.moveToFirst()) c.getLong(0) else null }
            ?: return false
        val updated = writableDatabase.update("transactions", ContentValues().apply {
            put("goal_id", t.goalId); put("amount", t.amount); put("date", t.date); put("note", t.note.trim())
        }, "id=?", arrayOf(t.id.toString())) > 0
        if (updated) {
            // A transaction may have been moved between goals. Reconcile both sides so
            // a previously completed goal cannot remain incorrectly marked complete.
            if (oldGoalId != t.goalId) {
                val oldGoal = goal(oldGoalId)
                if (oldGoal != null && saved(oldGoalId) < oldGoal.target) {
                    writableDatabase.execSQL("UPDATE goals SET active=1 WHERE id=?", arrayOf(oldGoalId))
                }
            }
            writableDatabase.execSQL("UPDATE goals SET active=1 WHERE id=?", arrayOf(t.goalId))
            updateCompleted(oldGoalId)
            updateCompleted(t.goalId)
        }
        return updated
    }

    fun deleteTransaction(id: Long): Long? {
        val db = writableDatabase
        val goalId = db.rawQuery("SELECT goal_id FROM transactions WHERE id=?", arrayOf(id.toString())).use { c ->
            if (c.moveToFirst()) c.getLong(0) else null
        } ?: return null
        db.delete("transactions", "id=?", arrayOf(id.toString()))
        val g = goal(goalId)
        if (g != null && !g.active && saved(goalId) < g.target) {
            db.execSQL("UPDATE goals SET active=1 WHERE id=?", arrayOf(goalId))
        }
        return goalId
    }

    fun saved(goalId: Long): Long = readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE goal_id=?", arrayOf(goalId.toString())).use { c -> c.moveToFirst(); c.getLong(0) }
    fun totalSaved(): Long = readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM transactions", null).use { c -> c.moveToFirst(); c.getLong(0) }
    fun activeCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM goals WHERE active=1", null).use { c -> c.moveToFirst(); c.getInt(0) }
    fun unclaimedCompletedGoalIds(): List<Long> = readableDatabase.rawQuery(
        "SELECT id FROM goals WHERE active=0 AND coin_reward_claimed=0 AND id IN (SELECT DISTINCT goal_id FROM transactions)", null
    ).use { c -> buildList { while (c.moveToNext()) add(c.getLong(0)) } }

    fun markGoalCoinRewardClaimed(id: Long): Boolean = writableDatabase.update("goals", ContentValues().apply { put("coin_reward_claimed", 1) }, "id=? AND coin_reward_claimed=0", arrayOf(id.toString())) > 0

    private fun updateCompleted(goalId: Long) {
        val g = goal(goalId) ?: return
        if (saved(goalId) >= g.target) writableDatabase.execSQL("UPDATE goals SET active=0 WHERE id=?", arrayOf(goalId))
    }

    // === v1.1.0: skor mini game ===
    fun insertGameScore(g: GameScore): Long = writableDatabase.insertOrThrow("game_scores", null, ContentValues().apply {
        put("game_type", g.gameType); put("score", g.score); put("grade", g.grade); put("date", g.date)
    })

    fun bestScore(gameType: String): Int? = readableDatabase.rawQuery("SELECT MAX(score) FROM game_scores WHERE game_type=?", arrayOf(gameType)).use { c ->
        c.moveToFirst(); if (c.isNull(0)) null else c.getInt(0)
    }

    fun recentGameScores(limit: Int = 10): List<GameScore> = readableDatabase.rawQuery("SELECT * FROM game_scores ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())).use { c ->
        buildList { while (c.moveToNext()) add(GameScore(c.getLong(0), c.getString(1), c.getInt(2), c.getString(3), c.getString(4))) }
    }
}
