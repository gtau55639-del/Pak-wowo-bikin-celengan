package com.sakutabung.app.ui

import android.Manifest
import android.app.DatePickerDialog
import android.appwidget.AppWidgetManager
import android.app.TimePickerDialog
import android.content.Intent
import android.accounts.Account
import android.accounts.AccountManager
import android.net.Uri
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.Gravity
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.view.animation.OvershootInterpolator
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textfield.TextInputEditText
import com.sakutabung.app.R
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.game.GameLimitManager
import com.sakutabung.app.model.Goal
import com.sakutabung.app.model.Transaction
import com.sakutabung.app.notification.ReminderScheduler
import com.sakutabung.app.util.Calculator
import com.sakutabung.app.util.Format
import com.sakutabung.app.util.I18n
import com.sakutabung.app.util.PremiumManager
import com.sakutabung.app.util.SecurityManager
import com.sakutabung.app.util.BackupManager
import com.sakutabung.app.util.SavingLimitManager
import com.sakutabung.app.util.CoinManager
import com.sakutabung.app.util.RewardManager
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val dateFmt = DateTimeFormatter.ISO_LOCAL_DATE
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val soundTone by lazy { ToneGenerator(AudioManager.STREAM_MUSIC, 70) }
    private var tabIndex = 0
    private var unlocked = false
    private val startupExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "SakuTabung-Startup").apply { isDaemon = true }
    }
    private val startupReady = AtomicBoolean(false)
    private var startupFailed = false
    private var startupScreenOpened = false
    private val backupPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        runCatching {
            val json = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("empty")
            BackupManager.restore(this, json)
            Toast.makeText(this, t("restore_done"), Toast.LENGTH_LONG).show()
            showHome()
        }.onFailure { Toast.makeText(this, t("restore_failed"), Toast.LENGTH_LONG).show() }
    }
    private var selectedGoalImageUri: Uri? = null
    private val imagePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            selectedGoalImageUri = it
            pendingGoalImage?.setImageURI(it)
            pendingGoalImage?.scaleType = ImageView.ScaleType.CENTER_CROP
        }
    }
    private var pendingGoalImage: ImageView? = null

    private fun t(key: String, vararg args: Any) = I18n.t(this, key, *args)

    override fun onCreate(state: Bundle?) {
        // Apply persisted configuration only when it actually differs. Calling
        // AppCompatDelegate on every onCreate can trigger an unnecessary Activity
        // recreation loop on older Android versions. Do it before super so the
        // starting theme and locale are stable for this Activity instance.
        applySavedThemeIfNeeded()
        applySavedLanguageIfNeeded()
        installSplashScreen()
        super.onCreate(state)
        buildBase()
        showStartupLoading()

        // SQLite opening/querying must never block the UI thread. This is especially
        // important on Android 10 devices where a cold DB open or migration can stall
        // the splash and become an ANR.
        startupExecutor.execute {
            try {
                val context = applicationContext
                db = DatabaseHelper(context)
                // Open and warm the DB off the main thread. These calls also validate
                // migrations before the first screen is rendered.
                db.writableDatabase
                db.goals()
                db.totalSaved()
                db.transactions()
                GameLimitManager.ensureInitialized(context)
                startupReady.set(true)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    if (SecurityManager.enabled(this)) {
                        lockApp()
                    } else {
                        unlocked = true
                        requestNotificationIfNeeded()
                        openRequestedScreenOnce()
                    }
                }
            } catch (t: Throwable) {
                startupFailed = true
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) showStartupFailure(t)
                }
            }
        }
    }

    override fun onDestroy() {
        startupExecutor.shutdownNow()
        runCatching { soundTone.release() }
        super.onDestroy()
    }

    private fun showStartupLoading() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        val icon = ImageView(this).apply {
            setImageResource(R.drawable.ic_brand)
            layoutParams = LinearLayout.LayoutParams(dp(72), dp(72))
            alpha = 0.92f
        }
        val title = TextView(this).apply {
            text = "SakuTabung"
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(getColorCompat(R.color.text))
            setPadding(0, dp(14), 0, dp(4))
        }
        val status = TextView(this).apply {
            text = "Menyiapkan data…"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(getColorCompat(R.color.muted))
        }
        val progress = LinearProgressIndicator(this).apply {
            isIndeterminate = true
            layoutParams = LinearLayout.LayoutParams(dp(150), dp(6)).also { it.setMargins(0, dp(18), 0, 0) }
        }
        box.addView(icon)
        box.addView(title)
        box.addView(status)
        box.addView(progress)
        setContentView(box)
        icon.animate().alpha(1f).scaleX(1.04f).scaleY(1.04f).setDuration(420).withEndAction {
            icon.animate().scaleX(1f).scaleY(1f).setDuration(260).start()
        }.start()
    }

    private fun showStartupFailure(error: Throwable) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(28), dp(28), dp(28))
        }
        box.addView(TextView(this).apply {
            text = "SakuTabung belum bisa dibuka"
            textSize = 21f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(getColorCompat(R.color.text))
        })
        box.addView(TextView(this).apply {
            text = "Data aplikasi gagal disiapkan. Aplikasi tidak akan dibiarkan menggantung di splash. Coba buka lagi atau kirim detail error ini ke pengembang."
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(getColorCompat(R.color.muted))
            setPadding(0, dp(10), 0, dp(14))
        })
        box.addView(secondaryButton("Coba Lagi") { recreate() })
        box.addView(TextView(this).apply {
            text = error.javaClass.simpleName + ": " + (error.message ?: "unknown")
            textSize = 10.5f
            setTextIsSelectable(true)
            setTextColor(getColorCompat(R.color.muted))
            setPadding(0, dp(12), 0, 0)
        })
        setContentView(box)
    }

    private fun openRequestedScreenOnce() {
        if (startupScreenOpened || !startupReady.get() || startupFailed) return
        startupScreenOpened = true
        openRequestedScreen()
    }

    private fun openRequestedScreen() {
        when (intent.getIntExtra("open_tab", 1)) {
            2 -> { tabIndex = 1; showGoals() }
            3 -> { tabIndex = 2; showHistory() }
            else -> {
                when {
                    intent.getBooleanExtra("open_settings", false) -> showSettings()
                    intent.getBooleanExtra("open_templates", false) -> showGoalTemplates()
                    else -> showHome()
                }
            }
        }
        intent.removeExtra("open_tab")
        intent.removeExtra("open_settings")
    }

    private fun applySavedLanguageIfNeeded() {
        val lang = prefs.getString("language", "id") ?: "id"
        val desired = LocaleListCompat.forLanguageTags(lang)
        val current = AppCompatDelegate.getApplicationLocales()
        if (current.toLanguageTags() != desired.toLanguageTags()) {
            AppCompatDelegate.setApplicationLocales(desired)
        }
    }

    private fun applySavedThemeIfNeeded() {
        val mode = prefs.getString("theme", if (prefs.getBoolean("dark_mode", false)) "dark" else "light") ?: "light"
        val desired = when (mode) {
            "system" -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            "dark" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_NO
        }
        if (AppCompatDelegate.getDefaultNightMode() != desired) {
            AppCompatDelegate.setDefaultNightMode(desired)
        }
    }

    // Kept for existing callers/settings code. These wrappers now use the guarded
    // versions so changing configuration does not blindly recreate the Activity.
    private fun applySavedLanguage() = applySavedLanguageIfNeeded()
    private fun applySavedTheme() = applySavedThemeIfNeeded()

    private fun buildBase() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundResource(R.color.background) }
        setContentView(root)
    }

    private fun shell(title: String, body: View, selected: Int) {
        root.removeAllViews()

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), 0)
            background = android.graphics.drawable.ColorDrawable(getColorCompat(R.color.background))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, dp(2))
        }

        val brand = ImageView(this).apply {
            setImageResource(R.drawable.ic_brand)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).also { it.setMargins(0, 0, dp(10), 0) }
        }
        top.addView(brand)

        top.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            addView(TextView(this@MainActivity).apply {
                text = title
                textSize = 23f
                setTypeface(null, Typeface.BOLD)
                setTextColor(getColorCompat(R.color.text))
                includeFontPadding = false
            })
            addView(TextView(this@MainActivity).apply {
                text = "Simpan sedikit. Tumbuh banyak."
                textSize = 11.5f
                setTextColor(getColorCompat(R.color.muted))
                setPadding(0, dp(2), 0, 0)
            })
        })

        top.addView(iconAction(R.drawable.ic_account, "Profil") { startActivity(Intent(this, ProfileActivity::class.java)) })
        top.addView(iconAction(R.drawable.ic_settings, t("settings")) { showSettings() })
        header.addView(top)

        if (selected in 1..6) header.addView(createTabStrip(selected))
        root.addView(header)

        val bodyHost = FrameLayout(this).apply {
            setBackgroundColor(getColorCompat(R.color.background))
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        body.alpha = 0f
        body.translationX = dp(20 * if (tabIndex == selected - 1) 1 else -1).toFloat()
        bodyHost.addView(body, FrameLayout.LayoutParams(-1, -1))
        root.addView(bodyHost)

        body.animate()
            .alpha(1f)
            .translationX(0f)
            .setDuration(260)
            .setInterpolator(android.view.animation.PathInterpolator(0.22f, 1f, 0.36f, 1f))
            .start()
    }

    private fun iconAction(iconRes: Int, contentDescription: String, action: () -> Unit): ImageButton {
        return ImageButton(this).apply {
            setImageResource(iconRes)
            this.contentDescription = contentDescription
            background = roundedIconBackground()
            setPadding(dp(10), dp(10), dp(10), dp(10))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            imageTintList = android.content.res.ColorStateList.valueOf(getColorCompat(R.color.text))
            setOnClickListener { animatePress(this); action() }
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).also { it.setMargins(dp(4), 0, 0, 0) }
        }
    }

    private fun roundedIconBackground() = GradientDrawable().apply {
        cornerRadius = dp(13).toFloat()
        setColor(getColorCompat(R.color.surface_alt))
        setStroke(dp(1), getColorCompat(R.color.divider))
    }

    private fun animatePress(view: View) {
        view.animate().scaleX(.92f).scaleY(.92f).setDuration(70).withEndAction {
            view.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()
    }

    private fun createTabStrip(selected: Int): HorizontalScrollView {
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
            setPadding(0, dp(10), 0, dp(10))
        }
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val definitions = listOf(
            Triple(1, t("home"), R.drawable.ic_tab_home),
            Triple(2, t("goals"), R.drawable.ic_tab_target),
            Triple(3, t("history"), R.drawable.ic_tab_history),
            Triple(6, "Semua Fitur", R.drawable.ic_hub)
        )
        definitions.forEachIndexed { index, item ->
            val active = item.first == selected
            val tab = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                minimumWidth = dp(82)
                setPadding(dp(9), 0, dp(9), 0)
                background = tabBackground(active)
                setOnClickListener {
                    if (!active) {
                        animatePress(this)
                        selectTab(item.first)
                    }
                }
                contentDescription = item.second
            }
            val icon = ImageView(this).apply {
                setImageResource(item.third)
                imageTintList = android.content.res.ColorStateList.valueOf(
                    getColorCompat(if (active) R.color.primary else R.color.muted)
                )
                layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)).also { it.setMargins(0, 0, dp(6), 0) }
            }
            tab.addView(icon)
            tab.addView(TextView(this).apply {
                text = item.second
                textSize = 12.5f
                setTypeface(null, if (active) Typeface.BOLD else Typeface.NORMAL)
                setTextColor(getColorCompat(if (active) R.color.primary else R.color.muted))
                includeFontPadding = false
            })
            tabs.addView(tab, LinearLayout.LayoutParams(-2, dp(42)).also {
                it.setMargins(if (index == 0) 0 else dp(6), 0, 0, 0)
            })
        }
        scroll.addView(tabs)
        return scroll
    }

    private fun tabBackground(active: Boolean) = GradientDrawable().apply {
        cornerRadius = dp(14).toFloat()
        setColor(getColorCompat(if (active) R.color.surface_alt else R.color.surface))
        setStroke(dp(1), getColorCompat(if (active) R.color.primary_soft else R.color.divider))
    }

    private fun selectTab(itemId: Int) {
        val next = when (itemId) { 1 -> 0; 2 -> 1; 3 -> 2; 6 -> 3; else -> tabIndex }
        val direction = if (next >= tabIndex) 1 else -1
        tabIndex = next
        when (itemId) {
            1 -> showHome(direction)
            2 -> showGoals(direction)
            3 -> showHistory(null, direction)
            6 -> startActivity(Intent(this@MainActivity, FeatureHubActivity::class.java))
        }
    }

    private fun showHome(direction: Int = 1) {
        val scroll = ScrollView(this)
        val box = contentColumn()
        val goals = db.goals()
        val active = goals.filter { it.active }
        val total = db.totalSaved()
        val target = goals.sumOf { it.target }
        box.addView(summaryCard(total, target, active.size, goals.count()))
        box.addView(progressInsightCard())
        box.addView(todayActionCard(active))
        box.addView(featureHubCard())
        box.addView(primaryButton("Insight Menabung") { startActivity(Intent(this@MainActivity, SavingInsightActivity::class.java)) })
        if (goals.isNotEmpty()) box.addView(primaryButton(t("add_saving")) { showQuickSaving(goals) })
        box.addView(coinWalletCard())
        val closest = active.minByOrNull { it.deadline }
        if (closest != null) box.addView(sectionLabel(t("nearest")))
        closest?.let { box.addView(goalCard(it)) }
        box.addView(sectionLabel(t("your_goals")))
        if (goals.isEmpty()) box.addView(emptyState(t("empty_goals"), t("empty_goals_sub")))
        else goals.take(6).forEach { box.addView(goalCard(it)) }
        box.addView(primaryButton(t("create_goal")) { showGoalForm(null) })
        if (!PremiumManager.isPremium(this)) box.addView(freeLimitCard()) else box.addView(premiumMiniCard())
        box.addView(TextView(this).apply { text = "SakuTabung • Menabung fisik, tetap berguna tanpa internet"; textSize = 12f; gravity = 17; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(8), 0, dp(20)) })
        scroll.addView(box)
        shell(t("home"), scroll, 1)
    }

    private fun todayActionCard(active: List<Goal>): View {
        val c = cardContainer()
        c.addView(TextView(this).apply {
            text = "Langkah berikutnya"
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setTextColor(getColorCompat(R.color.text))
        })
        val nearest = active.minByOrNull { it.deadline }
        val message = when {
            nearest == null -> "Buat satu target agar SakuTabung bisa menghitung rencana menabung kamu."
            db.saved(nearest.id) >= nearest.target -> "Target ini sudah tercapai. Kamu bisa membuat target berikutnya."
            else -> {
                val saved = db.saved(nearest.id)
                val remaining = (nearest.target - saved).coerceAtLeast(0L)
                "Target ${nearest.name} masih membutuhkan ${Format.rupiah(remaining)}."
            }
        }
        c.addView(TextView(this).apply {
            text = message
            textSize = 13.5f
            setTextColor(getColorCompat(R.color.muted))
            setPadding(0, dp(6), 0, dp(8))
        })
        if (nearest == null) {
            c.addView(primaryButton("Buat Target") { showGoalForm(null) })
        } else {
            c.addView(primaryButton("Catat Menabung") { showAddSaving(nearest) })
            c.addView(secondaryButton("Lihat Target") { showGoalDetail(nearest.id) })
        }
        return c
    }

    private fun featureHubCard(): View {
        val c = cardContainer()
        c.addView(TextView(this).apply {
            text = "Semua Fitur SakuTabung"
            textSize = 19f
            setTypeface(null, Typeface.BOLD)
            setTextColor(getColorCompat(R.color.text))
        })
        c.addView(TextView(this).apply {
            text = "Satu tempat untuk mencatat tabungan fisik, mengatur target, menghitung kebutuhan menabung, dan melihat progres. Uang tetap disimpan secara fisik oleh kamu; aplikasi hanya mencatat progresnya."
            textSize = 13f
            setTextColor(getColorCompat(R.color.muted))
            setPadding(0, dp(5), 0, dp(10))
        })
        c.addView(primaryButton("Buka Semua Fitur  →") { startActivity(Intent(this@MainActivity, FeatureHubActivity::class.java)) })
        return c
    }

    private fun coinWalletCard(): View = cardContainer().apply {
        addView(TextView(this@MainActivity).apply { text = "${CoinManager.balance(this@MainActivity)} koin"; textSize = 19f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.primary)) })
        addView(TextView(this@MainActivity).apply { text = "Koin adalah poin aplikasi. Gunakan untuk membuka kesempatan pencatatan atau bonus sesuai aturan SakuTabung."; textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(4), 0, dp(8)) })
        addView(secondaryButton("Buka Toko Koin") { startActivity(Intent(this@MainActivity, CoinShopActivity::class.java)) })
    }

    private fun freeFeaturesCard(): View {
        val c = cardContainer()
        c.addView(TextView(this).apply { text = "${t("free_features_title")}"; textSize = 17f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        val features = if (prefs.getString("language", "id") == "en") listOf("Quick saving","Goal images","Smart reminders","Indonesian / English","Light / Dark theme","Home widget","Achievements","Mini games") else listOf("Tabungan cepat","Gambar tujuan","Pengingat pintar","Indonesia / English","Tema terang / gelap","Widget layar utama","Pencapaian","Mini game")
        features.forEach { text -> c.addView(TextView(this).apply { this.text = "• $text"; textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(4), 0, 0) }) }
        return c
    }

    private fun summaryCard(total: Long, target: Long, active: Int, count: Int): View {
        val card = cardContainer()
        card.addView(TextView(this).apply { text = t("total_savings"); textSize = 14f; setTextColor(getColorCompat(R.color.muted)) })
        card.addView(TextView(this).apply { text = Format.rupiah(total); textSize = 28f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)); setPadding(0, dp(3), 0, dp(10)) })
        val percent = if (target > 0) ((total.toDouble() / target) * 100).toInt().coerceIn(0, 100) else 0
        val bar = LinearProgressIndicator(this).apply { max = 100; progress = percent; trackThickness = dp(8); setPadding(0, 0, 0, dp(7)) }
        card.addView(bar)
        card.addView(TextView(this).apply { text = t("active_all", percent, active, count); textSize = 13f; setTextColor(getColorCompat(R.color.muted)) })
        return card
    }


    private fun progressInsightCard(): View {
        val tx = db.transactions()
        val today = LocalDate.now()
        val monthTotal = tx.filter { runCatching { LocalDate.parse(it.date).month == today.month && LocalDate.parse(it.date).year == today.year }.getOrDefault(false) }
            .sumOf { it.amount }
        val dates = tx.mapNotNull { runCatching { LocalDate.parse(it.date) }.getOrNull() }.distinct().sortedDescending()
        var streak = 0L
        var cursor = today
        if (dates.isNotEmpty()) {
            if (dates.first() == today || dates.first() == today.minusDays(1)) {
                cursor = dates.first()
                streak = 1
                for (i in 1 until dates.size) {
                    if (dates[i] == cursor.minusDays(1)) { streak++; cursor = dates[i] } else break
                }
            }
        }
        val recent7 = tx.filter { runCatching { !LocalDate.parse(it.date).isBefore(today.minusDays(6)) }.getOrDefault(false) }.sumOf { it.amount }
        val c = cardContainer()
        c.addView(TextView(this).apply { text = t("progress"); textSize = 17f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, 0) }
        row.addView(insightItem(t("month"), Format.rupiah(monthTotal)), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(insightItem(t("days7"), Format.rupiah(recent7)), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(insightItem(t("streak"), if (streak > 0) "${streak}h" else t("start_today")), LinearLayout.LayoutParams(0, -2, 1f))
        c.addView(row)
        c.addView(TextView(this).apply { text = if (streak > 0) t("streak_good") else t("streak_start"); textSize = 12.5f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(12), 0, 0) })
        c.addView(secondaryButton("Lihat Kalender Menabung") { showSavingCalendar() })
        return c
    }

    private fun insightItem(label: String, value: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(TextView(this@MainActivity).apply { text = label; textSize = 12f; setTextColor(getColorCompat(R.color.muted)) })
        addView(TextView(this@MainActivity).apply { text = value; textSize = 14f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)); setPadding(0, dp(3), 0, 0) })
    }

    private fun showSavingCalendar() {
        val today = LocalDate.now()
        val tx = db.transactions()
        val byDate = tx.groupBy { it.date }.mapValues { (_, items) -> items.sumOf { it.amount } }
        val lines = buildString {
            append("Kalender menabung ${today.month.name.lowercase().replaceFirstChar { it.uppercase() }} ${today.year}\n\n")
            val first = today.withDayOfMonth(1)
            val days = today.lengthOfMonth()
            for (day in 1..days) {
                val d = first.withDayOfMonth(day)
                if (!d.isAfter(today)) {
                    val amount = byDate[d.toString()] ?: 0L
                    append("%02d  %s\n".format(day, if (amount > 0) "+ ${Format.rupiah(amount)}" else "—"))
                }
            }
        }
        AlertDialog.Builder(this).setTitle("Kalender Menabung").setMessage(lines).setPositiveButton("Tutup", null).show()
    }

    private fun showQuickSaving(goals: List<Goal>) {
        val names = goals.map { it.name }.toTypedArray()
        AlertDialog.Builder(this).setTitle(t("choose_goal"))
            .setItems(names) { _, which -> showAddSaving(goals[which]) }
            .setNegativeButton(t("cancel"), null).show()
    }

    private fun smartInsightCard(): View {
        val tx = db.transactions()
        val total = tx.sumOf { it.amount }
        val avg = if (tx.isEmpty()) 0L else total / tx.size
        val biggest = tx.maxOfOrNull { it.amount } ?: 0L
        val completed = db.goals().count { !it.active && db.saved(it.id) >= it.target }
        val c = cardContainer()
        c.addView(TextView(this).apply { text = t("smart_insight_title"); textSize = 17f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, 0) }
        row.addView(insightItem(t("avg_saving"), Format.rupiah(avg)), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(insightItem(t("biggest_saving"), Format.rupiah(biggest)), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(insightItem(t("goals_done"), completed.toString()), LinearLayout.LayoutParams(0, -2, 1f))
        c.addView(row)
        c.addView(TextView(this).apply { text = if (tx.isEmpty()) t("insight_empty") else t("insight_ready"); textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(10), 0, 0) })
        return c
    }

    private fun smartGoalTeaserCard(): View = cardContainer().apply {
        addView(TextView(this@MainActivity).apply { text = "Smart Goal"; textSize = 17f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        val active = db.goals().filter { it.active }
        val nearest = active.minByOrNull { it.deadline }
        val msg = if (nearest == null) "Hitung kebutuhan tabungan harian untuk target baru." else {
            val st = Calculator.stats(nearest, db.saved(nearest.id))
            "${nearest.name}: ${Format.rupiah(st.daily)}/hari untuk mengejar target."
        }
        addView(TextView(this@MainActivity).apply { text = msg; textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(5), 0, dp(8)) })
        addView(secondaryButton("Buka Smart Goal") { startActivity(Intent(this@MainActivity, SmartGoalActivity::class.java)) })
    }

    private fun challengeCard(): View {
        val today = LocalDate.now()
        val tx = db.transactions()
        val savedToday = tx.filter { it.date == today.toString() }.sumOf { it.amount }
        val goal = 10000L
        val progressPct = (savedToday.toDouble() / goal * 100).toInt().coerceIn(0, 100)
        val c = cardContainer()
        c.addView(TextView(this).apply { text = t("today_challenge"); textSize = 17f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        c.addView(TextView(this).apply { text = if (savedToday >= goal) t("challenge_done", Format.rupiah(savedToday)) else t("challenge_target", Format.rupiah(goal), Format.rupiah(savedToday)); textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(5), 0, dp(8)) })
        c.addView(LinearProgressIndicator(this).apply { max = 100; progress = progressPct; trackThickness = dp(7) })
        c.addView(secondaryButton(if (savedToday >= goal) t("view_progress") else t("start_saving")) {
            val goals = db.goals().filter { it.active }
            if (goals.isNotEmpty()) showQuickSaving(goals) else showGoalForm(null)
        })
        return c
    }

    private fun achievementCard(): View {
        val tx = db.transactions()
        val goals = db.goals()
        val total = tx.sumOf { it.amount }
        val streak = calculateStreak(tx)
        val unlocked = mutableListOf<String>()
        if (tx.isNotEmpty()) unlocked += "${t("first_achievement")}"
        if (total >= 100000) unlocked += "${t("hundred_k")}"
        if (total >= 1000000) unlocked += "${t("one_m")}"
        if (streak >= 7) unlocked += "${t("seven_days")}"
        if (streak >= 30) unlocked += "${t("thirty_days")}"
        if (goals.any { !it.active && db.saved(it.id) >= it.target }) unlocked += "${t("goal_achievement")}"
        val c = cardContainer()
        c.addView(TextView(this).apply { text = t("achievement"); textSize = 17f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        c.addView(TextView(this).apply { text = if (unlocked.isEmpty()) t("no_badges") else unlocked.joinToString("•"); textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(6), 0, dp(4)) })
        c.addView(secondaryButton(t("view_all")) { showAchievements() })
        return c
    }

    private fun calculateStreak(tx: List<Transaction>): Int {
        val dates = tx.mapNotNull { runCatching { LocalDate.parse(it.date) }.getOrNull() }.distinct().sortedDescending()
        if (dates.isEmpty()) return 0
        val today = LocalDate.now()
        if (dates.first() != today && dates.first() != today.minusDays(1)) return 0
        var count = 1
        var cursor = dates.first()
        for (i in 1 until dates.size) {
            if (dates[i] == cursor.minusDays(1)) { count++; cursor = dates[i] } else break
        }
        return count
    }

    private fun showAchievements() {
        val tx = db.transactions()
        val goals = db.goals()
        val total = tx.sumOf { it.amount }
        val streak = calculateStreak(tx)
        val items = listOf(
            "" to (t("first_achievement") to (tx.isNotEmpty())),
            "" to (t("hundred_k") to (total >= 100000)),
            "" to (t("one_m") to (total >= 1000000)),
            "" to (t("seven_days") to (streak >= 7)),
            "" to (t("thirty_days") to (streak >= 30)),
            "" to (t("goal_achievement") to goals.any { !it.active && db.saved(it.id) >= it.target })
        )

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(4))
        }
        items.forEachIndexed { index, item ->
            val icon = item.first
            val name = item.second.first
            val unlocked = item.second.second
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setBackgroundResource(if (unlocked) R.drawable.bg_success else R.drawable.bg_card)
                alpha = 0f
                scaleX = 0.82f
                scaleY = 0.82f
            }
            val badge = TextView(this).apply {
                text = if (unlocked) icon else ""
                textSize = 27f
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(50), dp(50))
            }
            val textBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            textBox.addView(TextView(this).apply {
                text = name
                textSize = 16f
                setTypeface(null, Typeface.BOLD)
                setTextColor(getColorCompat(R.color.text))
            })
            textBox.addView(TextView(this).apply {
                text = if (unlocked) t("unlocked") else t("locked")
                textSize = 12.5f
                setTextColor(getColorCompat(R.color.muted))
                setPadding(0, dp(2), 0, 0)
            })
            row.addView(badge)
            row.addView(textBox, LinearLayout.LayoutParams(0, -2, 1f))
            box.addView(row, LinearLayout.LayoutParams(-1, dp(76)).also { it.setMargins(0, 0, 0, dp(8)) })

            val fade = ObjectAnimator.ofFloat(row, View.ALPHA, 0f, 1f)
            val sx = ObjectAnimator.ofFloat(row, View.SCALE_X, 0.82f, 1f)
            val sy = ObjectAnimator.ofFloat(row, View.SCALE_Y, 0.82f, 1f)
            AnimatorSet().apply {
                playTogether(fade, sx, sy)
                duration = 420
                startDelay = index * 75L
                interpolator = OvershootInterpolator(1.2f)
            }.start()
        }

        val scroll = ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this)
            .setTitle(t("your_achievements"))
            .setView(scroll)
            .setPositiveButton(t("close"), null)
            .show()
    }

    private fun gameTeaserCard(): View {
        val c = cardContainer()
        val limit = GameLimitManager.getLimit(this)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(TextView(this).apply { text = "${t("game_title")}"; textSize = 16f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        texts.addView(TextView(this).apply { text = t("games_left", limit); textSize = 13f; setTextColor(getColorCompat(R.color.muted)) })
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply {
            text = t("open"); setAllCaps(false); textSize = 14f
            setOnClickListener { startActivity(Intent(this@MainActivity, GameHubActivity::class.java)) }
        }, LinearLayout.LayoutParams(dp(92), dp(48)))
        c.addView(row)
        return c
    }

    private fun showGoals(direction: Int = 1) {
        val scroll = ScrollView(this)
        val box = contentColumn()
        val goals = db.goals()
        if (goals.isEmpty()) box.addView(emptyState(t("empty_goals_old"), t("create_first_goal")))
        else {
            val sort = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf(t("sort_progress"), t("sort_deadline"), t("sort_name")))
            }
            box.addView(sort, LinearLayout.LayoutParams(-1, dp(52)).also { it.setMargins(0, 0, 0, dp(8)) })
            val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            fun refreshGoals() {
                list.removeAllViews()
                val ordered = when (sort.selectedItemPosition) {
                    0 -> goals.sortedByDescending { Calculator.stats(it, db.saved(it.id)).progress }
                    1 -> goals.sortedBy { it.deadline }
                    else -> goals.sortedBy { it.name.lowercase() }
                }
                ordered.forEach { list.addView(goalCard(it)) }
            }
            sort.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) = refreshGoals()
            }
            box.addView(list)
        }
        box.addView(primaryButton(t("create_goal")) { showGoalForm(null) })
        scroll.addView(box)
        shell(t("goals"), scroll, 2)
    }

    private fun goalCard(g: Goal): View {
        val stats = Calculator.stats(g, db.saved(g.id))
        val card = cardContainer()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = 16 }
        row.addView(goalImageView(g, 52))
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        texts.addView(TextView(this).apply { text = g.name; textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        texts.addView(TextView(this).apply { text = "${Format.rupiah(stats.saved)} / ${Format.rupiah(g.target)}"; textSize = 14f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(2), 0, 0) })
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(TextView(this).apply { text = "${stats.progress}%"; textSize = 16f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.primary)) })
        card.addView(row)
        val bar = LinearProgressIndicator(this).apply { max = 100; progress = stats.progress; trackThickness = dp(7); setPadding(0, dp(10), 0, dp(6)) }
        card.addView(bar)
        val detail = if (stats.isCompleted) t("goal_done") else if (stats.isOverdue) t("goal_overdue", Format.rupiah(stats.remaining)) else t("days_left", stats.daysLeft, Format.rupiah(stats.daily))
        card.addView(TextView(this).apply { text = detail; textSize = 13f; setTextColor(if (stats.isCompleted) getColorCompat(R.color.primary) else getColorCompat(R.color.muted)) })
        card.setOnClickListener { showGoalDetail(g.id) }
        return card
    }

    private fun goalImageView(g: Goal, size: Int): ImageView {
        val iv = ImageView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)); scaleType = ImageView.ScaleType.CENTER_CROP; setImageResource(R.drawable.ic_pig) }
        prefs.getString("goal_image_${g.id}", null)?.let { uri -> runCatching { iv.setImageURI(Uri.parse(uri)) } }
        return iv
    }

    private fun showGoalDetail(id: Long) {
        val g = db.goal(id) ?: return
        val stats = Calculator.stats(g, db.saved(id))
        val scroll = ScrollView(this)
        val box = contentColumn()
        val hero = cardContainer()
        hero.gravity = Gravity.CENTER_HORIZONTAL
        hero.addView(goalImageView(g, 84))
        hero.addView(TextView(this).apply { text = g.name; textSize = 23f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)); gravity = 17; setPadding(0, dp(8), 0, 0) })
        hero.addView(TextView(this).apply { text = "${stats.progress}%"; textSize = 34f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.primary)); gravity = 17; setPadding(0, dp(4), 0, dp(4)) })
        hero.addView(LinearProgressIndicator(this).apply { max = 100; progress = stats.progress; trackThickness = dp(10); layoutParams = LinearLayout.LayoutParams(-1, dp(12)) })
        hero.addView(TextView(this).apply { text = t("from", Format.rupiah(stats.saved), Format.rupiah(g.target)); textSize = 15f; gravity = 17; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(8), 0, 0) })
        box.addView(hero)
        val info = cardContainer()
        info.addView(TextView(this).apply { text = t("remaining", Format.rupiah(stats.remaining)); textSize = 16f; setTextColor(getColorCompat(R.color.text)); setPadding(0, 0, 0, dp(8)) })
        info.addView(TextView(this).apply { text = t("deadline", Format.date(g.deadline)) + "\n" + t("time_left", stats.daysLeft) + "\n" + t("daily_need", Format.rupiah(stats.daily)) + "\n" + t("weekly_need", Format.rupiah(stats.weekly)); textSize = 14f; setTextColor(getColorCompat(R.color.muted)) })
        box.addView(info)
        if (stats.isCompleted) box.addView(successBanner(t("auto_stop")))
        else if (stats.isOverdue) box.addView(successBanner(t("overdue")))
        box.addView(primaryButton(t("add_saving")) { showAddSaving(g) })
        box.addView(secondaryButton(t("view_history")) { showHistory(g.id) })
        box.addView(secondaryButton(t("edit_goal_title")) { showGoalForm(g) })
        box.addView(dangerButton(t("delete") + "" + t("goals")) { confirmDelete(g) })
        scroll.addView(box)
        shell(g.name, scroll, 2)
    }

    private fun showGoalForm(existing: Goal?, template: Pair<String, Long>? = null) {
        val form = contentColumn()
        selectedGoalImageUri = existing?.let { prefs.getString("goal_image_${it.id}", null)?.let(Uri::parse) }
        val imageLabel = TextView(this).apply { text = "Gambar tujuan menabung (opsional)"; textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(4), 0, dp(6)) }
        val image = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(150))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setImageResource(R.drawable.ic_pig)
            selectedGoalImageUri?.let { setImageURI(it); scaleType = ImageView.ScaleType.CENTER_CROP }
            background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(getColorCompat(R.color.background)) }
            setOnClickListener { imagePicker.launch(arrayOf("image/*")) }
        }
        pendingGoalImage = image
        val pickImage = secondaryButton(t("pick_image")) { imagePicker.launch(arrayOf("image/*")) }
        val clearImage = secondaryButton(t("clear_image")) { selectedGoalImageUri = null; image.setImageResource(R.drawable.ic_pig); image.scaleType = ImageView.ScaleType.CENTER_INSIDE }
        form.addView(imageLabel); form.addView(image); form.addView(pickImage); form.addView(clearImage)
        val name = input(t("goal_name"), template?.first ?: existing?.name.orEmpty())
        val target = input(t("target_amount"), template?.second?.toString() ?: existing?.target?.toString().orEmpty(), true)
        val start = input(t("start_date"), existing?.startDate ?: LocalDate.now().toString())
        val deadline = input(t("deadline_field"), existing?.deadline ?: LocalDate.now().plusDays(30).toString())
        val freq = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf(t("daily"), t("weekly"))); setSelection(if (existing?.frequency?.contains("minggu", true) == true || existing?.frequency?.contains("week", true) == true) 1 else 0) }
        val time = input(t("reminder_time"), existing?.let { "%02d:%02d".format(it.reminderHour, it.reminderMinute) } ?: "20:00")
        listOf(name, target, start, deadline).forEach { form.addView(it) }
        form.addView(TextView(this).apply { text = t("reminder_frequency"); textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(8), 0, dp(3)) })
        form.addView(freq, LinearLayout.LayoutParams(-1, dp(54)))
        form.addView(time)
        start.setOnClickListener { datePicker(start) }; deadline.setOnClickListener { datePicker(deadline) }; time.setOnClickListener { timePicker(time) }
        AlertDialog.Builder(this).setTitle(if (existing == null) t("create_goal_title") else t("edit_goal_title")).setView(form).setNegativeButton(t("cancel"), null).setPositiveButton(t("save"), null).create().also { dialog ->
            dialog.setOnShowListener {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    try {
                        val n = name.text.toString().trim()
                        val t = target.text.toString().filter(Char::isDigit).toLongOrNull() ?: 0L
                        val sd = LocalDate.parse(start.text.toString())
                        val ed = LocalDate.parse(deadline.text.toString())
                        require(n.isNotBlank() && t > 0 && !ed.isBefore(sd))
                        val hm = time.text.toString().split(":"); val h = hm.getOrNull(0)?.toIntOrNull() ?: 20; val m = hm.getOrNull(1)?.toIntOrNull() ?: 0
                        require(h in 0..23 && m in 0..59)
                        val goal = Goal(existing?.id ?: 0L, n, t, sd.toString(), ed.toString(), freq.selectedItem.toString(), h, m, existing?.active ?: true)
                        val id = if (existing == null) db.insertGoal(goal) else { db.updateGoal(goal); goal.id }
                        if (selectedGoalImageUri != null) prefs.edit().putString("goal_image_$id", selectedGoalImageUri.toString()).apply() else prefs.edit().remove("goal_image_$id").apply()
                        if (goal.active) ReminderScheduler.schedule(this, id, h, m, goal.frequency) else ReminderScheduler.cancel(this, id)
                        dialog.dismiss(); if (existing == null) showGoals() else showGoalDetail(id)
                    } catch (_: Exception) { Toast.makeText(this, t("invalid_goal"), Toast.LENGTH_SHORT).show() }
                }
            }
        }.show()
    }

    private fun showAddSaving(g: Goal) {
        if (!PremiumManager.isPremium(this) && SavingLimitManager.available(this) <= 0) {
            showPremiumLimitDialog()
            return
        }
        val form = contentColumn()
        val amount = input(t("amount"), "", true)
        val date = input(t("date"), LocalDate.now().toString())
        val note = input(t("note"), "")
        form.addView(amount); form.addView(date); form.addView(note)
        date.setOnClickListener { datePicker(date) }
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = 17 }
        listOf(10000L, 20000L, 50000L).forEach { value -> quick.addView(secondaryButton(Format.rupiah(value)) { amount.setText(value.toString()) }, LinearLayout.LayoutParams(0, dp(50), 1f).also { it.setMargins(dp(3), 0, dp(3), 0) }) }
        form.addView(quick)
        AlertDialog.Builder(this).setTitle(t("add_saving_title")).setView(form).setNegativeButton(t("cancel"), null).setPositiveButton(t("save"), null).create().also { dialog ->
            dialog.setOnShowListener {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    try {
                        val a = amount.text.toString().filter(Char::isDigit).toLongOrNull() ?: 0L
                        val d = LocalDate.parse(date.text.toString())
                        require(a > 0 && !d.isBefore(LocalDate.parse(g.startDate)) && !d.isAfter(LocalDate.now()))
                        if (!PremiumManager.isPremium(this) && !SavingLimitManager.consume(this)) { showPremiumLimitDialog(); return@setOnClickListener }
                        val beforeAchievements = achievementKeys()
                        try {
                            db.addTransaction(Transaction(0, g.id, a, d.toString(), note.text.toString().trim()))
                        } catch (dbError: Exception) {
                            if (!PremiumManager.isPremium(this)) SavingLimitManager.refund(this)
                            throw dbError
                        }
                        runCatching {
                            AppWidgetManager.getInstance(this).updateAppWidget(android.content.ComponentName(this, SakuTabungWidget::class.java), android.widget.RemoteViews(packageName, R.layout.widget_sakutabung).apply { setTextViewText(R.id.widget_title, "SakuTabung"); setTextViewText(R.id.widget_total, Format.rupiah(db.totalSaved())); setTextViewText(R.id.widget_goals, "${db.activeCount()} target aktif") })
                        }
                        val earned = GameLimitManager.award(this, a)
                        RewardManager.addSavingXp(this, 20)
                        val newSaved = db.saved(g.id)
                        runCatching { if (newSaved >= g.target) ReminderScheduler.cancel(this, g.id) else ReminderScheduler.schedule(this, g.id, g.reminderHour, g.reminderMinute, g.frequency) }
                        dialog.dismiss()
                        Toast.makeText(this, t("saved", earned), Toast.LENGTH_SHORT).show()
                        val newlyUnlocked = achievementKeys() - beforeAchievements
                        if (newlyUnlocked.isNotEmpty() && prefs.getBoolean("achievement_popup", true)) {
                            gIdForPopup = g.id
                            showAchievementUnlocked(newlyUnlocked.first())
                        } else {
                            showGoalDetail(g.id)
                        }
                    } catch (_: Exception) { Toast.makeText(this, t("invalid_saving"), Toast.LENGTH_SHORT).show() }
                }
            }
        }.show()
    }

    private fun showHistory(goalId: Long? = null, direction: Int = 1) {
        val scroll = ScrollView(this); val box = contentColumn()
        val search = input(t("search"), "")
        val allTransactions = db.transactions(goalId)
        // Avoid an N+1 database query for every history card. This was especially
        // expensive after returning to History on slower Android 10 devices.
        val goalNames = db.goals().associate { it.id to it.name }
        box.addView(search)
        box.addView(historySummary(allTransactions))
        box.addView(secondaryButton("Ringkasan Bulan Ini") { showMonthlySummary(goalId) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refresh() {
            list.removeAllViews()
            val q = search.text.toString().trim().lowercase()
            val tx = allTransactions.filter { q.isBlank() || it.note.lowercase().contains(q) || goalNames[it.goalId].orEmpty().lowercase().contains(q) }
            if (tx.isEmpty()) list.addView(emptyState(t("empty_tx"), t("empty_tx_sub")))
            tx.forEach { item -> list.addView(transactionCard(item, goalNames[item.goalId])) }
        }
        search.addTextChangedListener(SimpleTextWatcher { refresh() }); box.addView(list); refresh(); scroll.addView(box); shell(t("history"), scroll, 3)
    }

    private fun historySummary(tx: List<Transaction>): View {
        val now = LocalDate.now()
        val month = tx.filter { runCatching { val d = LocalDate.parse(it.date); d.year == now.year && d.month == now.month }.getOrDefault(false) }
        val c = cardContainer()
        c.addView(TextView(this).apply { text = "Ringkasan catatan"; textSize = 16f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, 0) }
        row.addView(insightItem("Bulan ini", Format.rupiah(month.sumOf { it.amount })), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(insightItem("Catatan", month.size.toString()), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(insightItem("Hari aktif", month.map { it.date }.distinct().size.toString()), LinearLayout.LayoutParams(0, -2, 1f))
        c.addView(row)
        return c
    }

    private fun showMonthlySummary(goalId: Long?) {
        val now = LocalDate.now()
        val tx = db.transactions(goalId).filter { runCatching { val d = LocalDate.parse(it.date); d.year == now.year && d.month == now.month }.getOrDefault(false) }
        val total = tx.sumOf { it.amount }
        val avg = if (tx.isEmpty()) 0L else total / tx.size
        val days = tx.map { it.date }.distinct().size
        val top = tx.maxByOrNull { it.amount }?.amount ?: 0L
        AlertDialog.Builder(this)
            .setTitle("Ringkasan ${now.month.name.lowercase().replaceFirstChar { it.uppercase() }} ${now.year}")
            .setMessage("Tercatat: ${Format.rupiah(total)}\nJumlah catatan: ${tx.size}\nHari menabung: $days\nRata-rata per catatan: ${Format.rupiah(avg)}\nCatatan terbesar: ${Format.rupiah(top)}")
            .setPositiveButton("Tutup", null)
            .show()
    }

    private fun transactionCard(t: Transaction, goalName: String? = null): View {
        val c = cardContainer()
        c.addView(TextView(this).apply { text = "${Format.date(t.date)} • ${goalName ?: t("goals")}"; textSize = 13f; setTextColor(getColorCompat(R.color.muted)) })
        c.addView(TextView(this).apply { text = "+ ${Format.rupiah(t.amount)}"; textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.primary)); setPadding(0, dp(4), 0, 0) })
        if (t.note.isNotBlank()) c.addView(TextView(this).apply { text = t.note; textSize = 14f; setTextColor(getColorCompat(R.color.text)); setPadding(0, dp(3), 0, 0) })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        actions.addView(secondaryButton("Edit") { showEditTransaction(t) }, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(secondaryButton("Hapus Catatan") {
            AlertDialog.Builder(this).setTitle("Hapus catatan?").setMessage("Catatan ini akan dihapus dari progres target. Uang fisik kamu tidak terpengaruh.")
                .setNegativeButton(t("cancel"), null).setPositiveButton("Hapus") { _, _ ->
                    db.deleteTransaction(t.id)
                    showHistory()
                }.show()
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        c.addView(actions)
        return c
    }

    private fun showEditTransaction(tx: Transaction) {
        val goals = db.goals()
        if (goals.isEmpty()) return
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), 0, dp(4), 0) }
        val amount = input("Nominal menabung", tx.amount.toString(), true)
        val date = input("Tanggal (YYYY-MM-DD)", tx.date)
        val note = input("Catatan", tx.note)
        val goalNames = goals.map { it.name }.toTypedArray()
        val spinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, goalNames); setSelection(goals.indexOfFirst { it.id == tx.goalId }.coerceAtLeast(0)) }
        box.addView(TextView(this).apply { text = "Target"; textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, 0, 0, dp(4)) })
        box.addView(spinner, LinearLayout.LayoutParams(-1, dp(54)))
        box.addView(amount); box.addView(date); box.addView(note)
        AlertDialog.Builder(this).setTitle("Edit Catatan Menabung").setView(box).setNegativeButton(t("cancel"), null).setPositiveButton(t("save"), null).create().also { dialog ->
            dialog.setOnShowListener {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val value = amount.text.toString().filter(Char::isDigit).toLongOrNull() ?: 0L
                    val chosen = goals[spinner.selectedItemPosition]
                    val parsed = runCatching { LocalDate.parse(date.text.toString()) }.getOrNull()
                    if (value <= 0 || parsed == null || parsed.isAfter(LocalDate.now()) || note.text.toString().length > 200) {
                        Toast.makeText(this, "Nominal/tanggal/catatan tidak valid", Toast.LENGTH_SHORT).show(); return@setOnClickListener
                    }
                    try {
                        db.updateTransaction(tx.copy(goalId = chosen.id, amount = value, date = parsed.toString(), note = note.text.toString().trim()))
                        dialog.dismiss(); showHistory()
                    } catch (_: Exception) { Toast.makeText(this, "Catatan tidak dapat diperbarui", Toast.LENGTH_SHORT).show() }
                }
            }
        }.show()
    }

    private fun lockApp() {
        val biometricAvailable = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
        val options = if (biometricAvailable) arrayOf(t("use_biometric"), t("use_pin")) else arrayOf(t("use_pin"))
        AlertDialog.Builder(this).setTitle(t("app_locked")).setMessage(t("unlock_message")).setItems(options) { _, which ->
            if (biometricAvailable && which == 0) authenticateBiometric() else pinDialog(false)
        }.setCancelable(false).show()
    }

    private fun authenticateBiometric() {
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { unlocked = true; requestNotificationIfNeeded(); openRequestedScreenOnce() }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { Toast.makeText(this@MainActivity, errString, Toast.LENGTH_SHORT).show(); lockApp() }
        })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("SakuTabung").setSubtitle(t("unlock_message")).setNegativeButtonText(t("use_pin")).build())
    }

    private fun pinDialog(disable: Boolean) {
        val input = EditText(this).apply { inputType = 2; hint = "PIN 4-6 digit" }
        AlertDialog.Builder(this).setTitle(if (disable) t("disable_pin") else t("enter_pin")).setView(input).setNegativeButton(t("cancel"), null).setPositiveButton(t("unlock")) { _, _ ->
            if (SecurityManager.verify(this, input.text.toString())) { if (disable) { SecurityManager.disable(this); Toast.makeText(this, t("pin_disabled"), Toast.LENGTH_SHORT).show(); showSettings() } else { unlocked = true; requestNotificationIfNeeded(); openRequestedScreenOnce() } } else Toast.makeText(this, t("wrong_pin"), Toast.LENGTH_SHORT).show()
        }.setCancelable(!disable).show()
    }

    private fun securitySettings(): View = cardContainer().apply {
        addView(TextView(this@MainActivity).apply { text = t("security_title"); textSize = 17f; setTypeface(null, Typeface.BOLD) })
        addView(TextView(this@MainActivity).apply { text = t("security_desc"); textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0,dp(4),0,dp(8)) })
        addView(primaryButton(if (SecurityManager.enabled(this@MainActivity)) t("disable_pin") else t("set_pin")) {
            if (SecurityManager.enabled(this@MainActivity)) { pinDialog(true) } else {
                val input=EditText(this@MainActivity).apply { inputType=2; hint="PIN 4-6 digit" }
                AlertDialog.Builder(this@MainActivity).setTitle(t("set_pin")).setView(input).setNegativeButton(t("cancel"),null).setPositiveButton(t("save")){_,_-> val pin=input.text.toString(); if(pin.length in 4..6 && pin.all(Char::isDigit)){SecurityManager.setPin(this@MainActivity,pin); Toast.makeText(this@MainActivity,t("pin_enabled"),Toast.LENGTH_SHORT).show(); showSettings()} else Toast.makeText(this@MainActivity,t("pin_invalid"),Toast.LENGTH_SHORT).show() }.show()
            }
        })
        val bio=Switch(this@MainActivity).apply { text=t("biometric"); isChecked=prefs.getBoolean("biometric_enabled",true); isEnabled=BiometricManager.from(this@MainActivity).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)==BiometricManager.BIOMETRIC_SUCCESS; setOnCheckedChangeListener{_,v->prefs.edit().putBoolean("biometric_enabled",v).apply()} }
        addView(bio)
    }

    private fun dataSettings(): View = cardContainer().apply {
        addView(TextView(this@MainActivity).apply { text=t("data_title"); textSize=17f; setTypeface(null,Typeface.BOLD) })
        addView(TextView(this@MainActivity).apply { text=t("data_desc"); textSize=13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0,dp(4),0,dp(8)) })
        addView(primaryButton(t("export_data")) { val data=BackupManager.export(this@MainActivity); startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/json";putExtra(Intent.EXTRA_TEXT,data)},t("export_data"))) })
        addView(secondaryButton(t("restore_data")) { backupPicker.launch(arrayOf("application/json","text/plain","*/*")) })
    }

    private fun themeSettings(): View = cardContainer().apply {
        addView(TextView(this@MainActivity).apply { text=t("theme_title"); textSize=17f; setTypeface(null,Typeface.BOLD) })
        val spinner=Spinner(this@MainActivity).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf(t("theme_system"),t("theme_light"),t("theme_dark"))); val mode=prefs.getString("theme","light"); setSelection(if(mode=="system")0 else if(mode=="dark")2 else 1); setOnItemSelectedListener(object:AdapterView.OnItemSelectedListener{var first=true;override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){if(first){first=false;return};val m=when(pos){0->"system";2->"dark";else->"light"};prefs.edit().putString("theme",m).putBoolean("dark_mode",m=="dark").apply();AppCompatDelegate.setDefaultNightMode(when(m){"system"->AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM;"dark"->AppCompatDelegate.MODE_NIGHT_YES;else->AppCompatDelegate.MODE_NIGHT_NO})}}) }
        addView(spinner,LinearLayout.LayoutParams(-1,dp(52)).also{it.setMargins(0,dp(8),0,0)})
    }

    private fun showSettings(direction: Int = 1) {
        val box = contentColumn()
        box.addView(accountCard())
        box.addView(themeSettings())
        box.addView(securitySettings())
        box.addView(dataSettings())
        val language = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Bahasa Indonesia", "English"))
            setSelection(if ((prefs.getString("language", "id") ?: "id") == "en") 1 else 0)
            setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
                private var first = true
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (first) { first = false; return }
                    val lang = if (position == 1) "en" else "id"
                    prefs.edit().putString("language", lang).apply()
                    if (AppCompatDelegate.getApplicationLocales().toLanguageTags() != lang) AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(lang))
                }
            })
        }
        box.addView(cardContainer().apply {
            addView(TextView(this@MainActivity).apply { text = t("language"); textSize = 16f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
            addView(language, LinearLayout.LayoutParams(-1, dp(52)).also { it.setMargins(0, dp(8), 0, 0) })
        })
        val popup = Switch(this).apply { text = t("popup"); textSize = 16f; isChecked = prefs.getBoolean("achievement_popup", true); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("achievement_popup", checked).apply() } }
        val confetti = Switch(this).apply { text = t("confetti"); textSize = 16f; isChecked = prefs.getBoolean("confetti", true); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("confetti", checked).apply() } }
        val sound = Switch(this).apply { text = t("sound"); textSize = 16f; isChecked = prefs.getBoolean("achievement_sound", false); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("achievement_sound", checked).apply(); if (checked) playAchievementSound() } }
        box.addView(cardContainer().apply { addView(popup); addView(confetti); addView(sound) })
        box.addView(primaryButton(t("enable_notifications")) { requestNotificationIfNeeded(force = true) })
        box.addView(secondaryButton("Developer / Creator • Chat & Support") { startActivity(Intent(this, DeveloperActivity::class.java)) })
        box.addView(cardContainer().apply { addView(TextView(this@MainActivity).apply { text = t("about"); textSize = 14f; setTextColor(getColorCompat(R.color.text)) }) })
        shell(t("settings"), ScrollView(this).apply { addView(box) }, 4)
    }

    private fun socialRewardCard(): View {
        val c = cardContainer()
        c.addView(TextView(this).apply { text = t("social_reward_title"); textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        c.addView(TextView(this).apply { text = t("social_reward_desc"); textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(5), 0, dp(8)) })
        val remaining = PremiumManager.socialDaysRemaining(this)
        val verified = PremiumManager.socialVerifiedAt(this) > 0L
        c.addView(TextView(this).apply { text = if (verified) t("social_reward_progress", remaining) else t("social_reward_not_started"); textSize = 13f; setTextColor(getColorCompat(R.color.primary)); setPadding(0, 0, 0, dp(8)) })
        c.addView(secondaryButton(t("social_open_youtube")) { openUrl("https://www.youtube.com/") })
        c.addView(secondaryButton(t("social_open_tiktok")) { openUrl("https://www.tiktok.com/") })
        c.addView(secondaryButton(t("social_open_instagram")) { openUrl("https://www.instagram.com/") })
        if (!verified) c.addView(primaryButton(t("social_start")) { PremiumManager.startSocialChallenge(this); Toast.makeText(this, t("social_online_required"), Toast.LENGTH_LONG).show(); showSettings() })
        else if (remaining == 0L && PremiumManager.canRewardFromSocial(this)) c.addView(primaryButton(t("social_claim")) { Toast.makeText(this, t("social_online_required"), Toast.LENGTH_LONG).show() })
        return c
    }

    private fun openUrl(url: String) {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            .onFailure { Toast.makeText(this, t("social_link_failed"), Toast.LENGTH_SHORT).show() }
    }

    private fun accountCard(): View {
        val c = cardContainer()
        val linked = PremiumManager.email(this)
        val developer = PremiumManager.isDeveloper(this)
        c.addView(TextView(this).apply { text = if (developer) t("developer_mode") else t("account_title"); textSize = 19f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(if (developer) R.color.primary else R.color.text)) })
        c.addView(TextView(this).apply { text = linked?.let { "$it${if (developer)" • ${t("developer_creator")}"else""}" } ?: t("account_desc"); textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(5), 0, dp(10)) })
        c.addView(primaryButton(if (linked != null) t("sign_out") else t("google_login")) { if (linked != null) { PremiumManager.signOut(this); showSettings() } else googleLogin() })
        return c
    }

    private fun googleLogin() {
        runCatching {
            val accounts = AccountManager.get(this).runCatching { getAccountsByType("com.google") }.getOrDefault(emptyArray())
            if (accounts.isEmpty()) throw IllegalStateException("NO_GOOGLE")
            val names = accounts.map { it.name }.toTypedArray()
            AlertDialog.Builder(this).setTitle(t("choose_google")).setItems(names) { _, which ->
                PremiumManager.login(this, names[which])
                Toast.makeText(this, t("account_title") + "terhubung", Toast.LENGTH_SHORT).show(); showSettings()
            }.setNegativeButton(t("cancel"), null).show()
        }.onFailure { Toast.makeText(this, t("google_unavailable"), Toast.LENGTH_LONG).show() }
    }

    private fun showPremiumLimitDialog() {
        AlertDialog.Builder(this).setTitle(t("limit_title"))
            .setMessage(t("limit_message", SavingLimitManager.WEEKLY_FREE_LIMIT, SavingLimitManager.used(this), SavingLimitManager.extra(this)))
            .setNegativeButton(t("cancel"), null)
            .setPositiveButton("Buka Toko Koin") { _, _ -> startActivity(Intent(this, CoinShopActivity::class.java)) }
            .show()
    }

    private fun showPremium() {
        val box = contentColumn()
        val c = cardContainer()
        c.addView(TextView(this).apply { text = "SakuTabung OPIMOUS"; textSize = 24f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.primary)); gravity = Gravity.CENTER })
        c.addView(TextView(this).apply { text = "Premium diperoleh dari progres level"; textSize = 17f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)); gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(2)) })
        c.addView(TextView(this).apply { text = "Level 20: 3 hari • Level 50: 7 hari • Level 100: permanen"; textSize = 12.5f; setTextColor(getColorCompat(R.color.muted)); gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(8)) })
        c.addView(TextView(this).apply { text = t("premium_desc"); textSize = 13f; setTextColor(getColorCompat(R.color.muted)); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(10)) })
        box.addView(c)
        val features = listOf("unlimited_saving","premium_stats","unlimited_games","custom_theme","smart_goal","export_backup","goal_templates","priority_insight","premium_badges")
        features.forEachIndexed { i, key ->
            val f = cardContainer()
            f.addView(TextView(this).apply { text = "${i+1}. ${t(key)}"; textSize = 15f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
            f.addView(TextView(this).apply { text = t("premium_only"); textSize = 12f; setTextColor(getColorCompat(R.color.primary)); setPadding(0, dp(3), 0, dp(6)) })
            f.addView(secondaryButton(t("use_feature")) { premiumFeatureAction(key) })
            box.addView(f)
        }
        box.addView(primaryButton(if (PremiumManager.isPremium(this)) t("premium_active") else "Lihat Reward Level") { startActivity(Intent(this, RewardCenterActivity::class.java)) })
        shell("OPIMOUS", ScrollView(this).apply { addView(box) }, 0)
    }

    private fun freeLimitCard(): View = cardContainer().apply {
        val available = SavingLimitManager.available(this@MainActivity)
        val used = SavingLimitManager.used(this@MainActivity)
        val extra = SavingLimitManager.extra(this@MainActivity)
        addView(TextView(this@MainActivity).apply { text = t("free_limit_title"); textSize = 16f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        addView(TextView(this@MainActivity).apply { text = "$available limit tersedia • $used/${SavingLimitManager.WEEKLY_FREE_LIMIT} kuota mingguan • +$extra ekstra"; textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(5), 0, 0) })
    }

    private fun premiumMiniCard(): View = cardContainer().apply {
        addView(TextView(this@MainActivity).apply { text = "${t("opimous_status")}"; textSize = 16f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.primary)) })
        addView(TextView(this@MainActivity).apply { text = t("unlimited_saving"); textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(5), 0, 0) })
    }


    private fun premiumFeatureAction(key: String) {
        if (!PremiumManager.isPremium(this)) { showPremium(); return }
        when (key) {
            "unlimited_saving" -> Toast.makeText(this, t("feature_active"), Toast.LENGTH_SHORT).show()
            "premium_stats" -> {
                val tx = db.transactions(); val total = tx.sumOf { it.amount }; val avg = if (tx.isEmpty()) 0L else total / tx.size
                AlertDialog.Builder(this).setTitle(t("premium_stats_title")).setMessage(t("premium_stats_msg", tx.size, Format.rupiah(total), Format.rupiah(avg))).setPositiveButton(t("great"), null).show()
            }
            "unlimited_games" -> Toast.makeText(this, t("feature_active"), Toast.LENGTH_SHORT).show()
            "custom_theme" -> { val next = !prefs.getBoolean("dark_mode", false); prefs.edit().putBoolean("dark_mode", next).apply(); AppCompatDelegate.setDefaultNightMode(if (next) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO) }
            "smart_goal" -> AlertDialog.Builder(this).setTitle(t("smart_goal_title")).setMessage(t("smart_goal_msg")).setPositiveButton(t("great"), null).show()
            "export_backup" -> exportBackup()
            "goal_templates" -> showGoalTemplates()
            "priority_insight" -> AlertDialog.Builder(this).setTitle(t("priority_title")).setMessage(t("priority_msg")).setPositiveButton(t("great"), null).show()
            "premium_badges" -> showAchievements()
            
        }
    }

    private fun exportBackup() {
        val payload = BackupManager.export(this)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "application/json"; putExtra(Intent.EXTRA_TEXT, payload) }, t("export_backup")))
    }

    private fun showGoalTemplates() {
        val templates = arrayOf(t("template_phone"), t("template_trip"), t("template_emergency"))
        val names = arrayOf("HP Impian", "Liburan", "Dana Darurat")
        val amounts = longArrayOf(3_000_000L, 2_000_000L, 5_000_000L)
        AlertDialog.Builder(this).setTitle(t("goal_templates")).setItems(templates) { _, which ->
            showGoalForm(null, names[which] to amounts[which])
        }.setNegativeButton(t("cancel"), null).show()
    }

    private fun achievementKeys(): Set<String> {
        val tx = db.transactions(); val goals = db.goals(); val total = tx.sumOf { it.amount }; val streak = calculateStreak(tx)
        return buildSet {
            if (tx.isNotEmpty()) add("first")
            if (total >= 100000) add("100k")
            if (total >= 1000000) add("1m")
            if (streak >= 7) add("7d")
            if (streak >= 30) add("30d")
            if (goals.any { !it.active && db.saved(it.id) >= it.target }) add("goal")
        }
    }

    private fun achievementName(key: String): Pair<String, String> = when (key) {
        "first" -> "01" to "Tabungan Pertama"
        "100k" -> "02" to "100 Ribu"
        "1m" -> "03" to "1 Juta"
        "7d" -> "04" to "7 Hari Berturut-turut"
        "30d" -> "05" to "30 Hari Berturut-turut"
        else -> "06" to "Menyelesaikan Target"
    }

    private fun showAchievementUnlocked(key: String) {
        val (icon, name) = achievementName(key)
        val frame = FrameLayout(this)
        val confetti = ConfettiView(this).apply { visibility = if (prefs.getBoolean("confetti", true)) View.VISIBLE else View.GONE }
        frame.addView(confetti, FrameLayout.LayoutParams(-1, -1))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(24), dp(22), dp(24), dp(22)); alpha = 0f; scaleX = .65f; scaleY = .65f
            background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(getColorCompat(R.color.background)) }
        }
        card.addView(TextView(this).apply { text = ""; textSize = 22f; gravity = Gravity.CENTER })
        card.addView(TextView(this).apply { text = t("achievement_open"); textSize = 20f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)); gravity = Gravity.CENTER })
        card.addView(TextView(this).apply { text = "$icon  $name"; textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.primary)); gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(4)) })
        card.addView(TextView(this).apply { text = t("keep_going"); textSize = 13f; setTextColor(getColorCompat(R.color.muted)); gravity = Gravity.CENTER })
        frame.addView(card, FrameLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER).also { it.setMargins(dp(34),0,dp(34),0) })
        val dialog = AlertDialog.Builder(this).setView(frame).setPositiveButton(t("great"), null).create()
        dialog.setOnShowListener {
            AnimatorSet().apply {
                playTogether(ObjectAnimator.ofFloat(card, View.ALPHA, 0f, 1f), ObjectAnimator.ofFloat(card, View.SCALE_X, .65f, 1f), ObjectAnimator.ofFloat(card, View.SCALE_Y, .65f, 1f)); duration = 600; interpolator = OvershootInterpolator(1.5f)
            }.start()
            if (prefs.getBoolean("achievement_sound", false)) playAchievementSound()
            confetti.start()
        }
        dialog.setOnDismissListener { gIdForPopup?.let { if (it > 0) showGoalDetail(it) else showHome() } ?: showHome() }
        // Keep the current screen intact; after dismissal simply refresh the home/detail below.
        dialog.show()
    }

    private var gIdForPopup: Long? = null
    private fun playAchievementSound() { runCatching { soundTone.startTone(ToneGenerator.TONE_PROP_ACK, 180) } }

    private fun confirmDelete(g: Goal) { AlertDialog.Builder(this).setTitle(t("delete_title", g.name)).setMessage(t("delete_msg")).setNegativeButton(t("cancel"), null).setPositiveButton(t("delete")) { _, _ -> db.deleteGoal(g.id); prefs.edit().remove("goal_image_${g.id}").apply(); ReminderScheduler.cancel(this, g.id); showGoals() }.show() }

    private fun sectionLabel(text: String) = TextView(this).apply { this.text = text; textSize = 17f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)); setPadding(0, dp(16), 0, dp(8)) }
    private fun emptyState(title: String, subtitle: String): View = cardContainer().apply { gravity = Gravity.CENTER_HORIZONTAL; addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_pig); layoutParams = LinearLayout.LayoutParams(dp(62), dp(62)) }); addView(TextView(this@MainActivity).apply { text = title; textSize = 17f; setTypeface(null, Typeface.BOLD); gravity = 17; setTextColor(getColorCompat(R.color.text)) }); addView(TextView(this@MainActivity).apply { text = subtitle; textSize = 13f; gravity = 17; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(4), 0, 0) }) }
    private fun successBanner(text: String) = TextView(this).apply { this.text = text; textSize = 14f; setTextColor(getColorCompat(R.color.primary)); setPadding(dp(16), dp(14), dp(16), dp(14)); setBackgroundResource(R.drawable.bg_success) }
    private fun contentColumn() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(4), dp(18), dp(18)) }
    private fun cardContainer() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); setBackgroundResource(R.drawable.bg_card); layoutParams = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.setMargins(0, 0, 0, dp(12)) } }
    private fun primaryButton(text: String, action: () -> Unit) = Button(this).apply { this.text = text; setAllCaps(false); textSize = 15f; setOnClickListener { action() }; setBackgroundResource(R.drawable.bg_primary_button); setTextColor(0xFFFFFFFF.toInt()); minHeight = dp(54); layoutParams = LinearLayout.LayoutParams(-1, dp(56)).also { it.setMargins(0, dp(4), 0, dp(8)) } }
    private fun secondaryButton(text: String, action: () -> Unit) = Button(this).apply { this.text = text; setAllCaps(false); textSize = 14f; setOnClickListener { action() }; minHeight = dp(50); layoutParams = LinearLayout.LayoutParams(-1, dp(52)).also { it.setMargins(0, dp(3), 0, dp(5)) } }
    private fun dangerButton(text: String, action: () -> Unit) = secondaryButton(text, action)
    private fun input(hint: String, value: String, numeric: Boolean = false): TextInputEditText = TextInputEditText(this).apply { this.hint = hint; setText(value); textSize = 16f; setSingleLine(true); if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER; layoutParams = LinearLayout.LayoutParams(-1, dp(58)).also { it.setMargins(0, dp(3), 0, dp(3)) } }

    private fun datePicker(target: TextView) { val initial = runCatching { LocalDate.parse(target.text.toString()) }.getOrElse { LocalDate.now() }; DatePickerDialog(this, { _, y, m, d -> target.text = "%04d-%02d-%02d".format(y, m + 1, d) }, initial.year, initial.monthValue - 1, initial.dayOfMonth).show() }
    private fun timePicker(target: TextView) { val c = Calendar.getInstance(); TimePickerDialog(this, { _, h, m -> target.text = "%02d:%02d".format(h, m) }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show() }
    private fun requestNotificationIfNeeded(force: Boolean = false) { if (Build.VERSION.SDK_INT >= 33 && (force || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS) }
    private fun getColorCompat(id: Int) = androidx.core.content.ContextCompat.getColor(this, id)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}

private class SimpleTextWatcher(private val changed: () -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = changed()
    override fun afterTextChanged(s: android.text.Editable?) = Unit
}
