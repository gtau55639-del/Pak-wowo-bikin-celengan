package com.sakutabung.app.util

import android.content.Context
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.game.GameLimitManager
import com.sakutabung.app.model.GameScore
import java.time.LocalDate

/** Satu jalur penyelesaian game agar skor, statistik, XP, dan koin konsisten. */
object GameRewardManager {
    fun record(context: Context, gameType: String, score: Int): Int {
        val safeScore = score.coerceAtLeast(0)
        DatabaseHelper(context).insertGameScore(
            GameScore(0, gameType, safeScore, GameLimitManager.getGrade(context), LocalDate.now().toString())
        )
        BrainStatsManager.record(context, safeScore)
        val coins = CoinManager.gameReward(safeScore)
        if (coins > 0) CoinManager.add(context, coins)
        RewardManager.addXp(context, 10 + (safeScore / 10).coerceAtMost(50))
        return coins
    }
}
