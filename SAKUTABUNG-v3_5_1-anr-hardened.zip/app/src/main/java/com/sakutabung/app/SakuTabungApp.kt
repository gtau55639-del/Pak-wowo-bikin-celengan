package com.sakutabung.app

import android.app.Application
import android.content.Intent
import com.sakutabung.app.ui.CrashActivity
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Menangkap crash yang tidak tertangani, lalu menampilkan detailnya di layar
 * (CrashActivity) alih-alih membuat aplikasi force-close tanpa keterangan.
 * Ini memudahkan diagnosis bug tanpa perlu adb/logcat.
 */
class SakuTabungApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val intent = Intent(this, CrashActivity::class.java).apply {
                    putExtra(CrashActivity.EXTRA_STACK_TRACE, sw.toString())
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                }
                startActivity(intent)
                android.os.Handler(mainLooper).postDelayed({
                    android.os.Process.killProcess(android.os.Process.myPid())
                }, 500L)
            } catch (_: Throwable) {
                android.os.Process.killProcess(android.os.Process.myPid())
            }
        }
    }
}
