package com.sakutabung.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.R
import com.sakutabung.app.util.PremiumManager

class DeveloperActivity: AppCompatActivity(){
 private val prefs by lazy{getSharedPreferences("dev_chat",MODE_PRIVATE)}
 private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
 override fun onCreate(b:Bundle?){super.onCreate(b);build()}
 private fun build(){
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(18))}
  root.addView(TextView(this).apply{text="Developer / Creator";textSize=26f;setTypeface(null,Typeface.BOLD)})
  root.addView(TextView(this).apply{text="Sampaikan keluh kesah, saran, atau laporan bug.";textSize=13f;setPadding(0,dp(4),0,dp(12))})
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundResource(R.drawable.bg_card);setPadding(dp(16),dp(16),dp(16),dp(16))}
  val status=TextView(this).apply{text=if(PremiumManager.isDeveloper(this@DeveloperActivity))"DEVELOPER MODE AKTIF" else "Mode pengguna";textSize=16f;setTypeface(null,Typeface.BOLD)};box.addView(status)
  val email=EditText(this).apply{hint="Email akun Google";setSingleLine(true)};box.addView(email)
  box.addView(Button(this).apply{text="Jadikan OPIMOUS (Developer)";setAllCaps(false);setOnClickListener{if(PremiumManager.isDeveloper(this@DeveloperActivity)){val e=email.text.toString().trim();if(e.isNotBlank()){getSharedPreferences("settings",0).edit().putBoolean("premium_active",true).putString("google_account",e).apply();Toast.makeText(this@DeveloperActivity,"OPIMOUS lokal diberikan ke $e",Toast.LENGTH_LONG).show()}}else Toast.makeText(this@DeveloperActivity,"Akses developer hanya untuk akun creator.",Toast.LENGTH_LONG).show()}})
  root.addView(box,LinearLayout.LayoutParams(-1,-2).also{it.setMargins(0,0,0,dp(12))})
  val msg=EditText(this).apply{hint="Tulis pesan / laporan bug...";minLines=4;gravity=48};root.addView(msg)
  val saved=TextView(this).apply{text=prefs.getString("messages","")?:"";textSize=13f;setPadding(0,dp(10),0,dp(10))};root.addView(saved,LinearLayout.LayoutParams(-1,0,1f))
  root.addView(Button(this).apply{text="Kirim offline";setAllCaps(false);setOnClickListener{val m=msg.text.toString().trim();if(m.isNotBlank()){val old=prefs.getString("messages","")?:"";prefs.edit().putString("messages",(old+"\n•"+m).trim()).apply();saved.text=prefs.getString("messages","");msg.text.clear();Toast.makeText(this@DeveloperActivity,"Pesan disimpan offline.",Toast.LENGTH_SHORT).show()}}})
  root.addView(Button(this).apply{text="Kirim online (Email)";setAllCaps(false);setOnClickListener{val m=msg.text.toString().trim();startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:febrianmahnu@gmail.com")).putExtra(Intent.EXTRA_SUBJECT,"SakuTabung — Feedback").putExtra(Intent.EXTRA_TEXT,m))}})
  root.addView(Button(this).apply{text="Dukung Developer via Saweria";setAllCaps(false);setOnClickListener{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://saweria.co/")))}})
  setContentView(root)
 }
}
