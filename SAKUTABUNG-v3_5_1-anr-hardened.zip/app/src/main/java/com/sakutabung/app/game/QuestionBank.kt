package com.sakutabung.app.game

import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Ditambahkan di v1.1.0.
 * Soal matematika dibuat acak secara prosedural (jadi selalu beda tiap main),
 * tingkat kesulitan mengikuti kelas yang dipilih (SD - SMA).
 * Soal bahasa Inggris diambil acak dari bank soal per tingkat.
 */
object QuestionBank {

    fun math(grade: Grade, count: Int = 10): List<Question> {
        val rnd = Random(System.nanoTime())
        val seen = mutableSetOf<String>()
        val result = mutableListOf<Question>()
        var guard = 0
        while (result.size < count && guard < count * 20) {
            guard++
            val q = generateMathQuestion(grade.number, rnd)
            if (seen.add(q.text)) result.add(q)
        }
        return result
    }

    fun english(grade: Grade, count: Int = 10): List<Question> {
        val pool = when (grade.tier) {
            0 -> englishTier0
            1 -> englishTier1
            2 -> englishTier2
            else -> englishTier3
        }
        return pool.shuffled().take(count.coerceAtMost(pool.size)).map { item ->
            val options = (item.distractors + item.correct).shuffled()
            Question(item.question, options, options.indexOf(item.correct))
        }
    }

    // ---------- Matematika (acak, sesuai kelas) ----------

    private fun mkQuestion(prompt: String, correct: Int, rnd: Random, spread: Int): Question {
        val options = mutableSetOf(correct)
        var guard = 0
        while (options.size < 4 && guard < 60) {
            guard++
            val delta = rnd.nextInt(-spread, spread + 1)
            if (delta != 0) options.add(correct + delta)
        }
        var extra = 1
        while (options.size < 4) { options.add(correct + spread + extra); extra++ }
        val list = options.toMutableList()
        list.shuffle(rnd)
        return Question(prompt, list.map { it.toString() }, list.indexOf(correct))
    }

    private fun generateMathQuestion(gradeNumber: Int, rnd: Random): Question = when {
        gradeNumber <= 2 -> { // SD kelas 1-2: penjumlahan & pengurangan sampai 20
            if (rnd.nextBoolean()) {
                val a = rnd.nextInt(1, 15); val b = rnd.nextInt(1, 20 - a + 1)
                mkQuestion("$a + $b = ?", a + b, rnd, 5)
            } else {
                val x = rnd.nextInt(5, 20); val y = rnd.nextInt(0, x)
                mkQuestion("$x - $y = ?", x - y, rnd, 5)
            }
        }
        gradeNumber == 3 -> { // SD kelas 3
            when (rnd.nextInt(3)) {
                0 -> { val a = rnd.nextInt(10, 200); val b = rnd.nextInt(10, 200); mkQuestion("$a + $b = ?", a + b, rnd, 15) }
                1 -> { val a = rnd.nextInt(50, 300); val b = rnd.nextInt(10, a); mkQuestion("$a - $b = ?", a - b, rnd, 15) }
                else -> { val a = rnd.nextInt(2, 10); val b = rnd.nextInt(2, 10); mkQuestion("$a x $b = ?", a * b, rnd, 8) }
            }
        }
        gradeNumber == 4 -> { // SD kelas 4
            when (rnd.nextInt(3)) {
                0 -> { val a = rnd.nextInt(100, 900); val b = rnd.nextInt(100, 900); mkQuestion("$a + $b = ?", a + b, rnd, 20) }
                1 -> { val a = rnd.nextInt(2, 12); val b = rnd.nextInt(2, 12); mkQuestion("$a x $b = ?", a * b, rnd, 10) }
                else -> { val b = rnd.nextInt(2, 10); val res = rnd.nextInt(2, 10); val a = b * res; mkQuestion("$a : $b = ?", res, rnd, 5) }
            }
        }
        gradeNumber <= 6 -> { // SD kelas 5-6
            when (rnd.nextInt(3)) {
                0 -> { val a = rnd.nextInt(12, 99); val b = rnd.nextInt(12, 99); mkQuestion("$a x $b = ?", a * b, rnd, 40) }
                1 -> { val b = rnd.nextInt(2, 12); val res = rnd.nextInt(2, 12); val a = b * res; mkQuestion("$a : $b = ?", res, rnd, 6) }
                else -> {
                    val denom = listOf(2, 4, 5, 10, 20).random(rnd); val num = rnd.nextInt(1, denom)
                    mkQuestion("$num/$denom sama dengan berapa persen?", num * 100 / denom, rnd, 15)
                }
            }
        }
        gradeNumber <= 9 -> { // SMP kelas 7-9
            when (rnd.nextInt(4)) {
                0 -> { val a = rnd.nextInt(2, 12); val x = rnd.nextInt(1, 20); val b = a * x; mkQuestion("${a}x = $b, nilai x = ?", x, rnd, 6) }
                1 -> { val a = rnd.nextInt(-25, 26); val b = rnd.nextInt(-25, 26); mkQuestion("($a) + ($b) = ?", a + b, rnd, 15) }
                2 -> { val a = rnd.nextInt(2, 12); mkQuestion("$a pangkat 2 = ?", a * a, rnd, 25) }
                else -> { val total = rnd.nextInt(50, 400); val pct = listOf(10, 20, 25, 50, 75).random(rnd); mkQuestion("$pct% dari $total = ?", total * pct / 100, rnd, 20) }
            }
        }
        else -> { // SMA kelas 10-12
            when (rnd.nextInt(4)) {
                0 -> { val r = rnd.nextInt(2, 13); mkQuestion("Akar kuadrat dari ${r * r} = ?", r, rnd, 5) }
                1 -> {
                    val a = rnd.nextInt(1, 5); val b = rnd.nextInt(-8, 9); val c = rnd.nextInt(-8, 9); val x = rnd.nextInt(-5, 6)
                    val hasil = a * x * x + b * x + c
                    mkQuestion("Jika f(x) = ${a}x\u00b2 + ${b}x + ($c), maka f($x) = ?", hasil, rnd, 15)
                }
                2 -> {
                    val angle = listOf(0, 90, 180, 270, 360).random(rnd)
                    val useSin = rnd.nextBoolean()
                    val value = if (useSin) Math.sin(Math.toRadians(angle.toDouble())).roundToInt() else Math.cos(Math.toRadians(angle.toDouble())).roundToInt()
                    val fn = if (useSin) "sin" else "cos"
                    mkQuestion("Nilai $fn($angle\u00b0) = ?", value, rnd, 2)
                }
                else -> { val pangkat = rnd.nextInt(1, 5); val hasil = Math.pow(10.0, pangkat.toDouble()).toInt(); mkQuestion("\u00b2log tidak dipakai. log10($hasil) = ?", pangkat, rnd, 3) }
            }
        }
    }

    // ---------- Bahasa Inggris (bank soal acak per tingkat) ----------

    private data class EnglishItem(val question: String, val correct: String, val distractors: List<String>)

    private val englishTier0 = listOf( // SD kelas 1-3: kosakata dasar
        EnglishItem("Bahasa Inggris dari 'kucing' adalah ...", "Cat", listOf("Dog", "Bird", "Fish")),
        EnglishItem("Bahasa Inggris dari 'buku' adalah ...", "Book", listOf("Pen", "Bag", "Chair")),
        EnglishItem("Bahasa Inggris dari 'merah' adalah ...", "Red", listOf("Blue", "Green", "Yellow")),
        EnglishItem("Bahasa Inggris dari 'satu' adalah ...", "One", listOf("Two", "Three", "Four")),
        EnglishItem("Bahasa Inggris dari 'ibu' adalah ...", "Mother", listOf("Father", "Sister", "Brother")),
        EnglishItem("Bahasa Inggris dari 'meja' adalah ...", "Table", listOf("Chair", "Door", "Window")),
        EnglishItem("Bahasa Inggris dari 'anjing' adalah ...", "Dog", listOf("Cat", "Cow", "Duck")),
        EnglishItem("Bahasa Inggris dari 'matahari' adalah ...", "Sun", listOf("Moon", "Star", "Sky")),
        EnglishItem("Bahasa Inggris dari 'sekolah' adalah ...", "School", listOf("Home", "Park", "Shop")),
        EnglishItem("Bahasa Inggris dari 'makan' adalah ...", "Eat", listOf("Drink", "Sleep", "Run")),
        EnglishItem("Bahasa Inggris dari 'lima' adalah ...", "Five", listOf("Six", "Four", "Seven")),
        EnglishItem("Bahasa Inggris dari 'biru' adalah ...", "Blue", listOf("Red", "Black", "White")),
        EnglishItem("Bahasa Inggris dari 'ayah' adalah ...", "Father", listOf("Mother", "Uncle", "Aunt")),
        EnglishItem("Bahasa Inggris dari 'pensil' adalah ...", "Pencil", listOf("Eraser", "Ruler", "Bag")),
        EnglishItem("Bahasa Inggris dari 'rumah' adalah ...", "House", listOf("Road", "Garden", "Field")),
        EnglishItem("Bahasa Inggris dari 'burung' adalah ...", "Bird", listOf("Fish", "Snake", "Frog")),
        EnglishItem("Bahasa Inggris dari 'sepuluh' adalah ...", "Ten", listOf("Nine", "Eight", "Eleven")),
        EnglishItem("Bahasa Inggris dari 'baju' adalah ...", "Shirt", listOf("Shoes", "Hat", "Socks"))
    )

    private val englishTier1 = listOf( // SD kelas 4-6: kalimat sederhana
        EnglishItem("She ___ to school every day.", "goes", listOf("go", "going", "gone")),
        EnglishItem("They ___ playing football now.", "are", listOf("is", "am", "be")),
        EnglishItem("I have ___ apple in my bag.", "an", listOf("a", "the", "some")),
        EnglishItem("This is my book. It is ___ book.", "my", listOf("me", "I", "mine self")),
        EnglishItem("Pilih kata yang berarti 'cepat': ...", "fast", listOf("slow", "heavy", "quiet")),
        EnglishItem("What is the plural of 'child'?", "children", listOf("childs", "childes", "childrens")),
        EnglishItem("We ___ dinner at 7 pm yesterday.", "had", listOf("have", "having", "has")),
        EnglishItem("Antonim dari 'big' adalah ...", "small", listOf("tall", "long", "wide")),
        EnglishItem("He is ___ than his brother.", "taller", listOf("tall", "tallest", "more tall")),
        EnglishItem("There ___ two cats under the table.", "are", listOf("is", "am", "was")),
        EnglishItem("My father works ___ a hospital.", "at", listOf("on", "of", "to")),
        EnglishItem("Kata kerja bentuk lampau dari 'go' adalah ...", "went", listOf("goed", "gone", "going")),
        EnglishItem("Yesterday I ___ my homework.", "did", listOf("do", "does", "doing")),
        EnglishItem("Sinonim dari 'happy' adalah ...", "glad", listOf("sad", "angry", "tired")),
        EnglishItem("She can ___ very well.", "swim", listOf("swimming", "swims", "swam")),
        EnglishItem("Look! The dog ___ running fast.", "is", listOf("are", "am", "be"))
    )

    private val englishTier2 = listOf( // SMP kelas 7-9: tata bahasa & kosakata
        EnglishItem("Choose the correct past tense of 'eat'.", "ate", listOf("eated", "eating", "eats")),
        EnglishItem("If it rains, I ___ stay at home.", "will", listOf("would", "was", "did")),
        EnglishItem("She has ___ finished her homework.", "already", listOf("yet", "still", "ago")),
        EnglishItem("Synonym of 'difficult' is ...", "hard", listOf("easy", "simple", "soft")),
        EnglishItem("The book ___ by many students.", "is read", listOf("reads", "reading", "read")),
        EnglishItem("Antonym of 'increase' is ...", "decrease", listOf("raise", "grow", "expand")),
        EnglishItem("We ___ friends since childhood.", "have been", listOf("are", "was", "were being")),
        EnglishItem("Choose the correct comparative: This box is ___ than that one.", "heavier", listOf("heavy", "more heavy", "heaviest")),
        EnglishItem("He asked me ___ I was late.", "why", listOf("what", "which", "who")),
        EnglishItem("The opposite of 'ancient' is ...", "modern", listOf("old", "historic", "classic")),
        EnglishItem("They ___ the movie before.", "have watched", listOf("watched", "watching", "watches")),
        EnglishItem("Choose the correct preposition: interested ___ music.", "in", listOf("on", "at", "for")),
        EnglishItem("'Borrow' means ...", "meminjam", listOf("meminjamkan", "membeli", "menjual")),
        EnglishItem("The teacher told us ___ be quiet.", "to", listOf("for", "that", "of")),
        EnglishItem("Choose the correct passive form: The letter ___ yesterday.", "was sent", listOf("sent", "is sent", "sending"))
    )

    private val englishTier3 = listOf( // SMA kelas 10-12: lebih lanjut
        EnglishItem("Synonym of 'abundant' is ...", "plentiful", listOf("scarce", "rare", "limited")),
        EnglishItem("Choose the correct sentence.", "She would have come if she had known.", listOf("She would came if she knew.", "She will have come if she know.", "She would have come if she knows.")),
        EnglishItem("'Procrastinate' means ...", "menunda-nunda", listOf("mempercepat", "menyelesaikan", "merencanakan")),
        EnglishItem("Idiom 'break the ice' means ...", "mencairkan suasana", listOf("memecahkan es", "membuat marah", "mengakhiri sesuatu")),
        EnglishItem("Choose the correct conditional: If I ___ rich, I would travel the world.", "were", listOf("was", "am", "will be")),
        EnglishItem("Antonym of 'concise' is ...", "verbose", listOf("brief", "short", "clear")),
        EnglishItem("Choose the best word: The evidence was ___ to convict him.", "insufficient", listOf("sufficiently", "sufficient enough", "insufficiency")),
        EnglishItem("'Nevertheless' is closest in meaning to ...", "however", listOf("therefore", "because", "moreover")),
        EnglishItem("Choose the correct reported speech: He said, 'I am tired.' -> He said that ...", "he was tired", listOf("he is tired", "he tired", "he has tired")),
        EnglishItem("'Meticulous' means ...", "sangat teliti", listOf("sangat ceroboh", "sangat cepat", "sangat malas")),
        EnglishItem("Choose the correct sentence with subjunctive mood.", "I suggest that he be careful.", listOf("I suggest that he is careful.", "I suggest that he careful.", "I suggest he being careful.")),
        EnglishItem("Idiom 'once in a blue moon' means ...", "sangat jarang terjadi", listOf("setiap bulan", "sangat sering", "tepat waktu"))
    )
}
