package com.sakutabung.app.util

import android.content.Context
import java.time.LocalDate
import java.time.temporal.WeekFields
import java.util.Locale

/**
 * OPIMOUS is earned through progression. No payment is required in the app's
 * current model. Google linking is optional and never grants entitlement.
 */
object PremiumManager {
    private const val PREFS = "settings"
    private const val KEY_EMAIL = "google_account"
    private const val KEY_PERMANENT = "premium_permanent"
    private const val KEY_UNTIL = "premium_until"
    private const val KEY_DEV = "developer_mode"
    const val FREE_WEEKLY_LIMIT = 6
    const val FREE_WEEKLY_SAVING_LIMIT = FREE_WEEKLY_LIMIT

    private const val KEY_SOCIAL_STARTED = "social_reward_started"
    private const val KEY_SOCIAL_VERIFIED_AT = "social_reward_verified_at"
    private const val SOCIAL_DAYS = 6L

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun email(c: Context) = p(c).getString(KEY_EMAIL, null)
    fun isDeveloper(c: Context): Boolean =
        com.sakutabung.app.BuildConfig.DEBUG && p(c).getBoolean(KEY_DEV, false)

    fun isPermanent(c: Context): Boolean = p(c).getBoolean(KEY_PERMANENT, false) || isDeveloper(c)

    fun premiumUntil(c: Context): LocalDate? = p(c).getString(KEY_UNTIL, null)?.let { runCatching { LocalDate.parse(it) }.getOrNull() }

    fun isPremium(c: Context): Boolean {
        if (isPermanent(c)) return true
        val until = premiumUntil(c) ?: return false
        return !LocalDate.now().isAfter(until)
    }

    fun daysRemaining(c: Context): Long = if (isPermanent(c)) Long.MAX_VALUE else {
        val until = premiumUntil(c) ?: return 0L
        (java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), until) + 1).coerceAtLeast(0L)
    }

    fun activateTrial(c: Context, days: Int): Boolean {
        if (days <= 0 || isPermanent(c)) return false
        val current = premiumUntil(c)
        val start = if (current != null && !LocalDate.now().isAfter(current)) current.plusDays(1) else LocalDate.now()
        val until = start.plusDays(days.toLong() - 1)
        p(c).edit().putString(KEY_UNTIL, until.toString()).apply()
        return true
    }

    fun activatePermanent(c: Context): Boolean {
        p(c).edit().putBoolean(KEY_PERMANENT, true).remove(KEY_UNTIL).apply()
        return true
    }

    /** Restores entitlement exactly from a trusted local backup. */
    fun restoreEntitlement(c: Context, permanent: Boolean, until: String?) {
        val editor = p(c).edit().putBoolean(KEY_PERMANENT, permanent)
        if (permanent) editor.remove(KEY_UNTIL) else if (!until.isNullOrBlank()) editor.putString(KEY_UNTIL, until) else editor.remove(KEY_UNTIL)
        editor.apply()
    }

    fun revokeTrial(c: Context) {
        if (!isPermanent(c)) p(c).edit().remove(KEY_UNTIL).apply()
    }

    /** Account linking is optional and does not grant Premium. */
    fun login(c: Context, account: String) {
        // Google linking is identity-only. It never grants Premium.
        p(c).edit().putString(KEY_EMAIL, account).putBoolean(KEY_DEV, false).apply()
    }

    fun signOut(c: Context) { p(c).edit().remove(KEY_EMAIL).putBoolean(KEY_DEV, false).apply() }

    fun socialChallengeStarted(c: Context): Boolean = p(c).getBoolean(KEY_SOCIAL_STARTED, false)
    fun socialVerifiedAt(c: Context): Long = p(c).getLong(KEY_SOCIAL_VERIFIED_AT, 0L)
    fun startSocialChallenge(c: Context) { p(c).edit().putBoolean(KEY_SOCIAL_STARTED, true).apply() }
    fun setOnlineSocialVerification(c: Context, verified: Boolean) {
        if (verified) p(c).edit().putLong(KEY_SOCIAL_VERIFIED_AT, System.currentTimeMillis()).apply()
        else p(c).edit().remove(KEY_SOCIAL_VERIFIED_AT).apply()
    }
    fun socialDaysRemaining(c: Context): Long {
        val at = socialVerifiedAt(c)
        if (at <= 0L) return SOCIAL_DAYS
        val elapsed = java.time.Duration.ofMillis((System.currentTimeMillis() - at).coerceAtLeast(0L)).toDays()
        return (SOCIAL_DAYS - elapsed).coerceAtLeast(0L)
    }
    fun canRewardFromSocial(c: Context): Boolean = socialVerifiedAt(c) > 0L && socialDaysRemaining(c) == 0L && !isDeveloper(c)
    fun revokeSocialReward(c: Context) { p(c).edit().remove(KEY_SOCIAL_VERIFIED_AT).apply(); revokeTrial(c) }

    fun weekKey(date: LocalDate = LocalDate.now()): String {
        val wf = WeekFields.of(Locale.getDefault())
        return "${date.get(wf.weekBasedYear())}-${date.get(wf.weekOfWeekBasedYear())}"
    }
    fun weeklyLimitUsed(c: Context): Int = com.sakutabung.app.data.DatabaseHelper(c).transactions().count {
        runCatching { weekKey(LocalDate.parse(it.date)) == weekKey() }.getOrDefault(false)
    }
    fun weeklySavingCount(c: Context): Int = weeklyLimitUsed(c)
}
