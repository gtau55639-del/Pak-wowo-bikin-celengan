package com.sakutabung.app.util

import android.content.Context
import java.time.LocalDate
import java.time.YearMonth

object ProfileManager {
    private const val PREFS = "profile"
    private const val NAME = "name"
    private const val LAST_NAME_CHANGE = "last_name_change"

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun name(c: Context): String = p(c).getString(NAME, "SakuUser")?.ifBlank { "SakuUser" } ?: "SakuUser"

    fun canChangeName(c: Context): Boolean {
        val last = p(c).getString(LAST_NAME_CHANGE, null) ?: return true
        return runCatching { YearMonth.from(LocalDate.now()) != YearMonth.from(LocalDate.parse(last)) }.getOrDefault(true)
    }

    fun changeName(c: Context, newName: String): Boolean {
        val clean = newName.trim().replace(Regex("\\s+"), " ")
        if (clean.length !in 3..24 || !canChangeName(c)) return false
        p(c).edit().putString(NAME, clean).putString(LAST_NAME_CHANGE, LocalDate.now().toString()).apply()
        return true
    }

    fun export(c: Context): Map<String, Any> = mapOf("name" to name(c), "lastNameChange" to (p(c).getString(LAST_NAME_CHANGE, "") ?: ""))

    fun import(c: Context, name: String?, lastNameChange: String?) {
        val clean = name?.trim().orEmpty()
        if (clean.isNotBlank()) p(c).edit().putString(NAME, clean.take(24)).apply()
        if (!lastNameChange.isNullOrBlank()) p(c).edit().putString(LAST_NAME_CHANGE, lastNameChange).apply()
    }
}
