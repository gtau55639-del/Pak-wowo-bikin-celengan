package com.sakutabung.app.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class PhysicalSavingPlace(
    val id: String,
    val name: String,
    val location: String,
    val note: String
)

/** Stores only the user's labels for physical saving places. No money is held here. */
object PhysicalSavingManager {
    private const val PREFS = "physical_saving"
    private const val KEY = "places"

    fun all(context: Context): List<PhysicalSavingPlace> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(PhysicalSavingPlace(o.getString("id"), o.getString("name"), o.optString("location"), o.optString("note")))
                }
            }
        }.getOrDefault(emptyList())
    }

    fun add(context: Context, name: String, location: String, note: String): Boolean {
        val cleanName = name.trim()
        if (cleanName.isBlank()) return false
        val items = all(context).toMutableList()
        items.add(PhysicalSavingPlace(UUID.randomUUID().toString(), cleanName, location.trim(), note.trim()))
        save(context, items)
        return true
    }

    fun delete(context: Context, id: String) {
        save(context, all(context).filterNot { it.id == id })
    }

    fun exportJson(context: Context): JSONArray = JSONArray().apply {
        all(context).forEach { p -> put(JSONObject().apply {
            put("id", p.id); put("name", p.name); put("location", p.location); put("note", p.note)
        }) }
    }

    fun importJson(context: Context, array: JSONArray?) {
        if (array == null) return
        val items = buildList {
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                val name = o.optString("name").trim()
                if (name.isNotBlank()) add(PhysicalSavingPlace(o.optString("id").ifBlank { UUID.randomUUID().toString() }, name, o.optString("location"), o.optString("note")))
            }
        }
        save(context, items)
    }

    private fun save(context: Context, items: List<PhysicalSavingPlace>) {
        val arr = JSONArray().apply { items.forEach { put(JSONObject().apply { put("id", it.id); put("name", it.name); put("location", it.location); put("note", it.note) }) } }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
