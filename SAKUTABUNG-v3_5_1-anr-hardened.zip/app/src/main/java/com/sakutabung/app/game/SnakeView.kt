package com.sakutabung.app.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.view.View
import kotlin.random.Random

/**
 * Ditambahkan di v1.1.0 - mini game "Ular Angka" (versi klasik snake).
 * Kontrol memakai tombol arah (dipasang di Activity), bukan swipe, agar mudah dimainkan di HP mana pun.
 */
class SnakeView(context: Context) : View(context) {
    enum class Dir { UP, DOWN, LEFT, RIGHT }

    private val cols = 14
    private val rows = 18
    private var cellSize = 0f
    private val snake = ArrayDeque<Pair<Int, Int>>()
    private var direction = Dir.RIGHT
    private var pendingDirection = Dir.RIGHT
    private var food = 0 to 0
    private var running = false
    private var score = 0
    private var speedMs = 180L
    private val handler = Handler(Looper.getMainLooper())
    private val tickRunnable = Runnable { tick() }

    var onGameOver: ((Int) -> Unit)? = null
    var onScoreChanged: ((Int) -> Unit)? = null

    private val paintSnakeBody = Paint().apply { color = Color.parseColor("#4F7D4A") }
    private val paintSnakeHead = Paint().apply { color = Color.parseColor("#315C33") }
    private val paintFood = Paint().apply { color = Color.parseColor("#E7A64A") }
    private val paintGrid = Paint().apply { color = Color.parseColor("#E4E7DF"); strokeWidth = 1f }

    init { reset() }

    fun reset() {
        snake.clear()
        val cx = cols / 2; val cy = rows / 2
        snake.addLast(cx - 1 to cy); snake.addLast(cx to cy); snake.addLast(cx + 1 to cy)
        direction = Dir.RIGHT; pendingDirection = Dir.RIGHT
        score = 0; speedMs = 180L
        spawnFood()
        running = true
        handler.removeCallbacks(tickRunnable)
        handler.postDelayed(tickRunnable, speedMs)
        postInvalidate()
    }

    fun stop() {
        running = false
        handler.removeCallbacks(tickRunnable)
    }

    private fun spawnFood() {
        do { food = Random.nextInt(cols) to Random.nextInt(rows) } while (snake.contains(food))
    }

    fun changeDirection(d: Dir) {
        val opposite = mapOf(Dir.UP to Dir.DOWN, Dir.DOWN to Dir.UP, Dir.LEFT to Dir.RIGHT, Dir.RIGHT to Dir.LEFT)
        if (opposite[d] != direction) pendingDirection = d
    }

    private fun tick() {
        if (!running) return
        direction = pendingDirection
        val head = snake.last()
        var hx = head.first; var hy = head.second
        when (direction) {
            Dir.UP -> hy--; Dir.DOWN -> hy++; Dir.LEFT -> hx--; Dir.RIGHT -> hx++
        }
        if (hx < 0 || hy < 0 || hx >= cols || hy >= rows || snake.contains(hx to hy)) {
            running = false
            onGameOver?.invoke(score)
            return
        }
        snake.addLast(hx to hy)
        if (hx to hy == food) {
            score += 10
            onScoreChanged?.invoke(score)
            spawnFood()
            speedMs = (speedMs - 3).coerceAtLeast(80L)
        } else {
            snake.removeFirst()
        }
        postInvalidate()
        if (running) handler.postDelayed(tickRunnable, speedMs)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cellSize = minOf(w / cols.toFloat(), h / rows.toFloat())
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.parseColor("#F7F8F4"))
        val offsetX = (width - cellSize * cols) / 2f
        val offsetY = (height - cellSize * rows) / 2f
        for (i in 0..cols) canvas.drawLine(offsetX + i * cellSize, offsetY, offsetX + i * cellSize, offsetY + rows * cellSize, paintGrid)
        for (j in 0..rows) canvas.drawLine(offsetX, offsetY + j * cellSize, offsetX + cols * cellSize, offsetY + j * cellSize, paintGrid)
        canvas.drawRect(
            offsetX + food.first * cellSize + 2, offsetY + food.second * cellSize + 2,
            offsetX + (food.first + 1) * cellSize - 2, offsetY + (food.second + 1) * cellSize - 2, paintFood
        )
        snake.forEachIndexed { idx, (x, y) ->
            val paint = if (idx == snake.size - 1) paintSnakeHead else paintSnakeBody
            canvas.drawRect(
                offsetX + x * cellSize + 1, offsetY + y * cellSize + 1,
                offsetX + (x + 1) * cellSize - 1, offsetY + (y + 1) * cellSize - 1, paint
            )
        }
    }
}
