package com.sakutabung.app.ui

import android.graphics.Typeface
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.R
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.util.Format
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class SavingInsightActivity : AppCompatActivity(){
 private val db by lazy{DatabaseHelper(this)}
 private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
 private fun color(id:Int)=androidx.core.content.ContextCompat.getColor(this,id)
 override fun onCreate(b:Bundle?){super.onCreate(b);build()}
 override fun onResume(){super.onResume();if(!isFinishing)build()}
 private fun build(){
  val scroll=ScrollView(this); val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(30));setBackgroundResource(R.color.background)}
  root.addView(TextView(this).apply{text="Insight Menabung";textSize=28f;setTypeface(null,Typeface.BOLD);setTextColor(color(R.color.text))})
  root.addView(TextView(this).apply{text="Ringkasan berdasarkan catatan tabungan fisik yang tersimpan di perangkat. Tidak ada data uang yang dikelola aplikasi.";textSize=13f;setTextColor(color(R.color.muted));setPadding(0,dp(5),0,dp(15))})
  val tx=db.transactions(); val today=LocalDate.now(); val month=tx.filter{runCatching{val d=LocalDate.parse(it.date);d.year==today.year&&d.month==today.month}.getOrDefault(false)}
  val last30=tx.filter{runCatching{val d=LocalDate.parse(it.date);!d.isBefore(today.minusDays(29))&&!d.isAfter(today)}.getOrDefault(false)}
  val active=db.goals().filter{it.active}
  val total30=last30.sumOf{it.amount}; val avg=if(last30.isEmpty())0 else total30/last30.size
  addCard(root,"30 hari terakhir","${Format.rupiah(total30)}\n${last30.map{it.date}.distinct().size} hari aktif\nRata-rata per catatan ${Format.rupiah(avg)}")
  val biggest=tx.maxByOrNull{it.amount}; if(biggest!=null)addCard(root,"Catatan terbesar","${Format.rupiah(biggest.amount)} pada ${Format.date(biggest.date)}")
  active.forEach{g->
   val saved=db.saved(g.id); val remain=(g.target-saved).coerceAtLeast(0); val rawDays=ChronoUnit.DAYS.between(today,LocalDate.parse(g.deadline)); val days=if(rawDays < 0) 0 else rawDays+1; val needed=if(remain==0L)0 else if(days==0L) remain else (remain+days-1)/days
   val recent=gSaved30(g.id); val rate=if(recent.isEmpty())0 else recent.sumOf{it.amount}/recent.map{it.date}.distinct().size
   val eta=if(remain==0L)"Target sudah tercapai" else if(rate<=0)"Belum cukup data untuk memperkirakan tanggal selesai" else { val daysToFinish=(remain+rate-1)/rate; val finish=today.plusDays(daysToFinish); "Dengan rata-rata ${Format.rupiah(rate)}/hari, diperkirakan ${Format.date(finish.toString())} (${daysToFinish} hari lagi)" }
   addCard(root,"${g.name}","Tercatat ${Format.rupiah(saved)} dari ${Format.rupiah(g.target)}\nKebutuhan rencana: ${Format.rupiah(needed)}/hari\n${eta}")
  }
  if(active.isEmpty()) addCard(root,"Belum ada target","Buat target terlebih dahulu agar insight dan prediksi bisa dihitung.")
  root.addView(Button(this).apply{setAllCaps(false);text="Kembali";setOnClickListener{finish()}})
  scroll.addView(root);setContentView(scroll)
 }
 private fun gSaved30(id:Long)=db.transactions(id).filter{runCatching{val d=LocalDate.parse(it.date);!d.isBefore(LocalDate.now().minusDays(29))&&!d.isAfter(LocalDate.now())}.getOrDefault(false)}
 private fun addCard(root:LinearLayout,title:String,body:String){root.addView(LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(15),dp(16),dp(15));setBackgroundResource(R.drawable.bg_card);layoutParams=LinearLayout.LayoutParams(-1,-2).also{it.setMargins(0,0,0,dp(10))}}.also{it.addView(TextView(this).apply{text=title;textSize=17f;setTypeface(null,Typeface.BOLD);setTextColor(color(R.color.text))});it.addView(TextView(this).apply{text=body;textSize=13.5f;setTextColor(color(R.color.muted));setPadding(0,dp(6),0,0)})})}
}
