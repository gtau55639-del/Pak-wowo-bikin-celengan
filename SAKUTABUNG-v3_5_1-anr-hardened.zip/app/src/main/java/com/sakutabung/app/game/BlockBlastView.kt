package com.sakutabung.app.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.random.Random

/**
 * Ditambahkan di v1.1.0 - "Block Blast Lite": versi ringan block blast.
 * Potongan (piece) yang muncul selalu acak - tidak berjenjang seperti level biasa,
 * jadi skor murni ditentukan dari seberapa pintar menyusun & membersihkan baris/kolom.
 * Cara main: ketuk salah satu dari 3 potongan di bawah, lalu ketuk kotak di papan untuk menaruhnya.
 */
class BlockBlastView(context: Context) : View(context) {
    private val gridSize = 8
    private val grid = Array(gridSize) { BooleanArray(gridSize) }

    private var cell = 0f
    private var gridLeft = 0f
    private var gridTop = 0f
    private var trayTop = 0f
    private var trayCell = 0f

    private val shapes = listOf(
        listOf(0 to 0),
        listOf(0 to 0, 1 to 0), listOf(0 to 0, 0 to 1),
        listOf(0 to 0, 1 to 0, 2 to 0), listOf(0 to 0, 0 to 1, 0 to 2),
        listOf(0 to 0, 1 to 0, 0 to 1, 1 to 1),
        listOf(0 to 0, 1 to 0, 2 to 0, 0 to 1),
        listOf(0 to 0, 0 to 1, 0 to 2, 1 to 2),
        listOf(0 to 0, 1 to 0, 1 to 1, 2 to 1),
        listOf(1 to 0, 2 to 0, 0 to 1, 1 to 1),
        listOf(0 to 0, 1 to 0, 2 to 0, 1 to 1),
        listOf(0 to 0, 1 to 0, 2 to 0, 3 to 0)
    )

    private var tray: MutableList<List<Pair<Int, Int>>?> = mutableListOf(null, null, null)
    private var selected: Int? = null
    private var score = 0
    private var gameOverFired = false

    var onScoreChanged: ((Int) -> Unit)? = null
    var onGameOver: ((Int) -> Unit)? = null

    private val paintGridLine = Paint().apply { color = Color.parseColor("#D8DCCF"); strokeWidth = 2f }
    private val paintFilled = Paint().apply { color = Color.parseColor("#4F7D4A") }
    private val paintEmpty = Paint().apply { color = Color.parseColor("#FFFFFF") }
    private val paintTraySel = Paint().apply { color = Color.parseColor("#E7A64A"); alpha = 70 }
    private val paintPiece = Paint().apply { color = Color.parseColor("#315C33") }

    init { refillTray() }

    private fun refillTray() {
        for (i in 0..2) tray[i] = shapes[Random.nextInt(shapes.size)]
        selected = null
        checkGameOver()
    }

    private fun checkGameOver() {
        if (gameOverFired) return
        val anyPlayable = tray.any { piece -> piece != null && canPlaceAnywhere(piece) }
        if (!anyPlayable) {
            gameOverFired = true
            onGameOver?.invoke(score)
        }
    }

    private fun canPlaceAnywhere(piece: List<Pair<Int, Int>>): Boolean {
        for (r in 0 until gridSize) for (c in 0 until gridSize) if (canPlace(piece, c, r)) return true
        return false
    }

    private fun canPlace(piece: List<Pair<Int, Int>>, anchorCol: Int, anchorRow: Int): Boolean =
        piece.all { (dx, dy) ->
            val cx = anchorCol + dx; val cy = anchorRow + dy
            cx in 0 until gridSize && cy in 0 until gridSize && !grid[cy][cx]
        }

    private fun place(piece: List<Pair<Int, Int>>, anchorCol: Int, anchorRow: Int) {
        piece.forEach { (dx, dy) -> grid[anchorRow + dy][anchorCol + dx] = true }
        score += piece.size
        clearLines()
        onScoreChanged?.invoke(score)
    }

    private fun clearLines() {
        val fullRows = (0 until gridSize).filter { r -> grid[r].all { it } }
        val fullCols = (0 until gridSize).filter { c -> (0 until gridSize).all { r -> grid[r][c] } }
        fullRows.forEach { r -> for (c in 0 until gridSize) grid[r][c] = false }
        fullCols.forEach { c -> for (r in 0 until gridSize) grid[r][c] = false }
        val cleared = fullRows.size + fullCols.size
        if (cleared > 0) score += cleared * 15
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val gridArea = minOf(w.toFloat(), h * 0.72f)
        cell = gridArea / gridSize
        gridLeft = (w - gridArea) / 2f
        gridTop = h * 0.04f
        trayTop = gridTop + gridArea + h * 0.06f
        trayCell = minOf(w / 3f / 5f, (h - trayTop) / 5f)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.parseColor("#F7F8F4"))
        for (r in 0 until gridSize) for (c in 0 until gridSize) {
            val left = gridLeft + c * cell; val top = gridTop + r * cell
            canvas.drawRect(left + 1, top + 1, left + cell - 1, top + cell - 1, if (grid[r][c]) paintFilled else paintEmpty)
        }
        for (i in 0..gridSize) {
            canvas.drawLine(gridLeft, gridTop + i * cell, gridLeft + gridSize * cell, gridTop + i * cell, paintGridLine)
            canvas.drawLine(gridLeft + i * cell, gridTop, gridLeft + i * cell, gridTop + gridSize * cell, paintGridLine)
        }
        val slotWidth = width / 3f
        tray.forEachIndexed { idx, piece ->
            val slotLeft = idx * slotWidth
            if (selected == idx) canvas.drawRect(slotLeft, trayTop, slotLeft + slotWidth, trayTop + trayCell * 4, paintTraySel)
            piece?.let { shape ->
                val maxX = shape.maxOf { it.first }; val maxY = shape.maxOf { it.second }
                val offX = slotLeft + (slotWidth - (maxX + 1) * trayCell) / 2f
                val offY = trayTop + (trayCell * 4 - (maxY + 1) * trayCell) / 2f
                shape.forEach { (dx, dy) ->
                    canvas.drawRect(offX + dx * trayCell + 2, offY + dy * trayCell + 2, offX + (dx + 1) * trayCell - 2, offY + (dy + 1) * trayCell - 2, paintPiece)
                }
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_DOWN || gameOverFired) return true
        if (event.y >= trayTop) {
            val idx = (event.x / (width / 3f)).toInt().coerceIn(0, 2)
            if (tray[idx] != null) selected = if (selected == idx) null else idx
            invalidate()
            return true
        }
        val sel = selected ?: return true
        val piece = tray[sel] ?: return true
        val col = ((event.x - gridLeft) / cell).toInt()
        val row = ((event.y - gridTop) / cell).toInt()
        if (canPlace(piece, col, row)) {
            place(piece, col, row)
            tray[sel] = null
            selected = null
            if (tray.all { it == null }) refillTray() else checkGameOver()
            invalidate()
        }
        return true
    }
}
