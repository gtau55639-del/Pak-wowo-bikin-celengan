package com.sakutabung.app.ui

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.game.GameLimitManager
import com.sakutabung.app.game.Grades
import com.sakutabung.app.game.Question
import com.sakutabung.app.game.QuestionBank
import com.sakutabung.app.model.GameScore
import com.sakutabung.app.util.I18n
import com.sakutabung.app.util.BrainStatsManager
import com.sakutabung.app.util.CoinManager
import com.sakutabung.app.util.RewardManager
import java.time.LocalDate

/**
 * Ditambahkan di v1.1.0 - layar kuis matematika & bahasa Inggris.
 * Soal selalu diacak dan disesuaikan dengan kelas yang dipilih di pusat game.
 */
class QuizActivity : AppCompatActivity() {
    private fun t(key: String, vararg args: Any) = I18n.t(this, key, *args)
    private lateinit var db: DatabaseHelper
    private lateinit var questions: List<Question>
    private var index = 0
    private var correct = 0
    private lateinit var quizType: String

    private lateinit var progressLabel: TextView
    private lateinit var questionLabel: TextView
    private lateinit var optionButtons: List<Button>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DatabaseHelper(this)
        if (!com.sakutabung.app.util.PremiumManager.isPremium(this) && !GameLimitManager.consume(this)) {
            finish()
            return
        }
        quizType = intent.getStringExtra("quiz_type") ?: "math"
        title = if (quizType == "math") t("quiz_math") else t("quiz_english")

        val grade = Grades.byCode(GameLimitManager.getGrade(this))
        questions = if (quizType == "math") QuestionBank.math(grade, 10) else QuestionBank.english(grade, 10)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(20)) }
        progressLabel = TextView(this).apply { textSize = 13f; setTextColor(Color.parseColor("#6B746A")) }
        questionLabel = TextView(this).apply { textSize = 20f; setTypeface(null, Typeface.BOLD); setPadding(0, dp(12), 0, dp(20)) }
        root.addView(progressLabel)
        root.addView(questionLabel)

        optionButtons = (0..3).map { i ->
            Button(this).apply {
                setAllCaps(false); textSize = 16f
                layoutParams = LinearLayout.LayoutParams(-1, dp(58)).also { it.setMargins(0, dp(4), 0, dp(4)) }
                setOnClickListener { onAnswer(i) }
            }
        }
        optionButtons.forEach { root.addView(it) }
        setContentView(root)
        showQuestion()
    }

    private fun showQuestion() {
        val q = questions[index]
        progressLabel.text = "Soal ${index + 1} dari ${questions.size} \u2022 Benar: $correct"
        questionLabel.text = q.text
        q.options.forEachIndexed { i, opt ->
            optionButtons[i].text = opt
            optionButtons[i].isEnabled = true
            optionButtons[i].setBackgroundColor(Color.parseColor("#EDEFE7"))
        }
    }

    private fun onAnswer(choice: Int) {
        val q = questions[index]
        optionButtons.forEach { it.isEnabled = false }
        if (choice == q.correctIndex) {
            correct++
            optionButtons[choice].setBackgroundColor(Color.parseColor("#BFE3B4"))
        } else {
            optionButtons[choice].setBackgroundColor(Color.parseColor("#F3B3AE"))
            optionButtons[q.correctIndex].setBackgroundColor(Color.parseColor("#BFE3B4"))
        }
        optionButtons[0].postDelayed({ next() }, 700)
    }

    private fun next() {
        index++
        if (index >= questions.size) finishQuiz() else showQuestion()
    }

    private fun finishQuiz() {
        val score = correct * 10
        val gameId = if (quizType == "math") "math_quiz" else "english_quiz"
        val coins = com.sakutabung.app.util.GameRewardManager.record(this, gameId, score)
        val earnedXp = 10 + (score / 10).coerceAtMost(50)
        AlertDialog.Builder(this)
            .setTitle(t("quiz_done"))
            .setMessage("Kamu benar $correct dari ${questions.size} soal.\nSkor: $score\n+${coins} koin • +$earnedXp XP")
            .setCancelable(false)
            .setPositiveButton(t("close")) { _, _ -> finish() }
            .show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
