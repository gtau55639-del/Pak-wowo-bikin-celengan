package com.sakutabung.app.util

import com.sakutabung.app.model.Goal
import com.sakutabung.app.model.GoalStats
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.ceil

object Calculator {
    fun stats(goal: Goal, saved: Long, today: LocalDate = LocalDate.now()): GoalStats {
        val safeTarget = goal.target.coerceAtLeast(1L)
        val remaining = (safeTarget - saved).coerceAtLeast(0L)
        val end = LocalDate.parse(goal.deadline)
        val days = ChronoUnit.DAYS.between(today, end).coerceAtLeast(0L)
        val progress = ((saved.toDouble() / safeTarget.toDouble()) * 100.0).toInt().coerceIn(0, 100)
        val completed = remaining == 0L
        val overdue = !completed && LocalDate.parse(goal.deadline).isBefore(today)
        val divisor = days.coerceAtLeast(1L)
        val daily = if (completed) 0L else ceil(remaining.toDouble() / divisor).toLong()
        val weekly = if (completed) 0L else ceil(remaining.toDouble() / divisor * 7.0).toLong()
        return GoalStats(saved, remaining, days, progress, daily, weekly, completed, overdue)
    }
}
