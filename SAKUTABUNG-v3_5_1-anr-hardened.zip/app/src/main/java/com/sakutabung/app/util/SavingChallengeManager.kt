package com.sakutabung.app.util

import android.content.Context
import com.sakutabung.app.data.DatabaseHelper
import java.time.LocalDate

/** Offline saving challenges. Rewards are application points, never money. */
object SavingChallengeManager {
    data class Challenge(val id: String, val title: String, val description: String, val goal: Int, val progress: Int, val rewardXp: Int, val rewardCoins: Int, val claimed: Boolean)
    private const val PREFS = "saving_challenges"

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun started(c: Context, id: String): String? = p(c).getString("start_$id", null)?.takeIf { it.isNotBlank() }
    private fun ensureStarted(c: Context, id: String) {
        if (started(c, id) == null) p(c).edit().putString("start_$id", LocalDate.now().toString()).apply()
    }
    private fun claimed(c: Context, id: String) = p(c).getBoolean("claimed_$id", false)

    fun all(c: Context): List<Challenge> {
        val db = DatabaseHelper(c)
        val tx = db.transactions()
        val today = LocalDate.now()
        val dates = tx.mapNotNull { runCatching { LocalDate.parse(it.date) }.getOrNull() }.toSet()

        ensureStarted(c, "seven_days")
        ensureStarted(c, "hundred_k")
        ensureStarted(c, "no_skip")

        val sevenStart = LocalDate.parse(started(c, "seven_days")!!)
        val sevenProgress = (0L..6L).count { dates.contains(sevenStart.plusDays(it)) && !sevenStart.plusDays(it).isAfter(today) }.toInt()
        val monthStart = today.minusDays(29)
        val hundredProgress = tx.filter { runCatching { val d = LocalDate.parse(it.date); !d.isBefore(monthStart) && !d.isAfter(today) }.getOrDefault(false) }.sumOf { it.amount }.coerceAtMost(100_000L).toInt()
        val noSkipStart = LocalDate.parse(started(c, "no_skip")!!)
        val elapsed = java.time.temporal.ChronoUnit.DAYS.between(noSkipStart, today).toInt().coerceAtLeast(0)
        val noSkipProgress = (0..elapsed.coerceAtMost(13)).count { dates.contains(noSkipStart.plusDays(it.toLong())) }

        return listOf(
            Challenge("seven_days", "7 Hari Menabung", "Catat menabung setiap hari selama 7 hari sejak tantangan dimulai.", 7, sevenProgress, 80, 20, claimed(c, "seven_days")),
            Challenge("hundred_k", "Rp100.000 Pertama", "Catat total minimal Rp100.000 dalam 30 hari terakhir.", 100_000, hundredProgress, 100, 25, claimed(c, "hundred_k")),
            Challenge("no_skip", "Konsisten 14 Hari", "Usahakan memiliki catatan menabung setiap hari selama 14 hari.", 14, noSkipProgress, 14, 15, claimed(c, "no_skip"))
        )
    }

    fun claim(c: Context, id: String): Boolean {
        val challenge = all(c).firstOrNull { it.id == id } ?: return false
        if (challenge.claimed || challenge.progress < challenge.goal) return false
        p(c).edit().putBoolean("claimed_$id", true).apply()
        RewardManager.addXp(c, challenge.rewardXp)
        CoinManager.add(c, challenge.rewardCoins)
        return true
    }

    fun export(c: Context): org.json.JSONObject = org.json.JSONObject().apply {
        listOf("seven_days", "hundred_k", "no_skip").forEach { id ->
            put("start_$id", started(c, id) ?: "")
            put("claimed_$id", claimed(c, id))
        }
    }

    fun import(c: Context, o: org.json.JSONObject?) {
        if (o == null) return
        val e = p(c).edit()
        listOf("seven_days", "hundred_k", "no_skip").forEach { id ->
            e.putString("start_$id", o.optString("start_$id", ""))
            e.putBoolean("claimed_$id", o.optBoolean("claimed_$id", false))
        }
        e.apply()
    }
}
