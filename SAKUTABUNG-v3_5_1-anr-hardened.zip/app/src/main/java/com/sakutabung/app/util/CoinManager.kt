package com.sakutabung.app.util

import android.content.Context

/** v2.4: coin wallet earned from brain games and completed savings goals. */
object CoinManager {
    private const val PREFS = "sakutabung_coin_wallet"
    private const val KEY_BALANCE = "balance"
    private const val KEY_CLAIMED = "claimed"

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun balance(c: Context): Int = p(c).getInt(KEY_BALANCE, 0).coerceAtLeast(0)

    @Synchronized
    fun add(c: Context, amount: Int): Int {
        if (amount <= 0) return balance(c)
        val next = (balance(c).toLong() + amount).coerceAtMost(2_000_000L).toInt()
        p(c).edit().putInt(KEY_BALANCE, next).apply()
        return next
    }

    @Synchronized
    fun setBalance(c: Context, amount: Int) { p(c).edit().putInt(KEY_BALANCE, amount.coerceAtLeast(0)).apply() }

    @Synchronized
    fun spend(c: Context, amount: Int): Boolean {
        if (amount <= 0 || balance(c) < amount) return false
        p(c).edit().putInt(KEY_BALANCE, balance(c) - amount).apply()
        return true
    }

    fun claimed(c: Context, key: String): Boolean = p(c).getStringSet(KEY_CLAIMED, emptySet())?.contains(key) == true

    @Synchronized
    fun claim(c: Context, key: String, amount: Int): Boolean {
        if (amount <= 0 || claimed(c, key)) return false
        val set = (p(c).getStringSet(KEY_CLAIMED, emptySet()) ?: emptySet()).toMutableSet()
        set.add(key)
        p(c).edit().putStringSet(KEY_CLAIMED, set).apply()
        add(c, amount)
        return true
    }

    fun gameReward(score: Int): Int = when {
        score >= 100 -> 20
        score >= 80 -> 12
        score >= 50 -> 6
        else -> 0
    }

    fun goalReward(): Int = 50
}
