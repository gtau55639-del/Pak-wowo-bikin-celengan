package com.sakutabung.app.ui

import android.graphics.Typeface
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.R
import com.sakutabung.app.util.Format
import com.sakutabung.app.util.SavingChallengeManager

class SavingChallengeActivity : AppCompatActivity() {
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun color(id:Int)=androidx.core.content.ContextCompat.getColor(this,id)
    override fun onCreate(b:Bundle?){super.onCreate(b); build()}
    override fun onResume(){super.onResume(); if(!isFinishing) build()}
    private fun build(){
        val scroll=ScrollView(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(30));setBackgroundResource(R.color.background)}
        root.addView(TextView(this).apply{text="Tantangan Menabung";textSize=28f;setTypeface(null,Typeface.BOLD);setTextColor(color(R.color.text))})
        root.addView(TextView(this).apply{text="Tantangan dihitung dari catatan tabungan fisik di perangkat dan tetap berjalan tanpa internet.";textSize=13f;setTextColor(color(R.color.muted));setPadding(0,dp(5),0,dp(15))})
        SavingChallengeManager.all(this).forEach { ch ->
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(15),dp(16),dp(15));setBackgroundResource(R.drawable.bg_card);layoutParams=LinearLayout.LayoutParams(-1,-2).also{it.setMargins(0,0,0,dp(10))}}
            card.addView(TextView(this).apply{text=ch.title;textSize=18f;setTypeface(null,Typeface.BOLD);setTextColor(color(R.color.text))})
            card.addView(TextView(this).apply{text=ch.description;textSize=13f;setTextColor(color(R.color.muted));setPadding(0,dp(5),0,dp(8))})
            val progress=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=ch.goal;this.progress=ch.progress;layoutParams=LinearLayout.LayoutParams(-1,dp(8)).also{it.setMargins(0,0,0,dp(7))}}
            card.addView(progress)
            val progressText=if(ch.id=="hundred_k") "${Format.rupiah(ch.progress.toLong())} / ${Format.rupiah(ch.goal.toLong())}" else "${ch.progress} / ${ch.goal}"
            card.addView(TextView(this).apply{text=progressText;textSize=13f;setTextColor(color(R.color.text))})
            card.addView(TextView(this).apply{text="Hadiah: ${ch.rewardXp} XP + ${ch.rewardCoins} koin";textSize=12f;setTextColor(color(R.color.muted));setPadding(0,dp(4),0,dp(6))})
            val button=Button(this).apply{setAllCaps(false);text=when{ch.claimed->"Sudah diklaim";ch.progress>=ch.goal->"Klaim hadiah";else->"Belum selesai"};isEnabled=!ch.claimed && ch.progress>=ch.goal}
            button.setOnClickListener{if(SavingChallengeManager.claim(this,ch.id)){Toast.makeText(this,"Hadiah berhasil diklaim",Toast.LENGTH_SHORT).show();build()}}
            card.addView(button)
            root.addView(card)
        }
        root.addView(Button(this).apply{setAllCaps(false);text="Kembali";setOnClickListener{finish()}})
        scroll.addView(root);setContentView(scroll)
    }
}
