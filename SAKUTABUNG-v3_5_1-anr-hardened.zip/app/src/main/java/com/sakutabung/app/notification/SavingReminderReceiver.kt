package com.sakutabung.app.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.sakutabung.app.R
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.util.Calculator
import com.sakutabung.app.util.Format

class SavingReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("goalId", -1L)
        if (id < 0) return
        val db = DatabaseHelper(context)
        val goal = db.goal(id) ?: return
        if (!goal.active) { ReminderScheduler.cancel(context, id); return }
        val stats = Calculator.stats(goal, db.saved(id))
        if (stats.remaining <= 0L) { ReminderScheduler.cancel(context, id); return }
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel("saving", "Pengingat menabung", NotificationManager.IMPORTANCE_DEFAULT))
        val notification = NotificationCompat.Builder(context, "saving")
            .setSmallIcon(R.drawable.ic_stat_piggy)
            .setContentTitle("Waktunya menabung!")
            .setContentText("${Format.rupiah(stats.daily)} • ${goal.name}")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Target berikutnya sekitar ${Format.rupiah(stats.daily)}. Tetap sedikit demi sedikit sampai jadi!"))
            .setAutoCancel(true)
            .build()
        manager.notify(id.toInt(), notification)
    }
}
