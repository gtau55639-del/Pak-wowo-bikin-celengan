package com.sakutabung.app.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View

/**
 * Ditambahkan di v1.1.0 - mini game puzzle geser (15-puzzle klasik).
 * Susun angka 1-15 berurutan dengan kotak kosong di pojok kanan bawah.
 * Selalu diacak dari kondisi tersusun lewat gerakan sah, jadi selalu bisa diselesaikan.
 */
class PuzzleView(context: Context) : View(context) {
    private val size = 4
    private var tiles = IntArray(size * size) { it }
    private var cell = 0f
    private var moves = 0
    private var startTime = System.currentTimeMillis()
    private var solved = false

    var onSolved: ((score: Int, moves: Int) -> Unit)? = null

    private val paintTile = Paint().apply { color = Color.parseColor("#4F7D4A") }
    private val paintBlank = Paint().apply { color = Color.parseColor("#F7F8F4") }
    private val paintText = Paint().apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val paintGrid = Paint().apply { color = Color.parseColor("#D8DCCF"); strokeWidth = 2f }

    init { shuffle() }

    private fun shuffle() {
        tiles = IntArray(size * size) { it }
        var blank = size * size - 1
        repeat(300) {
            val neighbors = neighborIndexes(blank)
            val pick = neighbors.random()
            tiles[blank] = tiles[pick]; tiles[pick] = 0
            blank = pick
        }
        moves = 0
        solved = false
        startTime = System.currentTimeMillis()
    }

    private fun neighborIndexes(idx: Int): List<Int> {
        val r = idx / size; val c = idx % size
        val list = mutableListOf<Int>()
        if (r > 0) list.add(idx - size)
        if (r < size - 1) list.add(idx + size)
        if (c > 0) list.add(idx - 1)
        if (c < size - 1) list.add(idx + 1)
        return list
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cell = minOf(w, h) / size.toFloat()
        paintText.textSize = cell * 0.4f
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.parseColor("#F7F8F4"))
        for (i in tiles.indices) {
            val r = i / size; val c = i % size
            val left = c * cell; val top = r * cell
            val value = tiles[i]
            canvas.drawRect(left + 2, top + 2, left + cell - 2, top + cell - 2, if (value == 0) paintBlank else paintTile)
            if (value != 0) canvas.drawText(value.toString(), left + cell / 2, top + cell / 2 + paintText.textSize / 3, paintText)
        }
        for (i in 0..size) {
            canvas.drawLine(0f, i * cell, size * cell, i * cell, paintGrid)
            canvas.drawLine(i * cell, 0f, i * cell, size * cell, paintGrid)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_DOWN || solved) return true
        val c = (event.x / cell).toInt().coerceIn(0, size - 1)
        val r = (event.y / cell).toInt().coerceIn(0, size - 1)
        val idx = r * size + c
        val blankIdx = tiles.indexOf(0)
        if (idx in neighborIndexes(blankIdx)) {
            tiles[blankIdx] = tiles[idx]; tiles[idx] = 0
            moves++
            invalidate()
            if (isSolved()) {
                solved = true
                val seconds = ((System.currentTimeMillis() - startTime) / 1000).toInt()
                val score = (1000 - moves * 4 - seconds * 2).coerceAtLeast(50)
                onSolved?.invoke(score, moves)
            }
        }
        return true
    }

    private fun isSolved(): Boolean = tiles.indices.all { i -> tiles[i] == (i + 1) % (size * size) }
}
