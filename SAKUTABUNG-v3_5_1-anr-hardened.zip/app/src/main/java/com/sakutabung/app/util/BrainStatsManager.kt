package com.sakutabung.app.util

import android.content.Context

/** v2.6: local brain-training progress. */
object BrainStatsManager {
    private const val PREFS = "sakutabung_brain_stats"
    private const val BEST = "best"
    private const val TOTAL = "total"
    private const val PLAYED = "played"
    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun best(c: Context) = p(c).getInt(BEST, 0)
    fun total(c: Context) = p(c).getLong(TOTAL, 0L)
    fun played(c: Context) = p(c).getInt(PLAYED, 0)
    fun record(c: Context, score: Int) {
        val sp = p(c)
        sp.edit().putInt(BEST, maxOf(best(c), score)).putLong(TOTAL, total(c) + score).putInt(PLAYED, played(c) + 1).apply()
    }
}
