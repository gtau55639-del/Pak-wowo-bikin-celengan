package com.sakutabung.app.notification

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.sakutabung.app.data.DatabaseHelper
import java.util.Calendar

object ReminderScheduler {
    private fun pending(context: Context, goalId: Long, flags: Int): PendingIntent = PendingIntent.getBroadcast(
        context, goalId.toInt(), Intent(context, SavingReminderReceiver::class.java).putExtra("goalId", goalId), flags
    )

    fun schedule(context: Context, goalId: Long, hour: Int, minute: Int, frequency: String) {
        val am = context.getSystemService(AlarmManager::class.java)
        cancel(context, goalId)
        val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hour.coerceIn(0,23)); set(Calendar.MINUTE, minute.coerceIn(0,59)); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }
        when {
            frequency.contains("minggu", true) -> {
                if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.WEEK_OF_YEAR, 1)
                am.setInexactRepeating(AlarmManager.RTC_WAKEUP, c.timeInMillis, AlarmManager.INTERVAL_DAY * 7L, pending(context, goalId, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            }
            else -> {
                if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1)
                am.setInexactRepeating(AlarmManager.RTC_WAKEUP, c.timeInMillis, AlarmManager.INTERVAL_DAY, pending(context, goalId, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            }
        }
    }

    fun scheduleAll(context: Context) {
        val db = DatabaseHelper(context)
        db.goals().filter { it.active }.forEach { schedule(context, it.id, it.reminderHour, it.reminderMinute, it.frequency) }
    }

    fun cancel(context: Context, goalId: Long) {
        val am = context.getSystemService(AlarmManager::class.java)
        runCatching { am.cancel(pending(context, goalId, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)) }
    }
}
