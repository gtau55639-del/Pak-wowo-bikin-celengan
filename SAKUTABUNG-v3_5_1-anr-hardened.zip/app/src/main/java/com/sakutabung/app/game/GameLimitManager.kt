package com.sakutabung.app.game

import android.content.Context
import com.sakutabung.app.util.PremiumManager

/**
 * Ditambahkan di v1.1.0.
 * Mengatur "kesempatan main" mini game: pengguna baru dapat kesempatan awal,
 * lalu mendapat tambahan kesempatan setiap kali menabung.
 */
object GameLimitManager {
    private const val PREFS = "sakutabung_game_prefs"
    private const val KEY_LIMIT = "limit_balance"
    private const val KEY_INITIALIZED = "limit_initialized"
    private const val KEY_GRADE = "selected_grade"

    const val STARTING_LIMIT = 15
    private const val RUPIAH_PER_LIMIT = 10_000L
    private const val MAX_EARN_PER_SAVING = 10

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Memberi kesempatan awal (sekitar 15x main) ke pengguna baru, sekali saja. */
    fun ensureInitialized(context: Context) {
        val p = prefs(context)
        if (!p.getBoolean(KEY_INITIALIZED, false)) {
            p.edit().putBoolean(KEY_INITIALIZED, true).putInt(KEY_LIMIT, STARTING_LIMIT).apply()
        }
    }

    fun getLimit(context: Context): Int {
        ensureInitialized(context)
        if (PremiumManager.isPremium(context)) return Int.MAX_VALUE
        return prefs(context).getInt(KEY_LIMIT, STARTING_LIMIT)
    }

    /** Dipanggil saat pengguna mulai main. Return false jika kesempatan habis. */
    @Synchronized
    fun consume(context: Context): Boolean {
        val current = getLimit(context)
        if (current <= 0) return false
        prefs(context).edit().putInt(KEY_LIMIT, current - 1).apply()
        return true
    }

    /**
     * Mengembalikan 1 kesempatan main jika pengguna membatalkan game yang baru dimulai
     * (pasangan dari [consume]). Pengguna Premium tidak pernah dikurangi, jadi tidak ada yang dikembalikan.
     */
    @Synchronized
    fun refund(context: Context): Boolean {
        if (PremiumManager.isPremium(context)) return false
        ensureInitialized(context)
        val current = prefs(context).getInt(KEY_LIMIT, STARTING_LIMIT)
        prefs(context).edit().putInt(KEY_LIMIT, current + 1).apply()
        return true
    }

    /**
     * Dipanggil setelah pengguna berhasil menabung. Setiap kelipatan Rp10.000 yang
     * ditabung memberi +1 kesempatan main (minimal 1, maksimal 10 per transaksi
     * agar tidak disalahgunakan). Mengembalikan jumlah kesempatan yang didapat.
     */
    @Synchronized
    fun award(context: Context, savedAmount: Long): Int {
        ensureInitialized(context)
        val earned = (savedAmount / RUPIAH_PER_LIMIT).toInt().coerceIn(0, MAX_EARN_PER_SAVING)
        val current = prefs(context).getInt(KEY_LIMIT, STARTING_LIMIT)
        prefs(context).edit().putInt(KEY_LIMIT, current + earned).apply()
        return earned
    }

    fun getGrade(context: Context): String = prefs(context).getString(KEY_GRADE, "SMP7") ?: "SMP7"
    fun setGrade(context: Context, code: String) { prefs(context).edit().putString(KEY_GRADE, code).apply() }
}
