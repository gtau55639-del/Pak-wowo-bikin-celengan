package com.sakutabung.app.ui

import android.graphics.Typeface
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.R
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.util.CoinManager
import com.sakutabung.app.util.RewardManager
import com.sakutabung.app.util.PremiumManager
import java.time.LocalDate

class RewardCenterActivity: AppCompatActivity(){
 private lateinit var db:DatabaseHelper
 private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
 private fun color(id:Int)=androidx.core.content.ContextCompat.getColor(this,id)
 override fun onCreate(b:Bundle?){super.onCreate(b);db=DatabaseHelper(this);build()}
 override fun onResume(){super.onResume();if(::db.isInitialized)build()}
 private fun build(){
  val s=ScrollView(this);val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(30));setBackgroundResource(R.color.background)}
  r.addView(TextView(this).apply{text="Reward Center";textSize=28f;setTypeface(null,Typeface.BOLD);setTextColor(color(R.color.text))})
  r.addView(TextView(this).apply{text="Satu sistem untuk XP, level, misi, streak, dan reward.";textSize=13f;setTextColor(color(R.color.muted));setPadding(0,dp(4),0,dp(14))})
  val level=RewardManager.level(this);val pr=RewardManager.progress(this);val xp=RewardManager.xp(this)
  r.addView(card().apply{addView(TextView(this@RewardCenterActivity).apply{text="Level $level";textSize=22f;setTypeface(null,Typeface.BOLD);setTextColor(color(R.color.text))});addView(TextView(this@RewardCenterActivity).apply{text="$xp XP  •  ${100-pr} XP menuju level berikutnya";textSize=13f;setTextColor(color(R.color.muted));setPadding(0,dp(5),0,dp(8))});addView(ProgressBar(this@RewardCenterActivity,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=pr});addView(TextView(this@RewardCenterActivity).apply{text="Login streak: ${RewardManager.streak(this@RewardCenterActivity)} hari  •  Streak menabung: ${RewardManager.savingStreak(this@RewardCenterActivity)} hari";textSize=13f;setTextColor(color(R.color.muted));setPadding(0,dp(8),0,0)})})
  r.addView(section("Milestone Premium"))
  listOf(20 to "Premium 3 hari",50 to "Premium 7 hari",100 to "Premium permanen").forEach{(lv,label)->val claimed=RewardManager.rewardClaimed(this,lv);val available=level>=lv&&!claimed;r.addView(card().apply{addView(TextView(this@RewardCenterActivity).apply{text="Level $lv";textSize=17f;setTypeface(null,Typeface.BOLD);setTextColor(color(R.color.text))});addView(TextView(this@RewardCenterActivity).apply{text="$label • ${when{claimed->"Sudah diklaim";available->"Tersedia";else->"Belum terbuka"}}";textSize=13f;setTextColor(color(if(available)R.color.primary else R.color.muted));setPadding(0,dp(4),0,dp(7))});if(available)addView(Button(this@RewardCenterActivity).apply{text="Klaim reward";setAllCaps(false);setOnClickListener{if(RewardManager.claimLevelReward(this@RewardCenterActivity,lv)){Toast.makeText(this@RewardCenterActivity,"Reward berhasil diklaim",Toast.LENGTH_SHORT).show();build()}}})})}
  r.addView(section("Hadiah harian"));r.addView(card().apply{addView(TextView(this@RewardCenterActivity).apply{text=if(RewardManager.dailyClaimed(this@RewardCenterActivity))"Sudah diklaim hari ini" else "Klaim +5 koin dan +15 XP sekali sehari.";textSize=14f;setTextColor(color(R.color.text))});if(!RewardManager.dailyClaimed(this@RewardCenterActivity))addView(Button(this@RewardCenterActivity).apply{text="Klaim hadiah";setAllCaps(false);setOnClickListener{RewardManager.claimDaily(this@RewardCenterActivity);build()}})})
  r.addView(section("Misi hari ini"));mission(r,"save","Menabung hari ini","Catat setidaknya satu tabungan fisik hari ini.",db.transactions().any{it.date==LocalDate.now().toString()},15,20);mission(r,"game","Main game","Selesaikan minimal satu game offline.",db.recentGameScores(100).any{it.date==LocalDate.now().toString()},12,20);mission(r,"goal","Target selesai","Selesaikan target pada hari ini.",db.goals().any{!it.active&&db.saved(it.id)>=it.target&&db.transactions(it.id).any{tx->tx.date==LocalDate.now().toString()}},30,35);mission(r,"coin","Kolektor koin","Miliki minimal 50 koin.",CoinManager.balance(this)>=50,20,25)
  r.addView(section("OPIMOUS"));r.addView(card().apply{addView(TextView(this@RewardCenterActivity).apply{text=when{PremiumManager.isPermanent(this@RewardCenterActivity)->"Premium permanen";PremiumManager.isPremium(this@RewardCenterActivity)->"Trial aktif • ${PremiumManager.daysRemaining(this@RewardCenterActivity)} hari";else->"Premium diperoleh melalui Level 20, 50, dan 100"};textSize=14f;setTextColor(color(R.color.text))})})
  s.addView(r);setContentView(s)
 }
 private fun mission(r:LinearLayout,id:String,title:String,desc:String,done:Boolean,coins:Int,xp:Int){r.addView(card().apply{addView(TextView(this@RewardCenterActivity).apply{text=title;textSize=16f;setTypeface(null,Typeface.BOLD);setTextColor(color(R.color.text))});addView(TextView(this@RewardCenterActivity).apply{text=desc;textSize=13f;setTextColor(color(R.color.muted));setPadding(0,dp(4),0,dp(6))});when{RewardManager.missionClaimed(this@RewardCenterActivity,id)->addView(TextView(this@RewardCenterActivity).apply{text="Sudah diklaim";textSize=13f;setTextColor(color(R.color.muted))});done->addView(Button(this@RewardCenterActivity).apply{text="Klaim +$coins koin  +$xp XP";setAllCaps(false);setOnClickListener{RewardManager.claimMission(this@RewardCenterActivity,id,coins,xp);build()}});else->addView(TextView(this@RewardCenterActivity).apply{text="Belum selesai";textSize=13f;setTextColor(color(R.color.muted))})}})}
 private fun section(x:String)=TextView(this).apply{text=x;textSize=18f;setTypeface(null,Typeface.BOLD);setTextColor(color(R.color.text));setPadding(0,dp(13),0,dp(7))}
 private fun card()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(15),dp(16),dp(15));setBackgroundResource(R.drawable.bg_card);layoutParams=LinearLayout.LayoutParams(-1,-2).also{it.setMargins(0,0,0,dp(9))}}
}
