package com.sakutabung.app.util

import android.content.Context
import java.time.LocalDate
import java.time.temporal.WeekFields
import java.util.Locale

/** v2.4: real saving-action quota. It is separate from game chances. */
object SavingLimitManager {
    const val WEEKLY_FREE_LIMIT = 6
    private const val PREFS = "sakutabung_saving_limits"
    private const val KEY_WEEK = "week"
    private const val KEY_USED = "used"
    private const val KEY_EXTRA = "extra"
    private const val KEY_LAST_SOURCE = "last_consume_source"

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun week(): String {
        val wf = WeekFields.of(Locale.getDefault())
        val d = LocalDate.now()
        return "${d.get(wf.weekBasedYear())}-${d.get(wf.weekOfWeekBasedYear())}"
    }
    private fun normalize(c: Context) {
        val sp = p(c); val w = week()
        if (sp.getString(KEY_WEEK, null) != w) sp.edit().putString(KEY_WEEK, w).putInt(KEY_USED, 0).apply()
    }
    fun used(c: Context): Int { normalize(c); return p(c).getInt(KEY_USED, 0) }
    fun extra(c: Context): Int = p(c).getInt(KEY_EXTRA, 0)
    fun available(c: Context): Int {
        if (PremiumManager.isPremium(c)) return Int.MAX_VALUE
        normalize(c)
        return (WEEKLY_FREE_LIMIT - used(c) + extra(c)).coerceAtLeast(0)
    }
    @Synchronized
    fun consume(c: Context): Boolean {
        if (PremiumManager.isPremium(c)) return true
        normalize(c)
        val sp = p(c)
        val used = sp.getInt(KEY_USED, 0)
        val extra = sp.getInt(KEY_EXTRA, 0)
        return when {
            used < WEEKLY_FREE_LIMIT -> {
                sp.edit().putInt(KEY_USED, used + 1).putString(KEY_LAST_SOURCE, "weekly").apply()
                true
            }
            extra > 0 -> {
                sp.edit().putInt(KEY_EXTRA, extra - 1).putString(KEY_LAST_SOURCE, "extra").apply()
                true
            }
            else -> false
        }
    }
    /** Mengembalikan sumber kuota yang terakhir dikonsumsi jika transaksi gagal. */
    @Synchronized
    fun refund(c: Context): Boolean {
        if (PremiumManager.isPremium(c)) return false
        normalize(c)
        val sp = p(c)
        return when (sp.getString(KEY_LAST_SOURCE, null)) {
            "weekly" -> {
                val used = sp.getInt(KEY_USED, 0)
                if (used <= 0) false else {
                    sp.edit().putInt(KEY_USED, used - 1).remove(KEY_LAST_SOURCE).apply(); true
                }
            }
            "extra" -> {
                val extra = sp.getInt(KEY_EXTRA, 0)
                if (extra >= 10_000) false else {
                    sp.edit().putInt(KEY_EXTRA, (extra + 1).coerceAtMost(10_000)).remove(KEY_LAST_SOURCE).apply(); true
                }
            }
            else -> false
        }
    }
    fun setExtra(c: Context, amount: Int) { p(c).edit().putInt(KEY_EXTRA, amount.coerceIn(0, 10_000)).apply() }

    fun canAddExtra(c: Context, amount: Int): Boolean {
        if (amount <= 0 || PremiumManager.isPremium(c)) return false
        return extra(c).toLong() + amount <= 10_000L
    }

    fun addExtra(c: Context, amount: Int): Boolean {
        if (!canAddExtra(c, amount)) return false
        val next = extra(c) + amount
        p(c).edit().putInt(KEY_EXTRA, next).apply()
        return true
    }
}
