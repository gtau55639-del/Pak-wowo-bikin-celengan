package com.sakutabung.app.ui

import android.graphics.Typeface
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.R
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.game.GameLimitManager
import com.sakutabung.app.model.GameScore
import com.sakutabung.app.util.BrainStatsManager
import com.sakutabung.app.util.CoinManager
import com.sakutabung.app.util.PremiumManager
import com.sakutabung.app.util.RewardManager
import java.time.LocalDate
import kotlin.random.Random

class BrainGamesActivity : AppCompatActivity() {
    private val games = listOf(
        "Memory Match" to "memory", "Sequence Otak" to "sequence", "Logika Cepat" to "logic",
        "Acak Kata" to "word", "Number Grid" to "grid", "Matematika Kilat" to "math",
        "Reaction Logic" to "reaction", "Pattern Master" to "pattern", "Deteksi Pola" to "detect",
        "Trivia Pintar" to "trivia"
    )
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onCreate(b: Bundle?) { super.onCreate(b); build() }
    override fun onResume(){ super.onResume(); if(!isFinishing) build() }

    private fun build(){
        val scroll=ScrollView(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(24))}
        root.addView(TextView(this).apply{text="Brain Center";textSize=28f;setTypeface(null,Typeface.BOLD)})
        root.addView(TextView(this).apply{text="Latih memori, logika, angka, pola, bahasa, dan kecepatan berpikir.";textSize=13f;setPadding(0,dp(4),0,dp(12))})
        root.addView(card().apply{
            addView(TextView(this@BrainGamesActivity).apply{text="Statistik otak";textSize=18f;setTypeface(null,Typeface.BOLD)})
            addView(TextView(this@BrainGamesActivity).apply{text="Best Score: ${BrainStatsManager.best(this@BrainGamesActivity)} • Total Score: ${BrainStatsManager.total(this@BrainGamesActivity)}\nGame selesai: ${BrainStatsManager.played(this@BrainGamesActivity)}";textSize=13f;setPadding(0,dp(5),0,0)})
        })
        games.forEach{(name,id)->
            root.addView(card().apply{
                addView(TextView(this@BrainGamesActivity).apply{text=name;textSize=17f;setTypeface(null,Typeface.BOLD)})
                addView(TextView(this@BrainGamesActivity).apply{text="Latihan singkat • skor + XP + koin";textSize=12f;setPadding(0,dp(3),0,dp(7))})
                addView(Button(this@BrainGamesActivity).apply{text="Mulai";setAllCaps(false);setOnClickListener{start(id)}})
            })
        }
        scroll.addView(root);setContentView(scroll)
    }

    private fun start(id:String){
        if(!PremiumManager.isPremium(this) && GameLimitManager.getLimit(this)<=0){
            AlertDialog.Builder(this).setTitle("Kesempatan habis").setMessage("Gunakan limit game yang tersedia atau tukarkan koin di Toko Koin.").setPositiveButton("OK",null).show();return
        }
        if(!PremiumManager.isPremium(this)) GameLimitManager.consume(this)
        when(id){
            "memory"->memory(); "sequence"->sequence(); "logic"->logic(); "word"->word(); "grid"->grid()
            "math"->math(); "reaction"->reaction(); "pattern"->pattern(); "detect"->detect(); "trivia"->trivia()
        }
    }

    private fun answer(title:String, body:String, options:List<String>, correct:Int, gameId:String){
        val indexed = options.mapIndexed { index, text -> index to text }.shuffled()
        val shown = indexed.map { it.second }
        val shownCorrect = indexed.indexOfFirst { it.first == correct }
        AlertDialog.Builder(this).setTitle(title).setMessage(body).setNegativeButton("Batal") { _, _ -> GameLimitManager.refund(this) }.setItems(shown.toTypedArray()){ d, which ->
            val gained=if(which==shownCorrect) 100 else 0
            if(gained>0) Toast.makeText(this,"Benar! +100",Toast.LENGTH_SHORT).show() else Toast.makeText(this,"Belum tepat. Coba lagi!",Toast.LENGTH_SHORT).show()
            finishRound(gameId, gained)
            d.dismiss()
        }.show()
    }
    private fun finishRound(gameId:String, gained:Int){
        if(gained<=0)return
        val score=gained
        val coins = com.sakutabung.app.util.GameRewardManager.record(this, "brain_$gameId", score)
        Toast.makeText(this,"+${coins}  • +10 XP",Toast.LENGTH_SHORT).show()
    }
    private fun memory(){val b=Random.nextInt(1,5);answer("Memory Match","Ingat pasangan: A${Random.nextInt(1,5)} • B$b. Pasangan B berapa?",listOf("B$b","B${b%4+1}","B${(b+1)%4+1}"),0,"memory")}
    private fun sequence(){val s=Random.nextInt(2,9);val step=Random.nextInt(2,6);val a=(0..2).map{s+it*step};answer("Sequence Otak","Lanjutkan pola: ${a.joinToString(", ")}, ?",listOf("${a[2]+step}","${a[2]+step+1}","${a[2]+step-1}"),0,"sequence")}
    private fun logic(){answer("Logika Cepat","Jika semua A adalah B, dan semua B adalah C, maka semua A adalah...",listOf("C","B saja","Tidak bisa diketahui"),0,"logic")}
    private fun word(){val w=listOf("TABUNG","TARGET","HEMAT","CELENGAN","MIMPI").random();val m=w.toList().shuffled().joinToString("");answer("Acak Kata","Susun kata: $m",listOf(w,"SAKU","KOIN"),0,"word")}
    private fun grid(){val n=Random.nextInt(1,10);answer("Number Grid","Angka: $n, ${n+1}, ${n+2}. Berikutnya?",listOf("${n+3}","${n+5}","${n+4}"),0,"grid")}
    private fun math(){val a=Random.nextInt(5,30);val b=Random.nextInt(2,15);answer("Matematika Kilat","$a + $b = ?",listOf("${a+b}","${a+b+2}","${a+b-2}"),0,"math")}
    private fun reaction(){answer("Reaction Logic","Mana yang berbeda?",listOf("▲ ▲ ▲","▲ ▲ ■","▲ ▲ ▲"),1,"reaction")}
    private fun pattern(){answer("Pattern Master","Pola: 2, 4, 8, 16. Berikutnya?",listOf("32","24","30"),0,"pattern")}
    private fun detect(){answer("Deteksi Pola","Mana urutan yang mengikuti 2, 4, 8, 16?",listOf("32","24","30"),0,"detect")}
    private fun trivia(){answer("Trivia Pintar","Planet yang dikenal sebagai Planet Merah adalah...",listOf("Mars","Venus","Jupiter"),0,"trivia")}
    private fun card()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(15),dp(16),dp(15));setBackgroundResource(R.drawable.bg_card);layoutParams=LinearLayout.LayoutParams(-1,-2).also{it.setMargins(0,0,0,dp(9))}}
}
