package com.sakutabung.app.ui

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import com.sakutabung.app.R
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.util.Format

class SakuTabungWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val db=DatabaseHelper(context); val views=RemoteViews(context.packageName,R.layout.widget_sakutabung)
        views.setTextViewText(R.id.widget_title,"SakuTabung")
        views.setTextViewText(R.id.widget_total,Format.rupiah(db.totalSaved()))
        views.setTextViewText(R.id.widget_goals,"${db.activeCount()} target aktif")
        ids.forEach { manager.updateAppWidget(it,views) }
    }
}
