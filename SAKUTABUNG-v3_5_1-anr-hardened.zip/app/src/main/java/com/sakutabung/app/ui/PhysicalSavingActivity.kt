package com.sakutabung.app.ui

import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.R
import com.sakutabung.app.util.PhysicalSavingManager

class PhysicalSavingActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = androidx.core.content.ContextCompat.getColor(this, id)

    override fun onCreate(state: Bundle?) { super.onCreate(state); build() }

    private fun build() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(30)); setBackgroundResource(R.color.background) }
        root.addView(TextView(this).apply { text = "Celengan Fisik"; textSize = 26f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(color(R.color.text)) })
        root.addView(TextView(this).apply {
            text = "Catat tempat kamu menyimpan uang secara fisik. SakuTabung tidak menyimpan atau memindahkan uang."
            textSize = 13.5f; setTextColor(color(R.color.muted)); setPadding(0, dp(5), 0, dp(12))
        })
        val add = Button(this).apply { text = "Tambah Celengan"; setOnClickListener { addDialog() } }
        root.addView(add, LinearLayout.LayoutParams(-1, dp(50)).also { it.setMargins(0, 0, 0, dp(12)) })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        scroll.addView(root); setContentView(scroll); refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val items = PhysicalSavingManager.all(this)
        if (items.isEmpty()) {
            list.addView(TextView(this).apply { text = "Belum ada celengan fisik. Tambahkan tempat pertama untuk memudahkan kamu mengingat lokasi tabungan."; textSize = 14f; setTextColor(color(R.color.muted)); setPadding(0, dp(12), 0, dp(12)) })
            return
        }
        items.forEach { p ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(14), dp(15), dp(14)); setBackgroundResource(R.drawable.bg_card); layoutParams = LinearLayout.LayoutParams(-1, -2).also { it.setMargins(0, 0, 0, dp(10)) } }
            card.addView(TextView(this).apply { text = p.name; textSize = 17f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(color(R.color.text)) })
            if (p.location.isNotBlank()) card.addView(TextView(this).apply { text = "Lokasi: ${p.location}"; textSize = 13f; setTextColor(color(R.color.muted)); setPadding(0, dp(4), 0, 0) })
            if (p.note.isNotBlank()) card.addView(TextView(this).apply { text = p.note; textSize = 13f; setTextColor(color(R.color.muted)); setPadding(0, dp(3), 0, dp(4) ) })
            card.addView(Button(this).apply { text = "Hapus"; setOnClickListener { AlertDialog.Builder(this@PhysicalSavingActivity).setTitle("Hapus celengan?").setMessage("Yang dihapus hanya catatan tempatnya. Uang fisik kamu tidak terpengaruh.").setNegativeButton("Batal", null).setPositiveButton("Hapus") { _, _ -> PhysicalSavingManager.delete(this@PhysicalSavingActivity, p.id); refresh() }.show() } })
            list.addView(card)
        }
    }

    private fun addDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), 0, dp(4), 0) }
        val name = EditText(this).apply { hint = "Nama, misalnya Celengan HP" }
        val location = EditText(this).apply { hint = "Lokasi, misalnya kamar" }
        val note = EditText(this).apply { hint = "Catatan (opsional)" }
        box.addView(name); box.addView(location); box.addView(note)
        AlertDialog.Builder(this).setTitle("Tambah Celengan Fisik").setView(box).setNegativeButton("Batal", null).setPositiveButton("Simpan") { _, _ ->
            if (PhysicalSavingManager.add(this, name.text.toString(), location.text.toString(), note.text.toString())) refresh()
            else Toast.makeText(this, "Nama celengan wajib diisi", Toast.LENGTH_SHORT).show()
        }.show()
    }
}
