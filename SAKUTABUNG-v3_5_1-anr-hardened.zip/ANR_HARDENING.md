# ANR Hardening — v3.5.1

## Root cause addressed
The previous startup path created/opened SQLite and immediately rendered database-heavy screens from `MainActivity.onCreate()`. Theme/locale setters were also called on every creation. On slower devices or during Activity recreation this could block the main thread long enough to appear as an ANR at the splash.

## Fixes
- `DatabaseHelper` initialization + warm-up moved to `SakuTabung-Startup` executor.
- Startup failure has a visible retry state instead of an indefinitely stuck splash.
- Theme/locale changes are guarded by current state.
- History avoids one DB lookup per transaction card.
- Release candidate should be verified on Android 10 with repeated cold starts and History navigation.

## Not claimed without device/CI evidence
This source change cannot by itself prove zero ANRs. A real APK build and runtime test on physical/emulated Android devices is still required.
