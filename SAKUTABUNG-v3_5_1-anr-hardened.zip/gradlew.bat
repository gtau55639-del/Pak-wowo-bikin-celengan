@echo off
set ROOT=%~dp0
if exist "%ROOT%.gradle-launcher\gradle-9.6.0\bin\gradle.bat" goto run
where gradle >nul 2>nul && gradle %* && exit /b %errorlevel%
if not exist "%ROOT%.gradle-launcher\gradle-9.6.0-bin.zip" powershell -NoProfile -Command "Invoke-WebRequest -UseBasicParsing -Uri https://services.gradle.org/distributions/gradle-9.6.0-bin.zip -OutFile '%ROOT%.gradle-launcher\gradle-9.6.0-bin.zip'"
powershell -NoProfile -Command "Expand-Archive -Force '%ROOT%.gradle-launcher\gradle-9.6.0-bin.zip' '%ROOT%.gradle-launcher'"
:run
call "%ROOT%.gradle-launcher\gradle-9.6.0\bin\gradle.bat" %*
