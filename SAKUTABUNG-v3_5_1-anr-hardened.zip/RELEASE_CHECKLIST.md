# SakuTabung 3.5.0 Release Checklist

## Feature freeze
- Physical saving remains the core purpose.
- Offline core flows do not require Google sign-in.
- Google linking is optional and identity-only; it does not grant Premium.
- Premium milestones: level 20 = 3 days, level 50 = 7 days, level 100 = permanent; each claim is one-time.

## Required device tests
1. Fresh install -> launch -> home.
2. Airplane mode: create target, create physical saving place, record/edit/delete saving, view insight/calendar, play every offline game.
3. Daily claim, missions, XP, level progression, coin rewards.
4. Claim level 20/50/100 rewards exactly once.
5. Backup export -> uninstall/reinstall -> restore.
6. Move/edit a saving record between goals and verify both goals recalculate.
7. Rotate/recreate activities where applicable and verify no duplicate rewards.
8. Deny notifications and verify the core app still works.
9. Dark/light/system theme and small-screen layout.
10. Low-memory/background-resume and cold start.

## Release security
- Release signing credentials must come from CI secrets/environment variables, never source control.
- Production Google linking must never grant Premium by email.
- Do not ship test/developer entitlements in release builds.

## Build
- Run `./gradlew test` and `./gradlew bundleRelease` in GitHub Actions/Android Studio with network/dependencies available.
- Install the generated APK on at least one Android 10 device and one newer Android device.
- Verify Android backup/restore and notification behavior.
