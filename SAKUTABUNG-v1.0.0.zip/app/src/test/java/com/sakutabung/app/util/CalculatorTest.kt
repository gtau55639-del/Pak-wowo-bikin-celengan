package com.sakutabung.app.util

import com.sakutabung.app.model.Goal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class CalculatorTest {
    private val goal = Goal(1, "HP", 3_000_000, "2026-09-17", "2026-12-11", "Setiap hari", 20, 0, true)

    @Test fun calculatesRemainingAndProgress() {
        val s = Calculator.stats(goal, 450_000, LocalDate.of(2026, 9, 17))
        assertEquals(2_550_000, s.remaining)
        assertEquals(15, s.progress)
        assertEquals(85, s.daysLeft)
        assertEquals(30_000, s.daily)
    }

    @Test fun completedGoalHasNoDailyRequirement() {
        val s = Calculator.stats(goal, 3_000_000, LocalDate.of(2026, 9, 17))
        assertTrue(s.isCompleted)
        assertEquals(0, s.daily)
        assertEquals(0, s.weekly)
        assertEquals(100, s.progress)
    }

    @Test fun overdueGoalStillCalculatesRemainingTarget() {
        val s = Calculator.stats(goal, 1_000_000, LocalDate.of(2027, 1, 1))
        assertTrue(s.isOverdue)
        assertEquals(2_000_000, s.remaining)
        assertTrue(s.daily > 0)
    }
}
