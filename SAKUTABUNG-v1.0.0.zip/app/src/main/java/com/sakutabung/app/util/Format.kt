package com.sakutabung.app.util

import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

object Format {
    private val rupiah = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply { maximumFractionDigits = 0; minimumFractionDigits = 0 }
    private val prettyDate = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale("id", "ID"))
    fun rupiah(value: Long): String = rupiah.format(value).replace("Rp", "Rp ").replace(" ", " ").trim()
    fun date(iso: String): String = runCatching { LocalDate.parse(iso).format(prettyDate) }.getOrDefault(iso)
}
