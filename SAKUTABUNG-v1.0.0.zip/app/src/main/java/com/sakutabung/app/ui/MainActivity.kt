package com.sakutabung.app.ui

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textfield.TextInputEditText
import com.sakutabung.app.R
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.model.Goal
import com.sakutabung.app.model.Transaction
import com.sakutabung.app.notification.ReminderScheduler
import com.sakutabung.app.util.Calculator
import com.sakutabung.app.util.Format
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Calendar

class MainActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val dateFmt = DateTimeFormatter.ISO_LOCAL_DATE
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(state: Bundle?) {
        installSplashScreen()
        super.onCreate(state)
        db = DatabaseHelper(this)
        applySavedTheme()
        buildBase()
        requestNotificationIfNeeded()
        showHome()
    }

    private fun applySavedTheme() {
        val dark = prefs.getBoolean("dark_mode", false)
        AppCompatDelegate.setDefaultNightMode(if (dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)
    }

    private fun buildBase() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundResource(R.color.background) }
        setContentView(root)
    }

    private fun shell(title: String, body: View, selected: Int) {
        root.removeAllViews()
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(6)) }
        header.addView(TextView(this).apply { text = title; textSize = 27f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        header.addView(TextView(this).apply { text = "Sedikit demi sedikit, sampai jadi."; textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(3), 0, dp(4)) })
        root.addView(header)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = BottomNavigationView(this).apply {
            menu.add(0, 1, 0, "Beranda").setIcon(android.R.drawable.ic_menu_view)
            menu.add(0, 2, 1, "Celengan").setIcon(android.R.drawable.ic_menu_agenda)
            menu.add(0, 3, 2, "Riwayat").setIcon(android.R.drawable.ic_menu_recent_history)
            menu.add(0, 4, 3, "Pengaturan").setIcon(android.R.drawable.ic_menu_preferences)
            selectedItemId = selected
            setOnItemSelectedListener { item -> when (item.itemId) { 1 -> { showHome(); true }; 2 -> { showGoals(); true }; 3 -> { showHistory(); true }; 4 -> { showSettings(); true }; else -> false } }
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(68)))
    }

    private fun showHome() {
        val scroll = ScrollView(this)
        val box = contentColumn()
        val goals = db.goals()
        val active = goals.filter { it.active }
        val total = db.totalSaved()
        val target = goals.sumOf { it.target }
        box.addView(summaryCard(total, target, active.size, goals.count()))
        val closest = active.minByOrNull { it.deadline }
        if (closest != null) box.addView(sectionLabel("Target terdekat"))
        closest?.let { box.addView(goalCard(it)) }
        box.addView(sectionLabel("Celengan kamu"))
        if (goals.isEmpty()) box.addView(emptyState("Belum ada celengan", "Buat target pertama dan mulai dari nominal kecil."))
        else goals.take(6).forEach { box.addView(goalCard(it)) }
        box.addView(primaryButton("+ Buat Celengan") { showGoalForm(null) })
        box.addView(TextView(this).apply { text = "Versi 1.0.0 • Offline-first"; textSize = 12f; gravity = 17; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(8), 0, dp(20)) })
        scroll.addView(box)
        shell("Beranda", scroll, 1)
    }

    private fun summaryCard(total: Long, target: Long, active: Int, count: Int): View {
        val card = cardContainer()
        card.addView(TextView(this).apply { text = "Total Tabungan"; textSize = 14f; setTextColor(getColorCompat(R.color.muted)) })
        card.addView(TextView(this).apply { text = Format.rupiah(total); textSize = 28f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)); setPadding(0, dp(3), 0, dp(10)) })
        val percent = if (target > 0) ((total.toDouble() / target) * 100).toInt().coerceIn(0, 100) else 0
        val bar = LinearProgressIndicator(this).apply { max = 100; progress = percent; trackThickness = dp(8); setPadding(0, 0, 0, dp(7)) }
        card.addView(bar)
        card.addView(TextView(this).apply { text = "$percent% dari total target • $active aktif • $count semua"; textSize = 13f; setTextColor(getColorCompat(R.color.muted)) })
        return card
    }

    private fun showGoals() {
        val scroll = ScrollView(this)
        val box = contentColumn()
        val goals = db.goals()
        if (goals.isEmpty()) box.addView(emptyState("Celengan masih kosong", "Buat target pertama kamu."))
        goals.forEach { box.addView(goalCard(it)) }
        box.addView(primaryButton("+ Buat Celengan") { showGoalForm(null) })
        scroll.addView(box)
        shell("Celengan", scroll, 2)
    }

    private fun goalCard(g: Goal): View {
        val stats = Calculator.stats(g, db.saved(g.id))
        val card = cardContainer()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = 16 }
        row.addView(ImageView(this).apply { setImageResource(R.drawable.ic_pig); layoutParams = LinearLayout.LayoutParams(dp(52), dp(52)) })
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        texts.addView(TextView(this).apply { text = g.name; textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        texts.addView(TextView(this).apply { text = "${Format.rupiah(stats.saved)} / ${Format.rupiah(g.target)}"; textSize = 14f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(2), 0, 0) })
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(TextView(this).apply { text = "${stats.progress}%"; textSize = 16f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.primary)) })
        card.addView(row)
        val bar = LinearProgressIndicator(this).apply { max = 100; progress = stats.progress; trackThickness = dp(7); setPadding(0, dp(10), 0, dp(6)) }
        card.addView(bar)
        val detail = if (stats.isCompleted) "🎉 Target tercapai!" else if (stats.isOverdue) "Deadline terlewat • ${Format.rupiah(stats.remaining)} tersisa" else "${stats.daysLeft} hari tersisa • ${Format.rupiah(stats.daily)}/hari"
        card.addView(TextView(this).apply { text = detail; textSize = 13f; setTextColor(if (stats.isCompleted) getColorCompat(R.color.primary) else getColorCompat(R.color.muted)) })
        card.setOnClickListener { showGoalDetail(g.id) }
        return card
    }

    private fun showGoalDetail(id: Long) {
        val g = db.goal(id) ?: return
        val stats = Calculator.stats(g, db.saved(id))
        val scroll = ScrollView(this)
        val box = contentColumn()
        val hero = cardContainer()
        hero.gravity = Gravity.CENTER_HORIZONTAL
        hero.addView(ImageView(this).apply { setImageResource(R.drawable.ic_pig); layoutParams = LinearLayout.LayoutParams(dp(84), dp(84)) })
        hero.addView(TextView(this).apply { text = g.name; textSize = 23f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)); gravity = 17; setPadding(0, dp(8), 0, 0) })
        hero.addView(TextView(this).apply { text = "${stats.progress}%"; textSize = 34f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.primary)); gravity = 17; setPadding(0, dp(4), 0, dp(4)) })
        hero.addView(LinearProgressIndicator(this).apply { max = 100; progress = stats.progress; trackThickness = dp(10); layoutParams = LinearLayout.LayoutParams(-1, dp(12)) })
        hero.addView(TextView(this).apply { text = "${Format.rupiah(stats.saved)} dari ${Format.rupiah(g.target)}"; textSize = 15f; gravity = 17; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(8), 0, 0) })
        box.addView(hero)
        val info = cardContainer()
        info.addView(TextView(this).apply { text = "Target tersisa  ${Format.rupiah(stats.remaining)}"; textSize = 16f; setTextColor(getColorCompat(R.color.text)); setPadding(0, 0, 0, dp(8)) })
        info.addView(TextView(this).apply { text = "Deadline  ${Format.date(g.deadline)}\nSisa waktu  ${stats.daysLeft} hari\nKebutuhan harian  ${Format.rupiah(stats.daily)}\nKebutuhan mingguan  ${Format.rupiah(stats.weekly)}"; textSize = 14f; setTextColor(getColorCompat(R.color.muted)) })
        box.addView(info)
        if (stats.isCompleted) box.addView(successBanner("🎉 Target tercapai! Pengingat otomatis dihentikan."))
        else if (stats.isOverdue) box.addView(successBanner("Deadline terlewat. Perhitungan tetap memakai sisa target agar kamu bisa melanjutkan."))
        box.addView(primaryButton("+ Tambah Tabungan") { showAddSaving(g) })
        box.addView(secondaryButton("Lihat Riwayat") { showHistory(g.id) })
        box.addView(secondaryButton("Edit Celengan") { showGoalForm(g) })
        box.addView(dangerButton("Hapus Celengan") { confirmDelete(g) })
        scroll.addView(box)
        shell(g.name, scroll, 2)
    }

    private fun showGoalForm(existing: Goal?) {
        val form = contentColumn()
        val name = input("Nama celengan", existing?.name.orEmpty())
        val target = input("Target nominal", existing?.target?.toString().orEmpty(), true)
        val start = input("Tanggal mulai", existing?.startDate ?: LocalDate.now().toString())
        val deadline = input("Deadline", existing?.deadline ?: LocalDate.now().plusDays(30).toString())
        val freq = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Setiap hari", "Setiap minggu")); setSelection(if (existing?.frequency?.contains("minggu", true) == true) 1 else 0) }
        val time = input("Jam pengingat", existing?.let { "%02d:%02d".format(it.reminderHour, it.reminderMinute) } ?: "20:00")
        listOf(name, target, start, deadline).forEach { form.addView(it) }
        form.addView(TextView(this).apply { text = "Frekuensi pengingat"; textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(8), 0, dp(3)) })
        form.addView(freq, LinearLayout.LayoutParams(-1, dp(54)))
        form.addView(time)
        start.setOnClickListener { datePicker(start) }; deadline.setOnClickListener { datePicker(deadline) }; time.setOnClickListener { timePicker(time) }
        AlertDialog.Builder(this).setTitle(if (existing == null) "Buat Celengan" else "Edit Celengan").setView(form).setNegativeButton("Batal", null).setPositiveButton("Simpan", null).create().also { dialog ->
            dialog.setOnShowListener {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    try {
                        val n = name.text.toString().trim()
                        val t = target.text.toString().filter(Char::isDigit).toLongOrNull() ?: 0L
                        val sd = LocalDate.parse(start.text.toString())
                        val ed = LocalDate.parse(deadline.text.toString())
                        require(n.isNotBlank() && t > 0 && !ed.isBefore(sd))
                        val hm = time.text.toString().split(":"); val h = hm.getOrNull(0)?.toIntOrNull() ?: 20; val m = hm.getOrNull(1)?.toIntOrNull() ?: 0
                        require(h in 0..23 && m in 0..59)
                        val goal = Goal(existing?.id ?: 0L, n, t, sd.toString(), ed.toString(), freq.selectedItem.toString(), h, m, existing?.active ?: true)
                        val id = if (existing == null) db.insertGoal(goal) else { db.updateGoal(goal); goal.id }
                        if (goal.active) ReminderScheduler.schedule(this, id, h, m, goal.frequency) else ReminderScheduler.cancel(this, id)
                        dialog.dismiss(); if (existing == null) showGoals() else showGoalDetail(id)
                    } catch (_: Exception) { Toast.makeText(this, "Periksa nama, nominal, dan tanggal.", Toast.LENGTH_SHORT).show() }
                }
            }
        }.show()
    }

    private fun showAddSaving(g: Goal) {
        val form = contentColumn()
        val amount = input("Nominal", "", true)
        val date = input("Tanggal", LocalDate.now().toString())
        val note = input("Catatan", "")
        form.addView(amount); form.addView(date); form.addView(note)
        date.setOnClickListener { datePicker(date) }
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = 17 }
        listOf(10000L, 20000L, 50000L).forEach { value -> quick.addView(secondaryButton(Format.rupiah(value)) { amount.setText(value.toString()) }, LinearLayout.LayoutParams(0, dp(50), 1f).also { it.setMargins(dp(3), 0, dp(3), 0) }) }
        form.addView(quick)
        AlertDialog.Builder(this).setTitle("Tambah Tabungan").setView(form).setNegativeButton("Batal", null).setPositiveButton("Simpan", null).create().also { dialog ->
            dialog.setOnShowListener {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    try {
                        val a = amount.text.toString().filter(Char::isDigit).toLongOrNull() ?: 0L
                        val d = LocalDate.parse(date.text.toString())
                        require(a > 0 && !d.isBefore(LocalDate.parse(g.startDate)))
                        db.addTransaction(Transaction(0, g.id, a, d.toString(), note.text.toString().trim()))
                        val newSaved = db.saved(g.id)
                        if (newSaved >= g.target) ReminderScheduler.cancel(this, g.id) else ReminderScheduler.schedule(this, g.id, g.reminderHour, g.reminderMinute, g.frequency)
                        dialog.dismiss(); showGoalDetail(g.id)
                    } catch (_: Exception) { Toast.makeText(this, "Nominal harus lebih dari 0 dan tanggal valid.", Toast.LENGTH_SHORT).show() }
                }
            }
        }.show()
    }

    private fun showHistory(goalId: Long? = null) {
        val scroll = ScrollView(this); val box = contentColumn()
        val search = input("Cari nama/catatan", "")
        box.addView(search)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refresh() {
            list.removeAllViews(); val q = search.text.toString().trim().lowercase(); val tx = db.transactions(goalId).filter { q.isBlank() || it.note.lowercase().contains(q) || (db.goal(it.goalId)?.name?.lowercase()?.contains(q) == true) }
            if (tx.isEmpty()) list.addView(emptyState("Belum ada transaksi", "Setelah menabung, transaksi akan muncul di sini."))
            tx.forEach { t -> list.addView(transactionCard(t)) }
        }
        search.addTextChangedListener(SimpleTextWatcher { refresh() }); box.addView(list); refresh(); scroll.addView(box); shell("Riwayat", scroll, 3)
    }

    private fun transactionCard(t: Transaction): View {
        val c = cardContainer(); val g = db.goal(t.goalId)
        c.addView(TextView(this).apply { text = "${Format.date(t.date)} • ${g?.name ?: "Celengan"}"; textSize = 13f; setTextColor(getColorCompat(R.color.muted)) })
        c.addView(TextView(this).apply { text = "+ ${Format.rupiah(t.amount)}"; textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.primary)); setPadding(0, dp(4), 0, 0) })
        if (t.note.isNotBlank()) c.addView(TextView(this).apply { text = t.note; textSize = 14f; setTextColor(getColorCompat(R.color.text)); setPadding(0, dp(3), 0, 0) })
        return c
    }

    private fun showSettings() {
        val box = contentColumn()
        val dark = Switch(this).apply { text = "Mode gelap"; textSize = 16f; isChecked = prefs.getBoolean("dark_mode", false); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("dark_mode", checked).apply(); AppCompatDelegate.setDefaultNightMode(if (checked) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO) } }
        box.addView(cardContainer().apply { addView(dark) })
        box.addView(primaryButton("Aktifkan notifikasi") { requestNotificationIfNeeded(force = true) })
        box.addView(cardContainer().apply { addView(TextView(this@MainActivity).apply { text = "SakuTabung v1.0.0\n\nOffline-first. Data tabungan tersimpan lokal di perangkat. Tidak membutuhkan akun, server, atau koneksi internet.\n\nIzin yang digunakan: notifikasi (Android 13+) dan penerima boot untuk menjadwalkan ulang pengingat."; textSize = 14f; setTextColor(getColorCompat(R.color.text)) }) })
        shell("Pengaturan", ScrollView(this).apply { addView(box) }, 4)
    }

    private fun confirmDelete(g: Goal) { AlertDialog.Builder(this).setTitle("Hapus ${g.name}?").setMessage("Semua transaksi di celengan ini juga akan dihapus. Tindakan ini tidak dapat dibatalkan.").setNegativeButton("Batal", null).setPositiveButton("Hapus") { _, _ -> db.deleteGoal(g.id); ReminderScheduler.cancel(this, g.id); showGoals() }.show() }

    private fun sectionLabel(text: String) = TextView(this).apply { this.text = text; textSize = 17f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)); setPadding(0, dp(16), 0, dp(8)) }
    private fun emptyState(title: String, subtitle: String): View = cardContainer().apply { gravity = Gravity.CENTER_HORIZONTAL; addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_pig); layoutParams = LinearLayout.LayoutParams(dp(62), dp(62)) }); addView(TextView(this@MainActivity).apply { text = title; textSize = 17f; setTypeface(null, Typeface.BOLD); gravity = 17; setTextColor(getColorCompat(R.color.text)) }); addView(TextView(this@MainActivity).apply { text = subtitle; textSize = 13f; gravity = 17; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(4), 0, 0) }) }
    private fun successBanner(text: String) = TextView(this).apply { this.text = text; textSize = 14f; setTextColor(getColorCompat(R.color.primary)); setPadding(dp(16), dp(14), dp(16), dp(14)); setBackgroundResource(R.drawable.bg_success) }
    private fun contentColumn() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(4), dp(18), dp(18)) }
    private fun cardContainer() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); setBackgroundResource(R.drawable.bg_card); layoutParams = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.setMargins(0, 0, 0, dp(12)) } }
    private fun primaryButton(text: String, action: () -> Unit) = Button(this).apply { this.text = text; setAllCaps(false); textSize = 15f; setOnClickListener { action() }; setBackgroundResource(R.drawable.bg_primary_button); setTextColor(0xFFFFFFFF.toInt()); minHeight = dp(54); layoutParams = LinearLayout.LayoutParams(-1, dp(56)).also { it.setMargins(0, dp(4), 0, dp(8)) } }
    private fun secondaryButton(text: String, action: () -> Unit) = Button(this).apply { this.text = text; setAllCaps(false); textSize = 14f; setOnClickListener { action() }; minHeight = dp(50); layoutParams = LinearLayout.LayoutParams(-1, dp(52)).also { it.setMargins(0, dp(3), 0, dp(5)) } }
    private fun dangerButton(text: String, action: () -> Unit) = secondaryButton(text, action)
    private fun input(hint: String, value: String, numeric: Boolean = false): TextInputEditText = TextInputEditText(this).apply { this.hint = hint; setText(value); textSize = 16f; setSingleLine(true); if (numeric) inputType = android.text.InputType.TYPE_CLASS_NUMBER; layoutParams = LinearLayout.LayoutParams(-1, dp(58)).also { it.setMargins(0, dp(3), 0, dp(3)) } }

    private fun datePicker(target: TextView) { val initial = runCatching { LocalDate.parse(target.text.toString()) }.getOrElse { LocalDate.now() }; DatePickerDialog(this, { _, y, m, d -> target.text = "%04d-%02d-%02d".format(y, m + 1, d) }, initial.year, initial.monthValue - 1, initial.dayOfMonth).show() }
    private fun timePicker(target: TextView) { val c = Calendar.getInstance(); TimePickerDialog(this, { _, h, m -> target.text = "%02d:%02d".format(h, m) }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show() }
    private fun requestNotificationIfNeeded(force: Boolean = false) { if (Build.VERSION.SDK_INT >= 33 && (force || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS) }
    private fun getColorCompat(id: Int) = androidx.core.content.ContextCompat.getColor(this, id)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}

private class SimpleTextWatcher(private val changed: () -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = changed()
    override fun afterTextChanged(s: android.text.Editable?) = Unit
}
