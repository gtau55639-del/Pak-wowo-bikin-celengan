# SAKUTABUNG v0.0.1

**Sedikit demi sedikit, sampai jadi.**

Offline-first Android savings tracker. No login, server, cloud database, bank integration, e-wallet integration, payment gateway, or AI.

## Build locally

Requirements:
- JDK 17
- Android SDK Platform 36
- Android Build Tools 36.0.0

From the project root:

```bash
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
./gradlew :app:assembleRelease
```

APKs are generated under `app/build/outputs/apk/`.

## GitHub: easiest ZIP flow

You can upload `SAKUTABUNG.zip` to the repository root. The workflow automatically extracts the ZIP, finds `settings.gradle.kts`/`settings.gradle`, installs the required Android SDK packages, runs tests, and builds debug + release APKs.

Go to **Actions → Build SAKUTABUNG APK → Run workflow**.

A push to `main` or `master` also starts the workflow automatically.

The APKs are available under **Actions → workflow run → Artifacts**.

## Compatibility

`minSdk = 21` (Android 5.0+), `targetSdk = 36`.

The project avoids the obsolete Android SDK `tools` package. The GitHub workflow installs only current packages required by the build: `platform-tools`, `platforms;android-36`, and `build-tools;36.0.0`.

## v0.0.1 known issue

The small splash/loading issue is intentionally retained for this initial version and is not treated as a v0.0.1 fix.
