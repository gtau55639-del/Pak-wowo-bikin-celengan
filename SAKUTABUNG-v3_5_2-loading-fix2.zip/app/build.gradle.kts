plugins { id("com.android.application") }

android {
    namespace = "com.sakutabung.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.sakutabung.app"
        minSdk = 21
        targetSdk = 36
        versionCode = 352
        versionName = "3.5.2"
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    val releaseStore = System.getenv("SAKUTABUNG_KEYSTORE")
    val releaseStorePassword = System.getenv("SAKUTABUNG_STORE_PASSWORD")
    val releaseKeyAlias = System.getenv("SAKUTABUNG_KEY_ALIAS")
    val releaseKeyPassword = System.getenv("SAKUTABUNG_KEY_PASSWORD")
    if (!releaseStore.isNullOrBlank() && !releaseStorePassword.isNullOrBlank() && !releaseKeyAlias.isNullOrBlank() && !releaseKeyPassword.isNullOrBlank()) {
        signingConfigs {
            create("release") {
                storeFile = file(releaseStore)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (!releaseStore.isNullOrBlank() && !releaseStorePassword.isNullOrBlank() && !releaseKeyAlias.isNullOrBlank() && !releaseKeyPassword.isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
        debug { applicationIdSuffix = ".debug"; versionNameSuffix = "-debug" }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("com.google.android.material:material:1.11.0")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
}
