package com.sakutabung.app.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.model.Goal
import com.sakutabung.app.model.Transaction
import com.sakutabung.app.util.PhysicalSavingManager

object BackupManager {
    fun export(c: Context): String {
        val db=DatabaseHelper(c); val root=JSONObject(); root.put("app","SakuTabung"); root.put("version",5); root.put("exportedAt", System.currentTimeMillis()); root.put("versionName", "3.5.2")
        val goals=JSONArray(); db.goals().forEach { g-> goals.put(JSONObject().apply { put("id",g.id);put("name",g.name);put("target",g.target);put("start",g.startDate);put("deadline",g.deadline);put("frequency",g.frequency);put("hour",g.reminderHour);put("minute",g.reminderMinute);put("active",g.active) }) }
        val tx=JSONArray(); db.transactions().forEach { t-> tx.put(JSONObject().apply { put("goalId",t.goalId);put("amount",t.amount);put("date",t.date);put("note",t.note) }) }
        root.put("goals",goals);root.put("transactions",tx);root.put("coins",CoinManager.balance(c));root.put("extraLimits",SavingLimitManager.extra(c)); root.put("challenges", SavingChallengeManager.export(c));root.put("physicalSavingPlaces",PhysicalSavingManager.exportJson(c)); root.put("profile", JSONObject().apply { put("name", ProfileManager.name(c)); put("lastNameChange", ProfileManager.export(c)["lastNameChange"] ?: "") }); root.put("rewards", RewardManager.export(c)); root.put("premiumPermanent", PremiumManager.isPermanent(c)); root.put("premiumUntil", PremiumManager.premiumUntil(c)?.toString() ?: ""); return root.toString(2)
    }
    fun restore(c: Context, json: String) {
        val root=JSONObject(json); require(root.optString("app").contains("SakuTabung"))
        require(root.optInt("version", 0) in 1..5) { "unsupported_backup" }
        val db=DatabaseHelper(c); val sql=db.writableDatabase; sql.beginTransaction()
        try {
            sql.delete("transactions",null,null); sql.delete("goals",null,null)
            val map=HashMap<Long,Long>(); val gs=root.getJSONArray("goals")
            for(i in 0 until gs.length()){val x=gs.getJSONObject(i); val old=x.optLong("id"); require(old > 0) { "invalid_goal_id" }; val name=x.getString("name").trim(); require(name.isNotBlank() && name.length <= 80) { "invalid_goal_name" }; val target=x.getLong("target"); require(target > 0) { "invalid_goal_target" }; val start=x.getString("start"); val deadline=x.getString("deadline"); require(runCatching { java.time.LocalDate.parse(start); java.time.LocalDate.parse(deadline); true }.getOrDefault(false)) { "invalid_goal_date" }; val g=Goal(0,name,target,start,deadline,x.getString("frequency"),x.getInt("hour").coerceIn(0,23),x.getInt("minute").coerceIn(0,59),x.optBoolean("active",true)); map[old]=db.insertGoal(g)}
            val ts=root.getJSONArray("transactions")
            for(i in 0 until ts.length()){val x=ts.getJSONObject(i); val gid=map[x.getLong("goalId")] ?: continue; val amount=x.getLong("amount"); require(amount > 0) { "invalid_transaction_amount" }; val date=x.getString("date"); require(runCatching { !java.time.LocalDate.parse(date).isAfter(java.time.LocalDate.now()) }.getOrDefault(false)) { "invalid_transaction_date" }; db.addTransaction(Transaction(0,gid,amount,date,x.optString("note").take(200)))}
            CoinManager.setBalance(c, root.optInt("coins", 0))
            SavingLimitManager.setExtra(c, root.optInt("extraLimits", 0))
            PhysicalSavingManager.importJson(c, root.optJSONArray("physicalSavingPlaces")); val profile=root.optJSONObject("profile"); ProfileManager.import(c, profile?.optString("name"), profile?.optString("lastNameChange")); RewardManager.import(c, root.optJSONObject("rewards")); SavingChallengeManager.import(c, root.optJSONObject("challenges"));
            PremiumManager.restoreEntitlement(c, root.optBoolean("premiumPermanent", false), root.optString("premiumUntil", "").ifBlank { null })
            sql.setTransactionSuccessful()
        } finally { sql.endTransaction() }
    }
}
