# SakuTabung 3.5.2 — Startup Loading Fix

- Removed full goals/transactions preloading from the startup executor.
- SQLite open/migration remains off the main/UI thread.
- Startup now initializes only the lightweight game-limit state before opening the first screen.
- Added a transaction date/id index for faster history/dashboard date scans.
- Existing files and project structure are preserved.
