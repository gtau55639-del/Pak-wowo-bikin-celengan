# SakuTabung v2.8.0

## Smart Saving Update
- Smart Goal calculator: target, current savings, deadline, daily and weekly recommendation.
- Smart Goal teaser on Home and a dedicated Smart Goal screen.
- Existing savings, goals, games, rewards, coins, premium, security, backup/export, language, theme, widget and developer features are preserved.
- Fixed duplicated coin-wallet description in Home.
- Version Code: 270 / Version Name: 2.8.0.

Build with Android Studio/Gradle. The project remains offline-first and does not require a new database migration for Smart Goal.


## v2.8.0
- Added SakuVerse personal progress dashboard.
- Shows level/XP, savings, coins, Brain Score, streak and badge progress.
- Added quick links to Coin Shop and Brain Center.
- No database schema change.
- Version code 280.
