package com.sakutabung.app.util

import android.content.Context
import java.time.LocalDate
import java.time.temporal.WeekFields
import java.time.Instant
import java.util.Locale

/** v1.9 prototype: account-linked OPIMOUS state stored locally. Production should verify entitlement server-side/Play Billing. */
object PremiumManager {
    private const val PREFS = "settings"
    private const val KEY_PREMIUM = "premium_active"
    private const val KEY_EMAIL = "google_account"
    const val DEVELOPER_EMAIL = "febrianmahnu@gmail.com"
    const val OPIMOUS_PRICE_RUPIAH = 4_850L
    const val FREE_WEEKLY_LIMIT = 6
    /** Backward-compatible alias; this is a limit quota, not a number of savings goals. */
    const val FREE_WEEKLY_SAVING_LIMIT = FREE_WEEKLY_LIMIT

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // Free-to-OPIMOUS social challenge: the app only grants the reward after an
    // online verifier confirms the required subscriptions/follows. No local
    // button can mark the challenge as verified.
    private const val KEY_SOCIAL_STARTED = "social_reward_started"
    private const val KEY_SOCIAL_VERIFIED_AT = "social_reward_verified_at"
    private const val SOCIAL_DAYS = 6L

    fun socialChallengeStarted(c: Context): Boolean = p(c).getBoolean(KEY_SOCIAL_STARTED, false)
    fun socialVerifiedAt(c: Context): Long = p(c).getLong(KEY_SOCIAL_VERIFIED_AT, 0L)
    fun startSocialChallenge(c: Context) { p(c).edit().putBoolean(KEY_SOCIAL_STARTED, true).apply() }
    fun setOnlineSocialVerification(c: Context, verified: Boolean) {
        if (verified) p(c).edit().putLong(KEY_SOCIAL_VERIFIED_AT, Instant.now().toEpochMilli()).apply()
        else p(c).edit().remove(KEY_SOCIAL_VERIFIED_AT).apply()
    }
    fun socialDaysRemaining(c: Context): Long {
        val at = socialVerifiedAt(c)
        if (at <= 0L) return SOCIAL_DAYS
        val elapsed = java.time.Duration.ofMillis((System.currentTimeMillis() - at).coerceAtLeast(0L)).toDays()
        return (SOCIAL_DAYS - elapsed).coerceAtLeast(0L)
    }
    fun canRewardFromSocial(c: Context): Boolean = socialVerifiedAt(c) > 0L && socialDaysRemaining(c) == 0L && !isDeveloper(c)
    fun revokeSocialReward(c: Context) {
        p(c).edit().remove(KEY_SOCIAL_VERIFIED_AT).apply()
        if (!isDeveloper(c)) p(c).edit().putBoolean(KEY_PREMIUM, false).remove(KEY_EMAIL).apply()
    }
    fun email(c: Context) = p(c).getString(KEY_EMAIL, null)
    fun isDeveloper(c: Context): Boolean = email(c)?.equals(DEVELOPER_EMAIL, ignoreCase = true) == true
    fun isPremium(c: Context): Boolean = p(c).getBoolean(KEY_PREMIUM, false) || isDeveloper(c)
    fun login(c: Context, account: String) {
        val developer = account.equals(DEVELOPER_EMAIL, ignoreCase = true)
        p(c).edit().putBoolean(KEY_PREMIUM, true).putString(KEY_EMAIL, account).putBoolean("developer_mode", developer).apply()
    }
    fun signOut(c: Context) { p(c).edit().putBoolean(KEY_PREMIUM, false).remove(KEY_EMAIL).apply() }
    fun weekKey(date: LocalDate = LocalDate.now()): String {
        val wf = WeekFields.of(Locale.getDefault())
        return "${date.get(wf.weekBasedYear())}-${date.get(wf.weekOfWeekBasedYear())}"
    }
    fun weeklyLimitUsed(c: Context): Int {
        val db = com.sakutabung.app.data.DatabaseHelper(c)
        val key = weekKey()
        return db.transactions().count { runCatching { weekKey(LocalDate.parse(it.date)) == key }.getOrDefault(false) }
    }

    /** Backward-compatible alias for older callers. */
    fun weeklySavingCount(c: Context): Int = weeklyLimitUsed(c)
}
