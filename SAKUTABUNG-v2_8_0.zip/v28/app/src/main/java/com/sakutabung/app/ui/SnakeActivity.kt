package com.sakutabung.app.ui

import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.game.GameLimitManager
import com.sakutabung.app.game.SnakeView
import com.sakutabung.app.model.GameScore
import com.sakutabung.app.util.I18n
import java.time.LocalDate

/** Ditambahkan di v1.1.0 - layar mini game Ular Angka. */
class SnakeActivity : AppCompatActivity() {
    private fun t(key: String, vararg args: Any) = I18n.t(this, key, *args)
    private lateinit var db: DatabaseHelper
    private lateinit var snakeView: SnakeView
    private lateinit var scoreLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DatabaseHelper(this)
        title = "Ular Angka"

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scoreLabel = TextView(this).apply { text = t("score_zero"); textSize = 20f; gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(8)) }
        root.addView(scoreLabel)

        snakeView = SnakeView(this)
        root.addView(snakeView, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(buildControls())
        setContentView(root)

        snakeView.onScoreChanged = { s -> runOnUiThread { scoreLabel.text = t("score_n", s) } }
        snakeView.onGameOver = { s -> runOnUiThread { finishGame(s) } }
    }

    private fun buildControls(): LinearLayout {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(20)) }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row1.addView(dirButton("\u2B06") { snakeView.changeDirection(SnakeView.Dir.UP) })
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row2.addView(dirButton("\u2B05") { snakeView.changeDirection(SnakeView.Dir.LEFT) })
        row2.addView(dirButton("\u2B07") { snakeView.changeDirection(SnakeView.Dir.DOWN) })
        row2.addView(dirButton("\u27A1") { snakeView.changeDirection(SnakeView.Dir.RIGHT) })
        wrap.addView(row1); wrap.addView(row2)
        return wrap
    }

    private fun dirButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(dp(64), dp(64)).also { it.setMargins(dp(6), dp(6), dp(6), dp(6)) }
    }

    private fun finishGame(score: Int) {
        db.insertGameScore(GameScore(0, "snake", score, GameLimitManager.getGrade(this), LocalDate.now().toString()))
        AlertDialog.Builder(this)
            .setTitle(t("game_over"))
            .setMessage(t("score", score))
            .setCancelable(false)
            .setPositiveButton(t("close")) { _, _ -> finish() }
            .show()
    }

    override fun onDestroy() {
        snakeView.stop()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
