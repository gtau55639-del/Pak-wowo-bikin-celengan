package com.sakutabung.app.util

import android.content.Context
import java.time.LocalDate
import java.time.temporal.WeekFields
import java.util.Locale

/** v2.4: real saving-action quota. It is separate from game chances. */
object SavingLimitManager {
    const val WEEKLY_FREE_LIMIT = 6
    private const val PREFS = "sakutabung_saving_limits"
    private const val KEY_WEEK = "week"
    private const val KEY_USED = "used"
    private const val KEY_EXTRA = "extra"

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun week(): String {
        val wf = WeekFields.of(Locale.getDefault())
        val d = LocalDate.now()
        return "${d.get(wf.weekBasedYear())}-${d.get(wf.weekOfWeekBasedYear())}"
    }
    private fun normalize(c: Context) {
        val sp = p(c); val w = week()
        if (sp.getString(KEY_WEEK, null) != w) sp.edit().putString(KEY_WEEK, w).putInt(KEY_USED, 0).apply()
    }
    fun used(c: Context): Int { normalize(c); return p(c).getInt(KEY_USED, 0) }
    fun extra(c: Context): Int = p(c).getInt(KEY_EXTRA, 0)
    fun available(c: Context): Int {
        if (PremiumManager.isPremium(c)) return Int.MAX_VALUE
        normalize(c)
        return (WEEKLY_FREE_LIMIT - used(c) + extra(c)).coerceAtLeast(0)
    }
    fun consume(c: Context): Boolean {
        if (PremiumManager.isPremium(c)) return true
        normalize(c); val sp = p(c); val used = sp.getInt(KEY_USED, 0); val extra = sp.getInt(KEY_EXTRA, 0)
        if (used < WEEKLY_FREE_LIMIT) sp.edit().putInt(KEY_USED, used + 1).apply()
        else if (extra > 0) sp.edit().putInt(KEY_EXTRA, extra - 1).apply()
        else return false
        return true
    }
    fun setExtra(c: Context, amount: Int) { p(c).edit().putInt(KEY_EXTRA, amount.coerceAtLeast(0)).apply() }

    fun addExtra(c: Context, amount: Int): Boolean {
        if (amount <= 0 || PremiumManager.isPremium(c)) return false
        val next = (extra(c).toLong() + amount).coerceAtMost(10_000L).toInt()
        p(c).edit().putInt(KEY_EXTRA, next).apply(); return true
    }
}
