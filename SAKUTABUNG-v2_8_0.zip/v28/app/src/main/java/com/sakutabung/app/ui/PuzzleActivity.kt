package com.sakutabung.app.ui

import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.game.GameLimitManager
import com.sakutabung.app.game.PuzzleView
import com.sakutabung.app.model.GameScore
import com.sakutabung.app.util.I18n
import java.time.LocalDate

/** Ditambahkan di v1.1.0 - layar mini game Puzzle Geser. */
class PuzzleActivity : AppCompatActivity() {
    private fun t(key: String, vararg args: Any) = I18n.t(this, key, *args)
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DatabaseHelper(this)
        title = "Puzzle Geser"

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(TextView(this).apply { text = t("puzzle_help"); textSize = 13f; gravity = Gravity.CENTER; setPadding(dp(16), dp(16), dp(16), dp(8)) })

        val holder = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        val view = PuzzleView(this)
        holder.addView(view, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        root.addView(holder)
        setContentView(root)

        view.onSolved = { score, moves ->
            runOnUiThread {
                db.insertGameScore(GameScore(0, "puzzle", score, GameLimitManager.getGrade(this), LocalDate.now().toString()))
                AlertDialog.Builder(this)
                    .setTitle(t("done"))
                    .setMessage(t("solved", moves, score))
                    .setCancelable(false)
                    .setPositiveButton(t("close")) { _, _ -> finish() }
                    .show()
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
