package com.sakutabung.app.util
import android.content.Context
import java.time.LocalDate
object RewardManager {
 private const val PREFS="sakutabung_rewards"; private const val DAILY="daily_claim"; private const val XP="xp"; private const val STREAK="streak"; private const val LAST="last_day"
 private fun p(c:Context)=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE); private fun today()=LocalDate.now().toString()
 fun xp(c:Context)=p(c).getInt(XP,0).coerceAtLeast(0); fun level(c:Context)=(xp(c)/100)+1; fun progress(c:Context)=xp(c)%100; fun streak(c:Context)=p(c).getInt(STREAK,0).coerceAtLeast(0)
 fun dailyClaimed(c:Context)=p(c).getString(DAILY,null)==today()
 fun claimDaily(c:Context):Boolean{val sp=p(c);if(dailyClaimed(c))return false;val last=sp.getString(LAST,null);val y=LocalDate.now().minusDays(1).toString();val s=if(last==y)streak(c)+1 else 1;sp.edit().putString(DAILY,today()).putString(LAST,today()).putInt(STREAK,s).apply();CoinManager.add(c,5);addXp(c,15);return true}
 fun addXp(c:Context,a:Int){if(a>0)p(c).edit().putInt(XP,(xp(c)+a).coerceAtMost(2000000)).apply()}
 fun missionClaimed(c:Context,id:String)=p(c).getBoolean("mission_${id}_$today()",false)
 fun claimMission(c:Context,id:String,coins:Int,xp:Int):Boolean{if(missionClaimed(c,id))return false;p(c).edit().putBoolean("mission_${id}_$today()",true).apply();CoinManager.add(c,coins);addXp(c,xp);return true}
}
