package com.sakutabung.app.ui

import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.game.BlockBlastView
import com.sakutabung.app.game.GameLimitManager
import com.sakutabung.app.model.GameScore
import com.sakutabung.app.util.I18n
import java.time.LocalDate

/** Ditambahkan di v1.1.0 - layar mini game Block Blast Lite. */
class BlockBlastActivity : AppCompatActivity() {
    private fun t(key: String, vararg args: Any) = I18n.t(this, key, *args)
    private lateinit var db: DatabaseHelper
    private lateinit var scoreLabel: TextView
    private lateinit var view: BlockBlastView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DatabaseHelper(this)
        title = "Block Blast Lite"

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scoreLabel = TextView(this).apply { text = t("score_zero"); textSize = 20f; gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(8)) }
        root.addView(scoreLabel)
        root.addView(TextView(this).apply { text = t("block_help"); textSize = 12f; gravity = Gravity.CENTER; setPadding(dp(20), 0, dp(20), dp(6)) })

        view = BlockBlastView(this)
        root.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        view.onScoreChanged = { s -> runOnUiThread { scoreLabel.text = t("score_n", s) } }
        view.onGameOver = { s -> runOnUiThread { finishGame(s) } }
    }

    private fun finishGame(score: Int) {
        db.insertGameScore(GameScore(0, "block_blast", score, GameLimitManager.getGrade(this), LocalDate.now().toString()))
        AlertDialog.Builder(this)
            .setTitle(t("game_over"))
            .setMessage(t("block_over", score))
            .setCancelable(false)
            .setPositiveButton(t("close")) { _, _ -> finish() }
            .show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
