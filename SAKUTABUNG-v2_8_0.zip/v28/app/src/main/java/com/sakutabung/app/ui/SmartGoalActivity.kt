package com.sakutabung.app.ui

import android.app.DatePickerDialog
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.R
import com.sakutabung.app.util.Format
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.ceil

/** v2.7: kalkulator target tabungan mandiri; tidak mengubah database atau transaksi lama. */
class SmartGoalActivity : AppCompatActivity() {
    private lateinit var targetInput: EditText
    private lateinit var savedInput: EditText
    private lateinit var result: TextView
    private var deadline = LocalDate.now().plusMonths(1)

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); setBackgroundResource(R.color.background) }
        val scroll = ScrollView(this); val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(TextView(this).apply { text = "🎯 Smart Goal"; textSize = 28f; setTypeface(null, Typeface.BOLD); setTextColor(color(R.color.text)) })
        box.addView(TextView(this).apply { text = "Hitung kebutuhan tabungan tanpa mengubah data celengan."; textSize = 13f; setTextColor(color(R.color.muted)); setPadding(0, dp(4), 0, dp(16)) })
        targetInput = field("Target tabungan (Rp)", "2000000"); box.addView(targetInput)
        savedInput = field("Sudah terkumpul (Rp)", "0"); box.addView(savedInput)
        val dateButton = Button(this).apply { text = "📅 Deadline: ${deadline}"; setOnClickListener { pickDate(this) } }; box.addView(dateButton)
        box.addView(Button(this).apply { text = "✨ Hitung Smart Goal"; setOnClickListener { calculate() } })
        result = TextView(this).apply { textSize = 15f; setTextColor(color(R.color.text)); setPadding(0, dp(18), 0, 0); gravity = Gravity.START }
        box.addView(result)
        box.addView(TextView(this).apply { text = "Tips: hasil adalah estimasi minimum per hari. Menabung lebih banyak dari angka ini memberi ruang aman sebelum deadline."; textSize = 12.5f; setTextColor(color(R.color.muted)); setPadding(0, dp(16), 0, 0) })
        scroll.addView(box); root.addView(scroll); setContentView(root)
    }
    private fun calculate() {
        val target = targetInput.text.toString().filter { it.isDigit() }.toLongOrNull() ?: 0L
        val saved = savedInput.text.toString().filter { it.isDigit() }.toLongOrNull() ?: 0L
        if (target <= 0 || saved < 0) { result.text = "Masukkan angka yang valid."; return }
        val remaining = (target - saved).coerceAtLeast(0L)
        val days = ChronoUnit.DAYS.between(LocalDate.now(), deadline).coerceAtLeast(0L)
        val daily = if (remaining == 0L) 0L else if (days == 0L) remaining else ceil(remaining.toDouble()/days).toLong()
        val weekly = daily * 7L
        val status = when { remaining == 0L -> "🎉 Target sudah tercapai!"; days == 0L -> "⚠️ Deadline hari ini."; else -> "🚀 Masih ada $days hari." }
        result.text = "$status\n\nKurang: ${Format.rupiah(remaining)}\nPer hari: ${Format.rupiah(daily)}\nPer minggu: ${Format.rupiah(weekly)}\nDeadline: $deadline"
    }
    private fun pickDate(button: Button) {
        DatePickerDialog(this, { _, y, m, d -> deadline = LocalDate.of(y,m+1,d); button.text = "📅 Deadline: $deadline" }, deadline.year, deadline.monthValue-1, deadline.dayOfMonth).show()
    }
    private fun field(hint: String, value: String) = EditText(this).apply { this.hint = hint; setText(value); inputType = 2; setPadding(dp(14), dp(12), dp(14), dp(12)); setBackgroundResource(R.drawable.bg_card); layoutParams = LinearLayout.LayoutParams(-1, dp(58)).also { it.setMargins(0,0,0,dp(10)) } }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun color(id:Int)= getColor(id)
}
