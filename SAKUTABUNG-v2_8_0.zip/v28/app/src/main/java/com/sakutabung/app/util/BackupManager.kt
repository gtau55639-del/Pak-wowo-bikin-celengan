package com.sakutabung.app.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.model.Goal
import com.sakutabung.app.model.Transaction

object BackupManager {
    fun export(c: Context): String {
        val db=DatabaseHelper(c); val root=JSONObject(); root.put("app","SakuTabung+"); root.put("version",2)
        val goals=JSONArray(); db.goals().forEach { g-> goals.put(JSONObject().apply { put("id",g.id);put("name",g.name);put("target",g.target);put("start",g.startDate);put("deadline",g.deadline);put("frequency",g.frequency);put("hour",g.reminderHour);put("minute",g.reminderMinute);put("active",g.active) }) }
        val tx=JSONArray(); db.transactions().forEach { t-> tx.put(JSONObject().apply { put("goalId",t.goalId);put("amount",t.amount);put("date",t.date);put("note",t.note) }) }
        root.put("goals",goals);root.put("transactions",tx);root.put("coins",CoinManager.balance(c));root.put("extraLimits",SavingLimitManager.extra(c)); return root.toString(2)
    }
    fun restore(c: Context, json: String) {
        val root=JSONObject(json); require(root.optString("app").contains("SakuTabung"))
        val db=DatabaseHelper(c); val sql=db.writableDatabase; sql.beginTransaction()
        try {
            sql.delete("transactions",null,null); sql.delete("goals",null,null)
            val map=HashMap<Long,Long>(); val gs=root.getJSONArray("goals")
            for(i in 0 until gs.length()){val x=gs.getJSONObject(i); val old=x.optLong("id"); val g=Goal(0,x.getString("name"),x.getLong("target"),x.getString("start"),x.getString("deadline"),x.getString("frequency"),x.getInt("hour"),x.getInt("minute"),x.optBoolean("active",true)); map[old]=db.insertGoal(g)}
            val ts=root.getJSONArray("transactions")
            for(i in 0 until ts.length()){val x=ts.getJSONObject(i); val gid=map[x.getLong("goalId")] ?: continue; db.addTransaction(Transaction(0,gid,x.getLong("amount"),x.getString("date"),x.optString("note")))}
            CoinManager.setBalance(c, root.optInt("coins", 0))
            SavingLimitManager.setExtra(c, root.optInt("extraLimits", 0))
            sql.setTransactionSuccessful()
        } finally { sql.endTransaction() }
    }
}
