package com.sakutabung.app.ui

import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.sakutabung.app.R
import com.sakutabung.app.data.DatabaseHelper
import com.sakutabung.app.util.BrainStatsManager
import com.sakutabung.app.util.CoinManager
import com.sakutabung.app.util.PremiumManager
import com.sakutabung.app.util.RewardManager
import com.sakutabung.app.util.SavingLimitManager

/** v2.8: SakuVerse personal progress dashboard. No new database tables required. */
class SakuVerseActivity : AppCompatActivity() {
    private val db by lazy { DatabaseHelper(this) }
    private val prefs by lazy { getSharedPreferences("sakutaverse", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(28))
            setBackgroundResource(R.color.background)
        }
        box.addView(TextView(this).apply { text = "🌌 SakuVerse"; textSize = 29f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        box.addView(TextView(this).apply { text = "Profil progres pribadi • v2.8"; textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(3), 0, dp(12)) })

        val totalSaved = db.totalSaved()
        val coins = CoinManager.balance(this)
        val brain = BrainStatsManager.total(this)
        val played = BrainStatsManager.played(this)
        val level = (RewardManager.xp(this) / 100) + 1
        val xp = RewardManager.xp(this) % 100
        val streak = prefs.getInt("streak", 0)
        val badges = listOf(
            "🌱 Awal yang baik" to (totalSaved > 0),
            "🪙 Kolektor" to (coins >= 100),
            "🧠 Brain Trainer" to (played >= 5),
            "🎯 Konsisten" to (streak >= 7),
            "🏆 Target Master" to db.goals().any { g -> db.saved(g.id) >= g.target },
            "♛ OPIMOUS" to PremiumManager.isPremium(this)
        )

        box.addView(card("⭐ LEVEL $level", "XP $xp / 100\nTerus kumpulkan XP dari menabung, misi, dan game."))
        box.addView(card("💰 TABUNGAN", "Total tersimpan: Rp${"%,d".format(totalSaved).replace(',', '.')}\nLimit Free tersedia: ${SavingLimitManager.available(this)}"))
        box.addView(card("🪙 KOIN", "Saldo: $coins koin\nGunakan di Toko Koin untuk limit ekstra."))
        box.addView(card("🧠 BRAIN SCORE", "Total skor: $brain\nGame dimainkan: $played\nBest score: ${BrainStatsManager.best(this)}"))
        box.addView(card("🔥 STREAK", "$streak hari\nJaga kebiasaan kecil setiap hari."))

        val badgeCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(10)); background = rounded() }
        badgeCard.addView(TextView(this).apply { text = "🏅 Koleksi Badge"; textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        badges.forEach { (name, unlocked) ->
            badgeCard.addView(TextView(this).apply {
                text = if (unlocked) "✓ $name" else "🔒 $name"
                textSize = 14f; setTextColor(getColorCompat(if (unlocked) R.color.primary else R.color.muted)); setPadding(0, dp(9), 0, dp(5))
            })
        }
        box.addView(badgeCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(10), 0, dp(10)) })
        box.addView(button("🪙 Buka Toko Koin") { startActivity(android.content.Intent(this, CoinShopActivity::class.java)) })
        box.addView(button("🧠 Buka Brain Center") { startActivity(android.content.Intent(this, BrainGamesActivity::class.java)) })
        box.addView(button("← Kembali") { finish() })
        scroll.addView(box)
        setContentView(scroll)
    }

    private fun card(title: String, body: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); background = rounded()
        addView(TextView(this@SakuVerseActivity).apply { text = title; textSize = 17f; setTypeface(null, Typeface.BOLD); setTextColor(getColorCompat(R.color.text)) })
        addView(TextView(this@SakuVerseActivity).apply { text = body; textSize = 13f; setTextColor(getColorCompat(R.color.muted)); setPadding(0, dp(5), 0, 0) })
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) }
    }

    private fun button(label: String, action: () -> Unit): Button = Button(this).apply { text = label; setOnClickListener { action() }; layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(0, dp(5), 0, dp(5)) } }

    private fun rounded() = android.graphics.drawable.GradientDrawable().apply {
        setColor(getColorCompat(R.color.surface)); cornerRadius = dp(18).toFloat()
        setStroke(dp(1), getColorCompat(R.color.divider))
    }

    private fun getColorCompat(id: Int) = androidx.core.content.ContextCompat.getColor(this, id)
}
