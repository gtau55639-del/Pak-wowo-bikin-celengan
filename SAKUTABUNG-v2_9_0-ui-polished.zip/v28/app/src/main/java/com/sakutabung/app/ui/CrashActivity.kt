package com.sakutabung.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class CrashActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_STACK_TRACE = "stack_trace"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val trace = intent.getStringExtra(EXTRA_STACK_TRACE) ?: "(Tidak ada detail error)"
        val dp = { v: Int -> (v * resources.displayMetrics.density).toInt() }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
        }

        root.addView(TextView(this).apply {
            text = "⚠️ Aplikasi mengalami error"
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Screenshot layar ini dan kirimkan ke pengembang supaya bisa diperbaiki."
            textSize = 13f
            setPadding(0, dp(6), 0, dp(14))
        })

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        val traceView = TextView(this).apply {
            text = trace
            textSize = 11f
            setTextIsSelectable(true)
            typeface = Typeface.MONOSPACE
        }
        scroll.addView(traceView)
        root.addView(scroll)

        root.addView(Button(this).apply {
            text = "Salin error"
            setAllCaps(false)
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("crash", trace))
                Toast.makeText(this@CrashActivity, "Disalin ke clipboard", Toast.LENGTH_SHORT).show()
            }
            layoutParams = LinearLayout.LayoutParams(-1, dp(52)).also { it.setMargins(0, dp(12), 0, dp(8)) }
        })
        root.addView(Button(this).apply {
            text = "Tutup aplikasi"
            setAllCaps(false)
            gravity = Gravity.CENTER
            setOnClickListener { finishAffinity() }
            layoutParams = LinearLayout.LayoutParams(-1, dp(52))
        })

        setContentView(root)
    }
}
