package com.sakutabung.app

import android.app.Application
import android.content.Intent
import com.sakutabung.app.ui.CrashActivity
import java.io.PrintWriter
import java.io.StringWriter
import kotlin.system.exitProcess

/**
 * Menangkap crash yang tidak tertangani, lalu menampilkan detailnya di layar
 * (CrashActivity) alih-alih membuat aplikasi force-close tanpa keterangan.
 * Ini memudahkan diagnosis bug tanpa perlu adb/logcat.
 */
class SakuTabungApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val intent = Intent(this, CrashActivity::class.java).apply {
                    putExtra(CrashActivity.EXTRA_STACK_TRACE, sw.toString())
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                }
                startActivity(intent)
            } catch (_: Throwable) {
                // fallback: if we can't even show the crash screen, don't loop forever
            } finally {
                defaultHandler?.uncaughtException(thread, throwable)
                android.os.Process.killProcess(android.os.Process.myPid())
                exitProcess(1)
            }
        }
    }
}
