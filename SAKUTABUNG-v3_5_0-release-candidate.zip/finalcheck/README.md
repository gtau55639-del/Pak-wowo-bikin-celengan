# SakuTabung v3.4.1 — Smart Saving & Economy Guard

Pendamping menabung fisik yang offline-first.

## Fokus
- Rencana dan insight menabung fisik.
- Prediksi target berdasarkan catatan lokal.
- Saving XP dibatasi satu kali per hari agar tidak mudah difarming.
- XP game/login/misi tetap berjalan offline.
- Premium milestone: level 20 (3 hari), level 50 (7 hari), level 100 (permanen), masing-masing sekali klaim.
- Google Login tetap opsional.
- Tidak ada uang pengguna yang disimpan aplikasi.

## Catatan build
Build penuh perlu dijalankan di Android Studio atau GitHub Actions dengan dependency Gradle tersedia.


## v3.4.2 — Release Hardening
- Edit catatan menabung tanpa menghapus progres target.
- Validasi tanggal catatan agar tidak dapat dicatat di masa depan.
- Validasi nominal dan panjang catatan.
- Status target dihitung ulang setelah koreksi catatan.
- Tetap offline-first dan tidak menyimpan uang pengguna.

## v3.4.3 — Data Safety & Goal Reconciliation
- Moving an edited saving note between goals now reconciles both goals correctly.
- Saving-note text is capped at 200 characters.
- Backup format upgraded to v3 and now preserves saving-challenge state.
- Restore now restores Premium entitlement exactly instead of leaving stale trial/permanent state behind.
- No money is stored by the app; these are records of physical saving activity.

## v3.5.0 — Release Candidate Hardening
- Feature freeze: physical saving remains the core.
- Added release checklist covering offline, rewards, backup/restore, themes, and device testing.
- Release signing credentials are now read from CI environment variables instead of being stored in the project.
- Google account linking is identity-only and never grants Premium.
- Backup schema upgraded to v4 with validation for goal/transaction data.
- Premium milestone rules remain: Lv20 = 3 days, Lv50 = 7 days, Lv100 = permanent; each one-time claim.
